﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Журнал1
{
    class Program
    {
            static string[] texts = new string[]{ "Сделайте пожалуйста выбор оперции, для подтверждения своего решения, нажмите - Enter\n",
            "ЖУРНАЛ\n",
"1 : Студент", "2 : Преподаватель", "3 : Админ","4 : Выход" };

            static void Main(string[] args)
            {
                menu();

            }

            public void menuA()

            {

                menu();

            }

            static void menu()

            {

                Console.Clear();

                foreach (string text in texts)

                    Console.WriteLine(text);

                int num = keys();//вызов менюшки

                switch (num)

                {

                    case 1: { ucheniki(); Console.Clear(); }; break;

                    case 2: { prepod(); Console.Clear(); } break;

                    case 3: { admin(); Console.Clear(); } break;

                    case 4: { admin(); Console.Clear(); }; break;

                }

            }

            static void ucheniki()

            {

                uchenik adm = new uchenik();

                adm.student();

            }

            static void prepod()

            {

                Prepod adm = new Prepod();

                adm.prepo();

            }

            static void Text(int i)//Замена цвета меню

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(texts[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(texts[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(texts[2]);

                    Console.WriteLine(texts[3]);

                    Console.WriteLine(texts[4]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(texts[0]);

                    Console.WriteLine(texts[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(texts[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(texts[3]);

                    Console.WriteLine(texts[4]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(texts[0]);

                    Console.WriteLine(texts[1]);

                    Console.WriteLine(texts[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(texts[3]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(texts[4]);

                }

                if (i == 4)

                {

                    Console.Clear();

                    Console.WriteLine(texts[0]);

                    Console.WriteLine(texts[1]);

                    Console.WriteLine(texts[2]);

                    Console.WriteLine(texts[3]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(texts[4]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static int keys()//работа менюшки

            {

                int num = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        num++;

                        Text(num);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        num--;

                        Text(num);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                    if (num == 0)

                    {

                        num = 4;

                        Text(4);

                    }

                    if (num == 5)

                    {

                        num = 1;

                        Text(1);

                    }

                } while (!flag);

                return num;

            }

            static void admin()

            {

                adminP adm = new adminP();

                adm.adminP_panel();

            }

        }

        class Prepod

        {

            static string[] admin = new string[] { "Сделай выбор оперции, для подтвердения нажмите - Enter\n", "1: Просмотреть оценки ученика", "2: Изменить оценки ученику", "3: Вернуться в главное меню" };

            public void prepo()

            {

                Console.Clear();

                string name1P = "";

                string name21P = "";

                string pred11P = "";

                string pred21P = "";

                string logP = "";

                string pasP = "";

                string name1 = "";

                string name21 = "";

                Console.WriteLine("Введите пожалуйста логин");

                string log = Console.ReadLine();

                Console.WriteLine("Введите пожалуйста пароль");

                string pas = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat"))

                {

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat", FileMode.OpenOrCreate)))

                    {

                        name1 = prepod1.ReadString();

                        name21 = prepod1.ReadString();

                        prepod1.Close();

                    }

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name1 + name21 + ".dat"))

                    {

                        using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name1 + name21 + ".dat", FileMode.Open)))

                        {

                            while (prepod1.PeekChar() > -1)

                            {

                                name1P = prepod1.ReadString();

                                name21P = prepod1.ReadString();

                                pred11P = prepod1.ReadString();

                                pred21P = prepod1.ReadString();

                                string grup = prepod1.ReadString();

                                logP = prepod1.ReadString();

                                pasP = prepod1.ReadString();

                            }

                            prepod1.Close();

                        }

                        if (log == logP && pas == pasP)

                        {

                            Console.Clear();

                            menu();

                        }

                        else

                        {

                            Console.WriteLine("Вами был введён не верный логин или пароль");

                            Console.ReadKey();

                            vixod();
                        }

                    }

                    else

                    {

                        Console.Clear();

                        Console.WriteLine("Вы ввели что-то не правильно");

                        Console.ReadKey();

                        vixod();

                    }

                }

                else

                {

                    Console.Clear();

                    Console.WriteLine("Вы ввели что-то не правильно");

                    Console.ReadKey();

                    vixod();

                }

            }

            static int rabmen()

            {

                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        prepodT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        prepodT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void prepodT(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[3]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static void menu()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = rabmen();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); getI(); }; break;

                    case 2: { Console.Clear(); chaI(); } break;

                    case 3: { Console.Clear(); chaI(); } break;

                    case 4: { Console.Clear(); vixod(); }; break;
            }

            }

            static void chaI()

            {

                Console.WriteLine("Просьба ввести ваши имя и фамилию ещё-раз, чтобы мы могли найти ваши данные");

                Console.WriteLine("Введите имя");

                string ima = Console.ReadLine();

                Console.WriteLine("Введите фамилию");

                string fam = Console.ReadLine();

                string nameS = "";

                string name2S = "";

                string para1 = "";

                string para2 = "";

                string log = "";

                string pas = "";

                if

                (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + ima + fam + ".dat"))

                {

                    int n, n1, n2, n3 = 0;

                    string grupaU = "";

                    string nameU = "";

                    string name2U = "";

                    string logU = "";

                    string pasU = "";

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + ima + fam + ".dat", FileMode.OpenOrCreate)))

                    {

                        nameS = prepod1.ReadString();

                        name2S = prepod1.ReadString();

                        para1 = prepod1.ReadString();

                        para2 = prepod1.ReadString();

                        string grup = prepod1.ReadString();

                        log = prepod1.ReadString();

                        pas = prepod1.ReadString();

                        prepod1.Close();

                    }

                    Console.WriteLine("Введите группу ученика");

                    string grupa = Console.ReadLine();

                    Console.WriteLine("Введите имя ученика");

                    string imaU = Console.ReadLine();

                    Console.WriteLine("Введите фамилию ученика");

                    string famU = Console.ReadLine();

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat"))

                    {

                        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.Open)))

                        {

                            grupaU = zhurnal.ReadString();

                            nameU = zhurnal.ReadString();

                            name2U = zhurnal.ReadString();

                            n = zhurnal.ReadInt32();

                            n1 = zhurnal.ReadInt32();

                            n2 = zhurnal.ReadInt32();

                            n3 = zhurnal.ReadInt32();

                            logU = zhurnal.ReadString();

                            pasU = zhurnal.ReadString();

                            zhurnal.Close();

                        }

                        // русский, математика, английский, физика

                        if (para1 == "русский" && para2 == "математика")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за русский");

                            int o = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за математику");

                            int o1 = Convert.ToInt32(Console.ReadLine());

                            int o2 = n2;

                            int o3 = n3;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "математика" && para2 == "русский")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за математику");

                            int o1 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за русский");

                            int o = Convert.ToInt32(Console.ReadLine());

                            int o2 = n2;

                            int o3 = n3;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "русский" && para2 == "английский")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за русский");

                            int o = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за английский");

                            int o2 = Convert.ToInt32(Console.ReadLine());

                            int o1 = n1;

                            int o3 = n3;

                            using

                            (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "английский" && para2 == "русский")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за ангийский");

                            int o2 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за  русский");

                            int o = Convert.ToInt32(Console.ReadLine());

                            int o1 = n1;

                            int o3 = n3;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "русский" && para2 == "физика")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за русский");

                            int o = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Введите оценку ученика за физика");

                            int o3 = Convert.ToInt32(Console.ReadLine());

                            int o1 = n1;

                            int o2 = n2;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "физика" && para2 == "русский")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за физику");

                            int o3 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за  русский");

                            int o = Convert.ToInt32(Console.ReadLine());

                            int o2 = n2;

                            int o1 = n1;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "математика" && para2 == "английский")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за математику");

                            int o1 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за английский");

                            int o2 = Convert.ToInt32(Console.ReadLine());

                            int o = n;

                            int o3 = n3;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "английский" && para2 == "математика")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за английский");

                            int o2 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за математику");

                            int o1 = Convert.ToInt32(Console.ReadLine());

                            int o = n;

                            int o3 = n3;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "математика" && para2 == "физика")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за математику");

                            int o1 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за физика");

                            int o3 = Convert.ToInt32(Console.ReadLine());

                            int o = n;

                            int o2 = n2;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "физика" && para2 == "математика")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за физика");

                            int o3 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за математику");

                            int o1 = Convert.ToInt32(Console.ReadLine());

                            int o = n;

                            int o2 = n2;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "английский" && para2 == "физика")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за английский");

                            int o2 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за физика");

                            int o3 = Convert.ToInt32(Console.ReadLine());

                            int o = n;

                            int o1 = n1;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else if (para1 == "физика" && para2 == "английский")

                        {

                            string grupaI = grupaU;

                            string nameI = nameU;

                            string name2I = name2U;

                            string logI = logU;

                            string pasI = pasU;

                            Console.WriteLine("Введите оценку ученика за физика");

                            int o3 = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Введите оценку ученика за английский");

                            int o2 = Convert.ToInt32(Console.ReadLine());

                            int o = n;

                            int o1 =

                            n1;

                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grupa + imaU + famU + ".dat", FileMode.OpenOrCreate)))

                            {

                                zhurnal.Write(grupaI);

                                zhurnal.Write(nameI);

                                zhurnal.Write(name2I);

                                zhurnal.Write(o);

                                zhurnal.Write(o1);

                                zhurnal.Write(o2);

                                zhurnal.Write(o3);

                                zhurnal.Write(logI);

                                zhurnal.Write(pasI);

                                zhurnal.Close();

                            }

                            Console.WriteLine("Данные изменены");

                        }

                        else

                        {

                            Console.Clear();

                            Console.WriteLine("С данными этим преподавателем что-то не так");

                        }

                    }

                    else

                    {

                        Console.WriteLine("Такого ученика нету");

                        Console.ReadKey();

                        menu();

                    }

                }

                else

                {

                    Console.WriteLine("Вы ввели что-то не так");

                }

                Console.ReadKey();

                menu();

            }

            static void getI()

            {

                Console.WriteLine("Введите группу студента");

                string gr = Console.ReadLine();

                Console.WriteLine("Введите имя студента");

                string name = Console.ReadLine();

                Console.WriteLine("Введите фамилию студента");

                string name2 = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr + name + name2 + ".dat"))

                {

                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr + name + name2 + ".dat", FileMode.OpenOrCreate)))

                    {

                        gr = zhurnal.ReadString();

                        name = zhurnal.ReadString();

                        name2 = zhurnal.ReadString();

                        int n = zhurnal.ReadInt32();

                        int n1 = zhurnal.ReadInt32();

                        int n2 = zhurnal.ReadInt32();

                        int n3 = zhurnal.ReadInt32();

                        string log = zhurnal.ReadString();

                        string pas = zhurnal.ReadString();

                        Console.WriteLine("Группа: {0} Имя: {1} Фамилия: {2} Русский: {3} Математика: {4} Английский: {5} Физкультура: {6}", gr, name, name2, n, n1, n2, n3);

                        zhurnal.Close();

                    }

                }

                else

                {

                    Console.WriteLine("Вы ввели что-то не то");

                }

                Console.ReadKey();

                menu();

            }

            static void vixod()

            {

                Program abc = new Program();
                abc.menuA();

            }

        }

        class uchenik

        {
 
            static string[] admin = new string[] { "Сделайте выбор оперции, для поддтверждения нажмите - Enter\n", "1: Просмотреть оценки учеников", "2: Вернуться в главное меню меню" };

            public void student()

            {

                Console.Clear();

                login();

            }

            static void login()

            {

                int n = 0;

                int n1 = 0;

                int n2 = 0;

                int n3 = 0;

                string log, pas, name, nameS, name2S, name1, name21 = "";

                Console.WriteLine("Введите логин");

                string logS = Console.ReadLine();

                Console.WriteLine("Введите пароль");

                string pasS = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + logS + ".dat"))

                {

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + logS + ".dat", FileMode.OpenOrCreate)))

                    {

                        name = prepod1.ReadString();

                        nameS = prepod1.ReadString();

                        name2S = prepod1.ReadString();

                        prepod1.Close();

                    }

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat"))

                    {

                        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.Open)))

                        {

                            name = zhurnal.ReadString();

                            nameS = zhurnal.ReadString();

                            name2S = zhurnal.ReadString();

                            n = zhurnal.ReadInt32();

                            n1 = zhurnal.ReadInt32();

                            n2 = zhurnal.ReadInt32();

                            n3 = zhurnal.ReadInt32();

                            log = zhurnal.ReadString();

                            pas = zhurnal.ReadString();

                            zhurnal.Close();

                        }

                        if (log == logS && pas == pasS)

                        {

                            Console.Clear();

                            menushka();

                        }

                        else

                        {

                            Console.WriteLine("Вами был введён не верный логин или пароль");

                            Console.ReadKey();

                            nazadP();

                        }

                    }

                    else

                    {

                        Console.WriteLine("Вы ввели что-то не правильно");

                        Console.ReadKey();

                        nazadP();

                    }

                }

                else

                {

                    Console.WriteLine("Вы ввели не верный логин или пароль");

                    Console.ReadKey();

                    nazadP();

                }

            }

            static void menushka()

            {

                menuU();

            }

            static void adminT(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static int adminK()//работа менюшки

            {

                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void menuU()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = adminK();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); ochenki(); }; break;

                    case 2: { Console.Clear(); nazadP(); }; break;

                }

            }

            static void ochenki()

            {

                int n = 0;

                int n1 = 0;

                int n2 = 0;

                int n3 = 0;

                string log, pas = "";

                Console.WriteLine("Введите группу");

                string name = Console.ReadLine();

                Console.WriteLine("Введите имя");

                string nameS = Console.ReadLine();

                Console.WriteLine("Введите фамилию");

                string name2S = Console.ReadLine();

                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.Open)))

                {

                    name = zhurnal.ReadString();

                    nameS = zhurnal.ReadString();

                    name2S = zhurnal.ReadString();

                    n = zhurnal.ReadInt32();

                    n1 = zhurnal.ReadInt32();

                    n2 = zhurnal.ReadInt32();

                    n3 = zhurnal.ReadInt32();

                    log = zhurnal.ReadString();

                    pas = zhurnal.ReadString();

                    zhurnal.Close();

                }

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat"))

                {

                    Console.WriteLine("Оценка по русскому: {0} Оценка по математика: {1} Оценка по английскому {2} Оценка по физкультуре: {3}", n, n1, n2, n3);

                    Console.ReadKey();

                    menuU();

                }

                else

                {

                    Console.WriteLine("Такого ученика нету");

                    Console.ReadKey();

                    menuU();

                }

            }

            static void nazadP()

            {

                Program adm = new Program();

                adm.menuA();

            }

        }

        struct stateGI

        {

            public string grup;

            public string nameS;

            public string name2S;

            public int n;

            public int n1;

            public string log;

            public string pas;

            public stateGI(string gG, string aG, string bG, int b1, int b2, string cG, string dG)

            {

                grup = gG;

                nameS = aG;

                name2S = bG;

                n = b1;

                n1 = b2;

                log = cG;

                pas = dG;

            }

        }

        class adminGetIn

        {

            static string[] admin = new string[] { "Сделайте выбор оперции, для поддтверждения нажмите - Enter\n", "1: Данные о преподавателях", "2: Данные о учениках", "3: Данные о журналах", "4: Вернуться в главное меню" };

            public void adminGetI()

            {

                menuGetI();

            }

            static void menuGetI()

            {

                adminsGetI();

            }

            static int adminK()//работа менюшки

            {

                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void adminT(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[4]);

                }

                if (i == 4)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[4]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static void adminsGetI()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = adminK();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); infoprepod(); }; break;

                    case 2: { Console.Clear(); infostud(); } break;

                    case 3: { Console.Clear(); zhurnal(); } break;

                    case 4: { Console.Clear(); nazad(); }; break;

                }

            }

            static void zhurnal()

            {

                Console.WriteLine("Введите название группы");

                string namegr = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + namegr + ".dat"))

                {

                    Console.WriteLine("Такая группа существует");

                }

                else

                {

                    Console.WriteLine("Такой группы нету");

                }

                Console.ReadKey();

                adminsGetI();

            }

            static void nazad()

            {

                adminP adm = new adminP();

                adm.adminsA();

            }

            static void infostud()

            {

                Console.WriteLine("Введите группу");

                string gr = Console.ReadLine();

                Console.WriteLine("Введите имя");

                string name = Console.ReadLine();

                Console.WriteLine("Введите фамилию");

                string name2 = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr + name + name2 + ".dat"))

                {

                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr + name + name2 + ".dat", FileMode.OpenOrCreate)))

                    {

                        gr = zhurnal.ReadString();

                        name = zhurnal.ReadString();

                        name2 = zhurnal.ReadString();

                        int n = zhurnal.ReadInt32();

                        int n1 = zhurnal.ReadInt32();

                        int n2 = zhurnal.ReadInt32();

                        int n3 = zhurnal.ReadInt32();

                        string log = zhurnal.ReadString();

                        string pas = zhurnal.ReadString();

                        Console.WriteLine("Группа: {0} Имя: {1} Фамилия: {2} Русский: {3} Математика: {4} Английский: {5} Физкультура: {6} Логин: {7} Пароль: {8}", gr, name, name2, n, n1, n2, n3, log, pas);

                        zhurnal.Close();

                    }

                }

                else

                {

                    Console.WriteLine("Вы ввели что-то не то");

                }

                Console.ReadKey();

                adminsGetI();

            }

            static void infoprepod()

            {

                Console.WriteLine("Введите имя преподавателя");

                string nameS = Console.ReadLine();

                Console.WriteLine("Введите фамилию преподавателя");

                string name2S = Console.ReadLine();

                string para1 = "";

                string para2 = "";

                string log = "";

                string pas = "";

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + nameS + name2S + ".dat"))

                {

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                    {

                        nameS = prepod1.ReadString();

                        name2S = prepod1.ReadString();

                        para1 = prepod1.ReadString();

                        para2 = prepod1.ReadString();

                        string grup = prepod1.ReadString();

                        log = prepod1.ReadString();

                        pas = prepod1.ReadString();

                        Console.WriteLine("Имя: {0} Фамилия: {1} Дисцилина 1: {2} Дисциплина 2: {3} Группа: {4} Логин: {5} Пароль {6}", nameS, name2S, para1, para2, grup, log, pas);

                        prepod1.Close();

                    }

                }

                else

                {

                    Console.WriteLine("Такого преподавателя нету");

                }

                Console.ReadKey();

                adminsGetI();

            }

        }

        class adminP

        {

            static string[] admin = new string[] { "Сделайте пожалуйста выбор оперции, выбирай стрелками вниз-вверх, для подтверждения нажмите - Ентер\n", "1: Добавить новые данные", "2: Удалить данные", "3: Изменить данные", "4: Просмотреть данные", "5: Вернуться в главное меню" };

            public void adminP_panel()

            {

                nachaloA();

            }

            public void adminsA()

            {

                admins();

            }

            static void nachaloA()

            {

                vxodA();

            }

            static void vxodA()

            {

                Console.Clear();

                string a, b;

                string c = "Daniyal";  //Логин

                string d = "12345";    //Пароль

                Console.WriteLine("Введите пожалуйста логин");

                a = Console.ReadLine();

                Console.WriteLine("Введите пожалуйста пароль");

                b = Console.ReadLine();

                if (a == c && b == d)

                {

                    admins();

                }

                else

                {

                    Console.Clear();

                    Console.WriteLine("Вы ввели что-то не правильно");

                    Console.ReadKey();

                    nachaloA();

                }

            }

            static void vixod()

            {

                Program abc = new Program();

                abc.menuA();

            }

            static void adminT(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                    Console.WriteLine(admin[5]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                    Console.WriteLine(admin[5]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[4]);

                    Console.WriteLine(admin[5]);

                }

                if (i == 4)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[4]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[5]);

                }

                if (i == 5)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[5]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static int adminK()//работа менюшки

            {

                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void admins()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = adminK();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); addA(); }; break;

                    case 2: { Console.Clear(); addD(); } break;

                    case 3: { Console.Clear(); adminCha(); } break;

                    case 4: { Console.Clear(); addGI(); }; break;

                    case 5: { vixod(); }; break;

                }

            }

            static void addA()

            {

                adminInfo a = new adminInfo();

                a.adminI();

            }

            static void addD()

            {

                admindelete b = new admindelete();

                b.admindel();

            }
            static void adminCha()

            {

                adminChange c = new adminChange();

                c.adminChANGE();

            }

            static void addGI()

            {

                adminGetIn b = new adminGetIn();

                b.adminGetI();

            }

        }

        class adminChange

        {

            static string[] admin = new string[] { "Сделайте выбор оперции, для подтверждения нажмите - Enter\n", "1: Изменить данные о преподавателях", "2: Изменить данные о учениках", "3: Изметь данные о журналах", "4: Вернуться в главное меню" };

            public void adminChANGE()

            {

                menuGetI();

            }

            static void menuGetI()

            {

                adminsGetI();

            }

            static int adminK()//работа менюшки

            {

                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void adminT(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[4]);

                }

                if (i == 4)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[4]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static void adminsGetI()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = adminK();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); chanprep(); } break;

                    case 2: { Console.Clear(); chanstud(); } break;

                    case 3: { Console.Clear(); chanzhu(); } break;

                    case 4: { Console.Clear(); nazad(); }; break;

                }

            }

            static void chanzhu()

            {

                Console.WriteLine("Введите название группы");

                string gr1 = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr1 + ".dat"))

                {

                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr1 + ".dat", FileMode.OpenOrCreate)))

                    {

                        gr1 = zhurnal.ReadString();

                        Console.WriteLine("Название группы: {0}", gr1);

                    }

                    Console.WriteLine("Это то, что мы имеем");

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr1 + ".dat");

                    Console.Clear();

                    Console.WriteLine("Введите группу к которой будет прекреплён новый журнал");

                    string gr = Console.ReadLine();

                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr + ".dat", FileMode.OpenOrCreate)))

                    {

                        zhurnal.Write(gr);

                    }

                    Console.WriteLine("Вы создали журнал");

                }

                else

                {

                    Console.WriteLine("Такой группы нету");

                }

                Console.ReadKey();

                adminsGetI();

            }

            static void chanstud()

            {

                string pred1 = "";

                string pred2 = "";

                int n = 0;

                int n1 = 0;

                int n2 = 0;

                int n3 = 0;

                string log = "";

                string pas = "";

                Console.WriteLine("Введите группу ученика");

                string name = Console.ReadLine();

                Console.WriteLine("Введите имя ученика");

                string nameS = Console.ReadLine();

                Console.WriteLine("Введите фамилию ученика");

                string name2S = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat"))

                {

                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                    {

                        name = zhurnal.ReadString();

                        nameS = zhurnal.ReadString();

                        name2S = zhurnal.ReadString();

                        n = zhurnal.ReadInt32();

                        n1 = zhurnal.ReadInt32();

                        n2 = zhurnal.ReadInt32();

                        n3 = zhurnal.ReadInt32();

                        log = zhurnal.ReadString();

                        pas = zhurnal.ReadString();

                        Console.WriteLine("Группа: {0} Имя: {1} Фамилия: {2} Оценка 1: {3} Оценка 2:{4} Оценка 3: {5} Оценка 4: {6} Логин: {7} Пароль: {8}", name, nameS, name2S, n, n1, n2, n3, log, pas);

                        zhurnal.Close();

                    }

                    Console.WriteLine("Это те данные, которые мы имеем");

                    Console.ReadKey();

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat");

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat");

                    Console.Clear();

                    Console.WriteLine("Вводим новые данные");

                    Console.WriteLine("Введите название группы");

                    name = Console.ReadLine();

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + ".dat"))

                    {

                        Console.WriteLine("Введите имя ученика");

                        nameS = Console.ReadLine();

                        Console.WriteLine("Введите фамилию ученика");

                        name2S = Console.ReadLine();

                        Console.WriteLine("У нас есть 4 предмета - русский, математика, английский, физика");

                        Console.WriteLine("Введите Оценку ученика за русский");

                        n = Convert.ToInt32(Console.ReadLine());

                        if (n < 0 || n > 5)

                        {

                            Console.WriteLine("У нас 5 бальная система");

                            Console.ReadKey();

                            adminsGetI();

                        }

                        else

                            Console.WriteLine("Введите оценку ученика за математику");


                        n1 = Convert.ToInt32(Console.ReadLine());

                        if (n1 < 0 || n1 > 5)

                        {

                            Console.WriteLine("У нас 5 бальная система");

                            Console.ReadKey();

                            adminsGetI();

                        }

                        else

                            Console.WriteLine("Введите оценку ученика за английский");

                        n2 = Convert.ToInt32(Console.ReadLine());

                        if (n2 < 0 || n2 > 5)

                        {

                            Console.WriteLine("У нас 5 бальная система");

                            Console.ReadKey();

                            adminsGetI();

                        }

                        else

                            Console.WriteLine("Введите оценку ученика за физика");

                        n3 = Convert.ToInt32(Console.ReadLine());

                        if (n3 < 0 || n3 > 5)

                        {

                            Console.WriteLine("У нас 5 бальная система");

                            Console.ReadKey();

                            adminsGetI();

                        }

                        else

                            Console.WriteLine("Введите логин");

                        log = Console.ReadLine();

                        Console.WriteLine("Введите пароль");

                        pas = Console.ReadLine();

                        if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat"))

                        {

                            Console.WriteLine("Уже существует такой логин и пароль!");

                            Console.ReadKey();

                            adminsGetI();

                        }

                        else

                            using (BinaryWriter prepod1 = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat", FileMode.OpenOrCreate)))

                            {

                                prepod1.Write(name);

                                prepod1.Write(nameS);

                                prepod1.Write(name2S);

                                prepod1.Close();

                            }

                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                        {

                            zhurnal.Write(name);

                            zhurnal.Write(nameS);

                            zhurnal.Write(name2S);

                            zhurnal.Write(n);

                            zhurnal.Write(n1);

                            zhurnal.Write(n2);

                            zhurnal.Write(n3);

                            zhurnal.Write(log);

                            zhurnal.Write(pas);

                        }

                        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                        {

                            name = zhurnal.ReadString();

                            nameS = zhurnal.ReadString();

                            name2S = zhurnal.ReadString();

                            n = zhurnal.ReadInt32();

                            n1 = zhurnal.ReadInt32();

                            n2 = zhurnal.ReadInt32();

                            n3 = zhurnal.ReadInt32();

                            log = zhurnal.ReadString();

                            pas = zhurnal.ReadString();
                            Console.WriteLine("Группа: {0} Имя: {1} Фамилия: {2} Русский: {3} Математика: {4} Английский: {5} Физкультура: {6} Логин: {7} Пароль: {8}", name, nameS, name2S, n, n1, n2, n3, log, pas);

                            zhurnal.Close();

                        }

                        Console.WriteLine("Всё записано");

                        Console.ReadKey();

                        adminsGetI();

                    }

                    else

                    {

                        Console.WriteLine("Такой группы нету");

                        Console.ReadKey();

                        adminsGetI();

                    }

                }

            }

            static void chanprep()

            {

                string name1 = "";

                string name21 = "";

                string pred11 = "";

                string pred21 = "";

                string log = "";

                string pas = "";

                Console.WriteLine("Введите имя преподавателя");

                string t = Console.ReadLine();

                Console.WriteLine("Введите фамилию преподавателя");

                string t1 = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + t + t1 + ".dat"))

                {

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + t + t1 + ".dat", FileMode.OpenOrCreate)))

                    {

                        name1 = prepod1.ReadString();

                        name21 = prepod1.ReadString();

                        pred11 = prepod1.ReadString();

                        pred21 = prepod1.ReadString();

                        string grup1 = prepod1.ReadString();

                        log = prepod1.ReadString();

                        pas = prepod1.ReadString();

                        Console.WriteLine("Имя: {0} Фамилия: {1} Дисцилина 1: {2} Дисциплина 2: {3} Группа: {4} Логин: {5} Пароль {6}", name1, name21, pred11, pred21, grup1, log, pas);

                        prepod1.Close();

                    }

                    Console.WriteLine("Это данные, которыми сейчас обладает преподаватель.");

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name1 + name21 + ".dat");

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat");

                    Console.Clear();

                    Console.WriteLine("Введите новые данные");

                    Console.WriteLine("Введите имя преподавателя");

                    name1 = Console.ReadLine();

                    Console.WriteLine("Введите фамилию преподавателя");

                    name21 = Console.ReadLine();

                    Console.WriteLine("Есть 4 дисциплины: русский, математика, английский, физика");

                    Console.WriteLine("Введите 1 дисциплину");

                    pred11 = Console.ReadLine();

                    if (pred11 != "математика" && pred11 != "русский" && pred11 != "английский" && pred11 != "физика")

                    {

                        Console.WriteLine("Такого предмета нету");

                        Console.ReadKey();

                        adminsGetI();

                    }

                    Console.WriteLine("Введите 2 дисциплину");

                    pred21 = Console.ReadLine();

                    if (pred21 != "математика" && pred21 != "русский" && pred21 != "английский" && pred21 != "физика")

                    {

                        Console.WriteLine("Такого предмета нету");

                        Console.ReadKey();

                        adminsGetI();

                    }

                    Console.WriteLine("Введи группу к которой будет прекреплён учитель");

                    string grup = Console.ReadLine();

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grup + ".dat"))

                    {

                        Console.WriteLine("Создайте логин");

                        log = Console.ReadLine();

                        Console.WriteLine("Создайте пароль");

                        pas = Console.ReadLine();

                        if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat"))

                        {

                            Console.WriteLine("Уже существует такой логин и пароль!");

                            Console.ReadKey();

                            adminsGetI();

                        }

                        else

                            using (BinaryWriter prepod1 = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat", FileMode.OpenOrCreate)))

                            {

                                prepod1.Write(name1);

                                prepod1.Write(name21);

                                prepod1.Close();

                            }

                        using (BinaryWriter prepod1 = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + name1 + name21 + ".dat", FileMode.OpenOrCreate)))

                        {

                            prepod1.Write(name1);

                            prepod1.Write(name21);

                            prepod1.Write(pred11);

                            prepod1.Write(pred21);

                            prepod1.Write(grup);

                            prepod1.Write(log);

                            prepod1.Write(pas);

                            prepod1.Close();

                        }

                        using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + name1 + name21 + ".dat", FileMode.Open)))

                        {

                            name1 = prepod1.ReadString();

                            name21 = prepod1.ReadString();

                            pred11 = prepod1.ReadString();

                            pred21 = prepod1.ReadString();

                            grup = prepod1.ReadString();

                            log = prepod1.ReadString();

                            pas = prepod1.ReadString();

                            Console.WriteLine("Имя: {0} Фамилия: {1} Дисцилина 1: {2} Дисциплина 2: {3} Группа: {4} Логин: {5} Пароль {6}", name1, name21, pred11, pred21, grup, log, pas);

                            prepod1.Close();

                        }

                        Console.ReadKey();

                        Console.ReadLine();

                        adminsGetI();

                    }

                    else

                    {

                        Console.WriteLine("Такой группы нету");

                        Console.ReadLine();

                        adminsGetI();

                    }

                }

                else

                {

                    Console.WriteLine("Не могу изменить данные того, кого нету");

                }

                Console.ReadKey();

                Console.Clear();

                adminsGetI();

            }

            static void nazad()

            {

                adminP adm = new adminP();

                adm.adminsA();

            }

        }

        struct stateD

        {

            public string nameD;

            public string name1D;

            public string predD;

            public string pred1D;

            public stateD(string aD, string bD, string cD, string dD)

            {

                nameD = aD;

                name1D = bD;

                predD = cD;

                pred1D = dD;

            }

        }

        class admindelete

        {

            static string[] admin = new string[] { "Сделай выбор оперции, что бы поддтвердить нажми - Enter\n", "1 Удалить Преподавателя", "2 Удалить ученика", "3 Назад" };

            public void admindel()

            {

                menush();

            }

            static void menush()

            {

                adminsD();

            }

            static void adminsD()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = menuADK();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); delprep(); }; break;

                    case 2: { Console.Clear(); deluche(); } break;

                    case 3: { nazadD(); } break;

                }

            }

            static void delprep()

            {

                string name1 = "";

                string name21 = "";

                string

                pred11 = "";

                string pred21 = "";

                string log = "";

                string pas = "";

                Console.WriteLine("Введите имя преподавателя");

                string t = Console.ReadLine();

                Console.WriteLine("Введите фамилию преподавателя");

                string t1 = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + t + t1 + ".dat"))

                {

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + t + t1 + ".dat", FileMode.OpenOrCreate)))

                    {

                        name1 = prepod1.ReadString();

                        name21 = prepod1.ReadString();

                        pred11 = prepod1.ReadString();

                        pred21 = prepod1.ReadString();

                        string grup1 = prepod1.ReadString();

                        log = prepod1.ReadString();

                        pas = prepod1.ReadString();

                        prepod1.Close();

                    }

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name1 + name21 + ".dat");

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat");

                    Console.Clear();

                    Console.WriteLine("Преподаватель удалён");

                    Console.ReadKey();

                    adminsD();

                }

                else

                {

                    Console.WriteLine("Такого преподавателя нету");

                    Console.ReadKey();

                    adminsD();

                }

            }

            static void deluche()

            {

                string pred1 = "";

                string pred2 = "";

                int n = 0;

                int n1 = 0;

                int n2 = 0;

                int n3 = 0;

                string log = "";

                string pas = "";

                Console.WriteLine("Введите группу ученика");

                string name = Console.ReadLine();

                Console.WriteLine("Введите имя ученика");

                string nameS = Console.ReadLine();

                Console.WriteLine("Введите фамилию ученика");

                string name2S = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat"))

                {

                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                    {

                        name = zhurnal.ReadString();

                        nameS = zhurnal.ReadString();

                        name2S = zhurnal.ReadString();

                        n = zhurnal.ReadInt32();

                        n1 = zhurnal.ReadInt32();

                        n2 = zhurnal.ReadInt32();

                        n3 = zhurnal.ReadInt32();

                        log = zhurnal.ReadString();

                        pas = zhurnal.ReadString();

                        zhurnal.Close();

                    }

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat");

                    File.Delete(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat");

                    Console.WriteLine("Ученик удалён");

                    Console.ReadKey();

                    adminsD();

                }

                else

                {

                    Console.WriteLine("Такого ученика нету");

                    Console.ReadKey();

                    adminsD();

                }

            }

            static void nazadD()

            {

                adminP adm = new adminP();

                adm.adminsA();

            }

            static int menuADK()

            {
                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        adminTD(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        adminTD(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void adminTD(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[3]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

        }

        struct state1

        {

            public string name1;

            public string name21;

            public string pred11;

            public string pred21;

            public state1(string a1, string b1, string c1, string d1)

            {

                name1 = a1;

                name21 = b1;

                pred11 = c1;

                pred21 = d1;

            }

        }

        class adminInfo

        {

            static string[] admin = new string[] { "Сделай выбор оперции, что бы поддтвердить нажми - Enter\n", "1: Добавить журнал", "2: Добавить преподавателя и его дисциплины", "3: Добавить студента и его оценки", "4: Вернуться в меню" };

            public void adminI()

            {

                menushka();

            }

            static void menushka()

            {

                admins();

            }

            static void adminT(int i)//Замена цвета менющки

            {

                if (i == 1)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                }

                if (i == 2)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[3]);

                    Console.WriteLine(admin[4]);

                }

                if (i == 3)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                    Console.WriteLine(admin[4]);

                }

                if (i == 4)

                {

                    Console.Clear();

                    Console.WriteLine(admin[0]);

                    Console.WriteLine(admin[1]);

                    Console.WriteLine(admin[2]);

                    Console.WriteLine(admin[3]);

                    Console.BackgroundColor = ConsoleColor.Blue;

                    Console.ForegroundColor = ConsoleColor.Green;

                    Console.WriteLine(admin[4]);

                    Console.BackgroundColor = ConsoleColor.Black;

                    Console.ForegroundColor = ConsoleColor.Gray;

                }

            }

            static int adminK()//работа менюшки

            {

                int numA = 0;

                bool flag = false;

                do

                {

                    ConsoleKeyInfo keyPushed = Console.ReadKey();

                    if (keyPushed.Key == ConsoleKey.DownArrow)

                    {

                        numA++;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.UpArrow)

                    {

                        numA--;

                        adminT(numA);

                    }

                    if (keyPushed.Key == ConsoleKey.Enter)

                    {

                        flag = true;

                    }

                } while (!flag);

                return numA;

            }

            static void admins()

            {

                Console.Clear();

                foreach (string textA in admin)

                    Console.WriteLine(textA);

                int numA = adminK();//вызов менюшки

                switch (numA)

                {

                    case 1: { Console.Clear(); addzhurnal(); }; break;

                    case 2: { Console.Clear(); addprepod(); } break;

                    case 3: { Console.Clear(); adduche(); } break;

                    case 4: { Console.Clear(); nazad(); }; break;

                }

            }

            static void nazad()

            {

                adminP adm = new adminP();

                adm.adminsA();

            }

            static void adduche()

            {

                Console.WriteLine("Введите название группы");

                string name = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + ".dat"))

                {

                    Console.WriteLine("Введите имя ученика");

                    string nameS = Console.ReadLine();

                    Console.WriteLine("Введите фамилию ученика");

                    string name2S = Console.ReadLine();

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat"))

                    {

                        Console.WriteLine("Такой ученик уже существует!");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        Console.WriteLine("У нас есть 4 предмета - русский, математика, английский, физика");

                    Console.WriteLine("Введите Оценку ученика за русский");

                    int n = Convert.ToInt32(Console.ReadLine());

                    if (n < 0 || n > 5)

                    {

                        Console.WriteLine("У нас 5 бальная система");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        Console.WriteLine("Введите оценку ученика за математику");

                    int n1 = Convert.ToInt32(Console.ReadLine());

                    if (n1 < 0 || n1 > 5)

                    {

                        Console.WriteLine("У нас 5 бальная система");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        Console.WriteLine("Введите оценку ученика за английский");

                    int n2 = Convert.ToInt32(Console.ReadLine());

                    if (n2 < 0 || n2 > 5)

                    {

                        Console.WriteLine("У нас 5 бальная система");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        Console.WriteLine("Введите оценку ученика за физику");

                    int n3 = Convert.ToInt32(Console.ReadLine());

                    if (n3 < 0 || n3 > 5)

                    {

                        Console.WriteLine("У нас 5 бальная система");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        Console.WriteLine("Введите логин");

                    string log = Console.ReadLine();

                    Console.WriteLine("Введите пароль");

                    string pas = Console.ReadLine();

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat"))

                    {

                        Console.WriteLine("Уже существует такой логин");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        using (BinaryWriter prepod1 = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat", FileMode.OpenOrCreate)))

                        {

                            prepod1.Write(name);

                            prepod1.Write(nameS);

                            prepod1.Write(name2S);

                            prepod1.Close();

                        }

                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                    {

                        zhurnal.Write(name);

                        zhurnal.Write(nameS);

                        zhurnal.Write(name2S);

                        zhurnal.Write(n);

                        zhurnal.Write(n1);

                        zhurnal.Write(n2);

                        zhurnal.Write(n3);

                        zhurnal.Write(log);

                        zhurnal.Write(pas);

                    }

                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + name + nameS + name2S + ".dat", FileMode.OpenOrCreate)))

                    {

                        name = zhurnal.ReadString();

                        nameS = zhurnal.ReadString();
                        name2S = zhurnal.ReadString();

                        n = zhurnal.ReadInt32();

                        n1 = zhurnal.ReadInt32();

                        n2 = zhurnal.ReadInt32();

                        n3 = zhurnal.ReadInt32();

                        log = zhurnal.ReadString();

                        pas = zhurnal.ReadString();

                        Console.WriteLine("Группа: {0} Имя: {1} Фамилия: {2} Русский: {3} Математика: {4} Английский: {5} Физкультура: {6} Логин: {7} Пароль: {8}", name, nameS, name2S, n, n1, n2, n3, log, pas);

                        zhurnal.Close();

                    }

                    Console.WriteLine("Всё записано");

                    Console.ReadKey();

                    admins();

                }

                else

                {

                    Console.WriteLine("Такой группы нету");

                    Console.ReadKey();

                    admins();

                }

                Console.WriteLine();

            }

            static void addzhurnal()

            {

                Console.WriteLine("Введите группу к которой будет прекреплён журнал");

                string gr = Console.ReadLine();

                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + gr + ".dat", FileMode.OpenOrCreate)))

                {

                    zhurnal.Write(gr);

                }

                Console.WriteLine("Вы создали журнал");

                Console.ReadKey();

                admins();

            }

            static void addprepod()

            {

                Console.WriteLine("Введите имя преподавателя");

                string name1 = Console.ReadLine();

                Console.WriteLine("Введите фамилию преподавателя");

                string name21 = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + name1 + name21 + ".dat"))

                {

                    Console.WriteLine("Такой педагог уже существует!");

                    Console.ReadKey();

                    admins();

                }

                else

                    Console.WriteLine("Есть 4 дисциплины: русский, математика, английский, физика");

                Console.WriteLine("Введите 1 дисциплину");

                string pred11 = Console.ReadLine();

                if (pred11 != "математика" && pred11 != "русский" && pred11 != "английский" && pred11 != "физика")

                {

                    Console.WriteLine("Такого предмета нету");

                    Console.ReadKey();

                    admins();

                }

                Console.WriteLine("Введите 2 дисциплину");

                string pred21 = Console.ReadLine();

                if (pred21 != "математика" && pred21 != "русский" && pred21 != "английский" && pred21 != "физика")

                {

                    Console.WriteLine("Такого предмета нету");

                    Console.ReadKey();

                    admins();

                }

                Console.WriteLine("Введи группу к которой будет прекреплён учитель");

                string grup = Console.ReadLine();

                if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + grup + ".dat"))

                {

                    Console.WriteLine("Создайте логин");

                    string log = Console.ReadLine();

                    Console.WriteLine("Создайте пароль");

                    string pas = Console.ReadLine();

                    if (File.Exists(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat"))

                    {

                        Console.WriteLine("Уже существует такой логин");

                        Console.ReadKey();

                        admins();

                    }

                    else

                        using (BinaryWriter prepod1 = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + @"\" + log + ".dat", FileMode.OpenOrCreate)))

                        {

                            prepod1.Write(name1);

                            prepod1.Write(name21);

                            prepod1.Close();

                        }

                    using (BinaryWriter prepod1 = new BinaryWriter(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + name1 + name21 + ".dat", FileMode.OpenOrCreate)))

                    {

                        prepod1.Write(name1);

                        prepod1.Write(name21);

                        prepod1.Write(pred11);

                        prepod1.Write(pred21);

                        prepod1.Write(grup);

                        prepod1.Write(log);

                        prepod1.Write(pas);

                        prepod1.Close();

                    }

                    using (BinaryReader prepod1 = new BinaryReader(File.Open(@"C:\Users\Danik\Desktop\Практические\Практика\Журнал1\Журнал1\файлы\" + name1 + name21 + ".dat", FileMode.Open)))

                    {

                        name1 = prepod1.ReadString();

                        name21 = prepod1.ReadString();

                        pred11 = prepod1.ReadString();

                        pred21 = prepod1.ReadString();

                        grup = prepod1.ReadString();

                        log = prepod1.ReadString();

                        pas = prepod1.ReadString();

                        Console.WriteLine("Имя: {0} Фамилия: {1} Дисцилина 1: {2} Дисциплина 2: {3} Группа: {4} Логин: {5} Пароль {6}", name1, name21, pred11, pred21, grup, log, pas);

                        prepod1.Close();

                    }

                    Console.ReadKey();

                    Console.ReadLine();

                    admins();

                }

                else

                {

                    Console.WriteLine("Такой группы нету");

                    Console.ReadLine();

                    admins();

                }

            }

        }
    }
