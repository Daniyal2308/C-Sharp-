﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalkyl
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            foreach (UIElement el in MainRoot.Children)
            {
                if (el is Button)
                {
                    ((Button)el).Click += Button_Click;
                }
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

            int T = 0;
            string str = (string)((Button)e.OriginalSource).Content;
            if (str == "²√X")
            {
                try
                {
                    textLabel.Text = (Math.Sqrt(Convert.ToDouble(textLabel.Text))).ToString();
                }
                catch { 
                }
            }
            else if (str == "C")
            {
                textLabel.Text = "";


            }
            else if (str == "CE")
            {
                textLabel.Text = "";
            }
            else if (str == "=")
            {
                try {
                    string value = new DataTable().Compute(textLabel.Text, null).ToString();
                    textLabel.Text = value;
            }
                catch
            {
                MessageBox.Show("Вы ввели неккоректное выражение");
            }
        }
            else if (str == "1/x")
            {
                try
                {
                    textLabel.Text = (1 / Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }
            }
            else if (str == "П")
            {
                textLabel.Text = "3.14";
            }
            else if (str == "%")
            {

                try
                {
                    textLabel.Text = (Convert.ToDouble(textLabel.Text) / 100).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }

            }
            else if (str == ",")
            {
                if (textLabel.Text.IndexOf(",") > 0)
                {
                    return;
                }
                textLabel.Text += ".";

            }
            else if (str == "|X|")
            {
                try
                {
                    int t = Convert.ToInt32(textLabel.Text);
                    if (t < 0)
                    {
                        t = t * (-1);
                        textLabel.Text = Convert.ToString(t);
                    }
                }
                catch
                {
                    MessageBox.Show("что-то не так");
                }

            }
            else if (str == "1/X")
            {
                try
                {
                    textLabel.Text = (1 / Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("что-то не так");
                }
            }
            else if (str == "10^x")
            {
                try {
                    textLabel.Text = Convert.ToString(Math.Pow(10, Convert.ToDouble(textLabel.Text)));
                }
                catch
                {
                    MessageBox.Show("Что-то не так");
                }
            }
            else if (str == "log")
            {
                try
                {
                    textLabel.Text = Convert.ToString(Math.Log(Convert.ToDouble(textLabel.Text)));
                }
                catch
                {
                    MessageBox.Show("Что-то не так");
                }
            }
            else if (str == "Sin")
            {
                try
                {
                    textLabel.Text = Convert.ToString(Math.Sin(Convert.ToDouble(textLabel.Text)));
                }
                catch
                {
                    MessageBox.Show("Что-то не так");
                }
            }
            else if (str == "Cos")
            {
                try
                {
                    textLabel.Text = Convert.ToString(Math.Cos(Convert.ToDouble(textLabel.Text)));
                }
                catch
                {
                    MessageBox.Show("Что-то не так");
                }
            }
            else if (str == "e")
            {
                try
                {
                    textLabel.Text = Math.E.ToString();
                }
                catch
                {
                    MessageBox.Show("Что-то не так");
                }
            }
            else if (str == "ln")
            {
                try
                {
                    textLabel.Text = Convert.ToString(Math.Log10(Convert.ToDouble(textLabel.Text)));
                }
                catch
                {
                    MessageBox.Show("Что-то не так");
                }
            }
            else if (str == "x^y")
            {
                try 
            { 
                textLabel.Text += "^";
               
            }
                catch
            {
                MessageBox.Show("что-то не то");
            }
        }


            else if (str == "-")
            {

                if (textLabel.Text == "0" || textLabel.Text == "")
                {
                    textLabel.Text += "-";

                }
                else
                {
                    textLabel.Text += "-";

                }
            }
            else if (str == "←")
            {
                if (textLabel.Text.Length - 1 == 0)
                {
                    textLabel.Text = "0";
                }
                else
                {
                    try
                    {
                        textLabel.Text = textLabel.Text.Substring(0, textLabel.Text.Length - 1);
                    }
                    catch
                    {
                        MessageBox.Show("Нечего стирать");
                    }
                }

            }
            else if (str == "²√x")
            {
                try
                {
                    textLabel.Text = (Math.Sqrt(Convert.ToDouble(textLabel.Text))).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }

            }
            else if (str == "x²")
            {
                try
                {
                    textLabel.Text = (Convert.ToDouble(textLabel.Text) * Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }
            }
            else if (str == "+/-")
            {
                try
                {
                    textLabel.Text = (-Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("Что-то пошло не так");
                }
            }
            else
            {

                textLabel.Text += str;
            }

        }

        private void Obichniy_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow a = new MainWindow();
            a.Show();
        }

        private void programmis12t_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Window2 b= new Window2();
            b.Show();
        }

        
    }
}
