﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kalkyl
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {

            InitializeComponent();

            foreach (UIElement el in mainRoot.Children)
            {
                if (el is Button)
                {
                    ((Button)el).Click += Button_Click;
                }
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string str = (string)((Button)e.OriginalSource).Content;
            if (str == "С")
            {
                textLabel.Text = "";


            }
            else if (str == "CE")
            {
                textLabel.Text = "";
            }
            else if (str == "=")
            {
                try
                {
                    
                    string value = new DataTable().Compute(textLabel.Text, null).ToString();
                    textLabel.Text = value;
                    
                }
                catch
                {
                    MessageBox.Show("Вы ввели неккоректное выражение");
                }
            }
            else if (str == "1/x")
            {
                try
                {
                    textLabel.Text = (1 / Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }
            }
            else if (str == "%")
            {

                try
                {
                    textLabel.Text = (Convert.ToDouble(textLabel.Text) / 100).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }

            }
            else if (str == ",")
            {
                if (textLabel.Text.IndexOf(",") > 0)
                {
                    return;
                }
                textLabel.Text += ".";

            }
            else if (str == "1/x")
            {

                textLabel.Text = (1 / Convert.ToDouble(textLabel.Text)).ToString();

            }
            else if (str == "-")
            {

                if (textLabel.Text == "0" || textLabel.Text == "")
                {
                    textLabel.Text += "-";

                }
                else
                {
                    textLabel.Text += "-";

                }
            }
            else if (str == "←")
            {
                if (textLabel.Text.Length - 1 == 0)
                {
                    textLabel.Text = "0";
                }
                else
                {
                    try
                    {
                        textLabel.Text = textLabel.Text.Substring(0, textLabel.Text.Length - 1);
                    }
                    catch
                    {
                        MessageBox.Show("Нечего стирать");
                    }
                }

            }
            else if (str == "²√x")
            {
                try
                {
                    textLabel.Text = (Math.Sqrt(Convert.ToDouble(textLabel.Text))).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }

            }
            else if (str == "x²")
            {
                try
                {
                    textLabel.Text = (Convert.ToDouble(textLabel.Text) * Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("Вы не ввели число");
                }
            }
            else if (str == "+/-")
            {
                try
                {
                    textLabel.Text = (-Convert.ToDouble(textLabel.Text)).ToString();
                }
                catch
                {
                    MessageBox.Show("Что-то пошло не так");
                }
            }
            else
            {

                textLabel.Text += str;
            }

        }

        private void injenersiy_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Window1 d = new Window1();
            d.Show();

        }

        private void Obitsniy_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow d = new MainWindow();
            d.Show();

        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

            try
            {
                int i = Convert.ToInt32(textLabel.Text);
                TextBlick2.Text = Convert.ToString(i, 16);
            }
            catch
            { 
                TextBlick2.Text = textLabel.Text;
            }
        }

        private void _8_Checked(object sender, RoutedEventArgs e)
        {
            
            try
            {

                string value = new DataTable().Compute(textLabel.Text, null).ToString();
                textLabel.Text = value;
                try
                {
                    int i = Convert.ToInt32(textLabel.Text);
                    TextBlick2.Text = Convert.ToString(i, 8);
                }
                catch
                {
                    MessageBox.Show("не то");
                }

            }
            catch
            {
                MessageBox.Show("Вы ввели неккоректное выражение");
            }
        }

        private void _2_Checked(object sender, RoutedEventArgs e)
        {
            
                
            try
            {

                string value = new DataTable().Compute(textLabel.Text, null).ToString();
                textLabel.Text = value;
                try
                {
                    int i = Convert.ToInt32(textLabel.Text);
                    TextBlick2.Text = Convert.ToString(i, 2);
                }
                catch
                {
                    MessageBox.Show("не то");
                }

            }
            catch
            {
                MessageBox.Show("Вы ввели неккоректное выражение");
            }

        }
    }
}
