﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Tancontrolll
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        int y = 0;
        byte a, r, g, b;
        byte c, q, s, t;

        

        string put;

        

        public Window3()
        {
            InitializeComponent();
            
        }

        private void BackGr_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
                y++;
            if (y > 1)
            {
                Bt.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(BackGr.SelectedColor.Value.A, BackGr.SelectedColor.Value.R, BackGr.SelectedColor.Value.G, BackGr.SelectedColor.Value.B)));
                this.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(BackGr.SelectedColor.Value.A, BackGr.SelectedColor.Value.R, BackGr.SelectedColor.Value.G, BackGr.SelectedColor.Value.B)));
                a = BackGr.SelectedColor.Value.A;
                r = BackGr.SelectedColor.Value.R;
                g = BackGr.SelectedColor.Value.G;
                b = BackGr.SelectedColor.Value.B;
                put = "";
                Put.Content = "";
            }
        }

        private void FontGr_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            y++;
                if (y > 2)
            {
                Bt.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(FontGr.SelectedColor.Value.A, FontGr.SelectedColor.Value.R, FontGr.SelectedColor.Value.G, FontGr.SelectedColor.Value.B)));
                CvetF.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(FontGr.SelectedColor.Value.A, FontGr.SelectedColor.Value.R, FontGr.SelectedColor.Value.G, FontGr.SelectedColor.Value.B)));
                CvetT.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(FontGr.SelectedColor.Value.A, FontGr.SelectedColor.Value.R, FontGr.SelectedColor.Value.G, FontGr.SelectedColor.Value.B)));
                Tem.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(FontGr.SelectedColor.Value.A, FontGr.SelectedColor.Value.R, FontGr.SelectedColor.Value.G, FontGr.SelectedColor.Value.B)));
                c = FontGr.SelectedColor.Value.A;
                q = FontGr.SelectedColor.Value.R;
                s = FontGr.SelectedColor.Value.G;
                t = FontGr.SelectedColor.Value.B;
            }
        }

        private void Use_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow window = new MainWindow(a,r,g,b,c,q,s,t,put);
            window.ShowDialog();
        }
        private void Load_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
        "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
        "Portable Network Graphic (*.png)|*.png"; ; //фильтрация файлов, только текстовые документы
            openFileDialog.InitialDirectory = @"C:\"; //открывает выбранный путь по умолчанию.
            if (openFileDialog.ShowDialog() == true)
            {
                Put.Content = openFileDialog.FileName;
                put = Put.Content.ToString();
            }
            try
            {
                var brush = new ImageBrush();
                brush.ImageSource = new BitmapImage(new Uri(put));
                this.Background = brush;
                
                //Bt.Content = "Вперед";
            }
            catch { }
        }
        private void Def_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow window = new MainWindow();
            window.ShowDialog();
        }
    }
}
