﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

using System.IO;
using mshtml;

namespace Tancontrolll
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        private ObservableCollection<WB> wBs = new ObservableCollection<WB>();
        public MainWindow()
        {
            InitializeComponent();
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = "http://mail.ru" });
            if (!(Directory.Exists(Directory.GetCurrentDirectory() + @"\History")))
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + @"\History");
            }
        }
        public MainWindow(byte a, byte r, byte g, byte b, byte c, byte q, byte s, byte t, string put)
        {
            InitializeComponent();
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = "http://mail.ru" });
            if (!(Directory.Exists(Directory.GetCurrentDirectory() + @"\History")))
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + @"\History");
            }
            //tb.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            //tb.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));

           /* Bt.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            btnADD.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            btnGo.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            btnBack.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            Design.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            Print.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            Privatka.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            Dubl.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            close.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            closeAll.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            History.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            //txtUrl.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            txtUrl.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            Refres.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            btnBack.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            Bt.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));
            this.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            tc1.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            tc1.SetCurrentValue(Control.ForegroundProperty, new SolidColorBrush(Color.FromArgb(c, q, s, t)));

            Bt.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            btnADD.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            btnGo.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            btnBack.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            Design.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            Print.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            Privatka.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            Dubl.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            close.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            closeAll.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            History.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));
            Refres.SetCurrentValue(Control.BackgroundProperty, new SolidColorBrush(Color.FromArgb(a, r, g, b)));*/
            try
            {
                IB.ImageSource = new BitmapImage(new Uri(put, UriKind.Relative));
                var brush = new ImageBrush();
                brush.ImageSource = new BitmapImage(new Uri(put));
                //txtUrl.Background = brush;
               /*Bt.Foreground = Brushes.Transparent;
                btnADD.Foreground = Brushes.Transparent;
                btnGo.Background = null;
                btnBack.Background = null;
                Design.Background = null;
                Print.Background = null;
                Privatka.Background = null;
                Dubl.Background = null;
                close.Background = null;
                closeAll.Background = null;
                History.Background = null;
                Refres.Background = null;
                tc1.Background = null; */
                //tc1.SetCurrentValue(Control.BackgroundProperty, brush);
                //tc1.SetCurrentValue(Control.ForegroundProperty, brush);
                this.Background = brush;
            }
            catch { }
        }

        private void btnADD_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(tc1.SelectedIndex.ToString());
            TabItem tabItem = new TabItem();

            tabItem.Width = 150;
            tc1.Items.Add(tabItem);
            tc1.SelectedIndex = tc1.Items.Count - 1;
            wbSample.Navigate($"http://google.com");
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = "http://google.com" });
            txtUrl.Text = "http://google.com";


            DateTime date1 = new DateTime();
            string name = (DateTime.Now).ToString();
            name = name.Replace(" ", "");
            name = name.Replace(':', '.');
            using (BinaryWriter writer = new BinaryWriter(File.Open(Directory.GetCurrentDirectory() + $@"\History\{name}", FileMode.Create)))
            {
                writer.Write(DateTime.Now + " " + txtUrl.Text);
            }
        }
        private void btnGo_Click(object sender, RoutedEventArgs e)
        {

            //изменение в коллекции данных
            try
            {
                DateTime date1 = new DateTime();
                wBs[tc1.SelectedIndex].WebB = $"{txtUrl.Text}";
                wbSample.Navigate($"{txtUrl.Text}");
                string name = (DateTime.Now).ToString();
                name = name.Replace(" ", "");
                name = name.Replace(':', '.');
                using (BinaryWriter writer = new BinaryWriter(File.Open(Directory.GetCurrentDirectory() + $@"\History\{name}", FileMode.Create)))
                {
                    writer.Write(DateTime.Now + " " + txtUrl.Text);
                }

            }
            catch
            {
                try
                {
                    DateTime date1 = new DateTime();
                    wBs[tc1.SelectedIndex].WebB = $"{txtUrl.Text}";
                    wbSample.Navigate($"http://{txtUrl.Text}.ru");
                    txtUrl.Text = $"http://{txtUrl.Text}.ru";
                    string name = (DateTime.Now).ToString();
                    name = name.Replace(" ", "");
                    name = name.Replace(':', '.');
                    using (BinaryWriter writer = new BinaryWriter(File.Open(Directory.GetCurrentDirectory() + $@"\History\{name}", FileMode.Create)))
                    {
                        writer.Write(DateTime.Now + " " + txtUrl.Text);
                    }
                }
                catch { }
            }


        }


        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ((wbSample != null) && (wbSample.CanGoBack));
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            wbSample.GoBack();
            txtUrl.Text = $"{wbSample.Source}";
        }

        private void CommandBinding_CanExecute_1(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ((wbSample != null) && (wbSample.CanGoForward));
        }

        private void CommandBinding_Executed_1(object sender, ExecutedRoutedEventArgs e)
        {
            wbSample.GoForward();
            txtUrl.Text = $"{wbSample.Source}";
        }

        private void Button_Refresh(object sender, RoutedEventArgs e)
        {
            try
            {
                wbSample.Refresh();
            }
            catch { }
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int a = tc1.SelectedIndex;
                if (a > 0)
                {
                    tc1.SelectedIndex = a - 1;
                    tc1.Items.RemoveAt(a);
                    wBs.RemoveAt(a);
                }
            }
            catch { }

            // tc1.SelectedIndex = tc1.Items.Count - 1;
        }

        private void closeAll_Click(object sender, RoutedEventArgs e)
        {
            TabItem tabItem = new TabItem();
            tc1.SelectedIndex = tc1.Items.Count - 1;
            while (tc1.SelectedIndex > 0 && (bool)(tabItem.Tag = true))
            {
                if ((bool)(tabItem.Tag = true))
                {
                    int a = tc1.SelectedIndex;
                    tc1.SelectedIndex = a - 1;
                    if ((bool)(tabItem.Tag = true))
                    {
                        tc1.Items.RemoveAt(a);
                        wBs.RemoveAt(a);
                    }
                }
            }



        }
        private void tc1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                wbSample.Navigate(wBs[tc1.SelectedIndex].WebB);
                txtUrl.Text = $"{wBs[tc1.SelectedIndex].WebB}";
            }
            catch { }
        }
        public class WB : INotifyPropertyChanged
        {
            public int index { get; set; }
            private string web;



            public string WebB
            {
                get
                {
                    return this.web;
                }
                set
                {
                    if (this.web != value)
                    {
                        this.web = value;
                        this.NotifyPropertyChanged("WebB");
                    }

                }
            }
            public event PropertyChangedEventHandler PropertyChanged;
            public void NotifyPropertyChanged(string propName)
            {
                if (this.PropertyChanged != null)
                    this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }

        private void Dubl_Click(object sender, RoutedEventArgs e)
        {
            if (wbSample.Source != null)
            {
                TabItem tabItem = new TabItem();
                tabItem.Width = 150;
                tc1.Items.Add(tabItem);
                tc1.SelectedIndex = tc1.Items.Count - 1;
                wbSample.Navigate(wbSample.Source);
                wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = wbSample.Source.OriginalString });
                txtUrl.Text = wbSample.Source.OriginalString;


                DateTime date1 = new DateTime();
                string name = (DateTime.Now).ToString();
                name = name.Replace(" ", "");
                name = name.Replace(':', '.');
                using (BinaryWriter writer = new BinaryWriter(File.Open(Directory.GetCurrentDirectory() + $@"\History\{name}", FileMode.Create)))
                {
                    writer.Write(DateTime.Now + " " + txtUrl.Text);
                }
            }
            else { }
        }

        private void History_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.ShowDialog();
        }
        public void Printt()
        {

        }
        private void Print_Click(object sender, RoutedEventArgs e)
        {
            var doc = wbSample.Document as IHTMLDocument2;
            if (doc != null)
            {
                doc.execCommand("Print", true, 0);
                return;
            }
        }

        private void Privatka_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Window2 window2 = new Window2();
            window2.ShowDialog();

        }

        private void Design_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Window3 window3 = new Window3();
            window3.ShowDialog();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void wbSample_Navigated(object sender, NavigationEventArgs e)
        {
            try
            {
                txtUrl.Text = wbSample.Source.OriginalString;
                TabItem tabItem = (TabItem)(tc1.SelectedItem as TabItem);
                //if (tabItem != null)
                tabItem.Header = wbSample.Source.OriginalString;
                wBs[tc1.SelectedIndex].WebB = wbSample.Source.OriginalString;
                DateTime date1 = new DateTime();
                string name = (DateTime.Now).ToString();
                name = name.Replace(" ", "");
                name = name.Replace(':', '.');
                using (BinaryWriter writer = new BinaryWriter(File.Open(Directory.GetCurrentDirectory() + $@"\History\{name}", FileMode.Create)))
                {
                    writer.Write(DateTime.Now + " " + txtUrl.Text);
                }
            }
            catch { }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            TabItem tabItem = new TabItem();
            tabItem.Width = 150;
            tc1.Items.Add(tabItem);
            tc1.SelectedIndex = 0;
            tabItem.Tag = true;
            wbSample.Navigate(wbSample.Source);
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = wbSample.Source.OriginalString });
            txtUrl.Text = wbSample.Source.OriginalString;
            tc1.Items.RemoveAt(tc1.Items.Count-1);
            wBs.RemoveAt(tc1.Items.Count-1);

        }

       
    }
}

