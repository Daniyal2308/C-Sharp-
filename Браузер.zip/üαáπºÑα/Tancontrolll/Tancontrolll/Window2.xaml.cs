﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

using System.IO;

namespace Tancontrolll
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private ObservableCollection<WB> wBs = new ObservableCollection<WB>();
        public Window2()
        {
            InitializeComponent();
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = "http://google.com" });
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow window = new MainWindow();
            window.ShowDialog();
            

        }
        private void btnADD_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(tc1.SelectedIndex.ToString());
            tc1.Items.Add("");
            tc1.SelectedIndex = tc1.Items.Count - 1;
            wbSample.Navigate($"http://google.com");
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = "http://google.com" });
            txtUrl.Text = "http://google.com";
            DateTime date1 = new DateTime();
            string name = (DateTime.Now).ToString();
            name = name.Replace(" ", "");
            name = name.Replace(':', '.');
        }
        private void btnGo_Click(object sender, RoutedEventArgs e)
        {
                wBs[tc1.SelectedIndex].WebB = $"{txtUrl.Text}";
                wbSample.Navigate($"{txtUrl.Text}");
        }
        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ((wbSample != null) && (wbSample.CanGoBack));
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            wbSample.GoBack();
            txtUrl.Text = $"{wbSample.Source}";
        }

        private void CommandBinding_CanExecute_1(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ((wbSample != null) && (wbSample.CanGoForward));
        }

        private void CommandBinding_Executed_1(object sender, ExecutedRoutedEventArgs e)
        {
            wbSample.GoForward();
            txtUrl.Text = $"{wbSample.Source}";
        }

        private void Button_Refresh(object sender, RoutedEventArgs e)
        {
            wbSample.Refresh();
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            int a = tc1.SelectedIndex;
            try
            {
                if (a != 0)
                {
                    tc1.SelectedIndex = a - 1;
                    tc1.Items.RemoveAt(a);
                    wBs.RemoveAt(a);
                }
            }
            catch { }
            // tc1.SelectedIndex = tc1.Items.Count - 1;
        }

        private void closeAll_Click(object sender, RoutedEventArgs e)
        {
            tc1.SelectedIndex = tc1.Items.Count - 1;
            while (tc1.SelectedIndex != 0)
            {
                int a = tc1.SelectedIndex;
                tc1.SelectedIndex = a - 1;
                tc1.Items.RemoveAt(a);
                wBs.RemoveAt(a);
            }



        }
        private void tc1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            wbSample.Navigate(wBs[tc1.SelectedIndex].WebB);
            txtUrl.Text = $"{wBs[tc1.SelectedIndex].WebB}";
        }
        public class WB : INotifyPropertyChanged
        {
            public int index { get; set; }
            private string web;



            public string WebB
            {
                get
                {
                    return this.web;
                }
                set
                {
                    if (this.web != value)
                    {
                        this.web = value;
                        this.NotifyPropertyChanged("WebB");
                    }

                }
            }
            public event PropertyChangedEventHandler PropertyChanged;
            public void NotifyPropertyChanged(string propName)
            {
                if (this.PropertyChanged != null)
                    this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }

        private void Dubl_Click(object sender, RoutedEventArgs e)
        {
            tc1.Items.Add("");
            tc1.SelectedIndex = tc1.Items.Count - 1;
            wbSample.Navigate($"{wbSample.Source}");
            wBs.Add(new WB() { index = tc1.SelectedIndex, WebB = $"{wbSample.Source}" });
        }

        
    }
}
