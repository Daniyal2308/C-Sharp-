﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Collections;
using System.Threading;

namespace Tancontrolll
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            //Thread myThread = new Thread(new ThreadStart(Count));

            // myThread.Start();
            string[] Allfile = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\History");
            try
            {
                foreach (string namefile in Allfile)
                {
                    string result = System.IO.Path.GetFileName(namefile);
                    using (BinaryReader reader = new BinaryReader(File.Open(Directory.GetCurrentDirectory() + $@"\History\" + result, FileMode.Open)))
                    {
                        History.Items.Add(reader.ReadString());
                    }
                }
            }
            catch { }
        }

        private void ClearAll_Click(object sender, RoutedEventArgs e)
        {
            History.Items.Clear();
            string[] Allfile = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\History");
            try
            {
                foreach (string namefile in Allfile)
                {
                    string result = System.IO.Path.GetFileName(namefile);
                    System.IO.File.Delete(Directory.GetCurrentDirectory() + $@"\History\" + result);
                }
            }
            catch { }
        }

        private void DelBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<string> numbers = new List<string>();
                string[] Allfile = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\History");
                try
                {
                    foreach (string namefile in Allfile)
                    {
                        numbers.Add(System.IO.Path.GetFileName(namefile));
                    }
                }
                catch { }
                System.IO.File.Delete(Directory.GetCurrentDirectory() + $@"\History\" + numbers[History.SelectedIndex]);
                numbers.RemoveAt(History.SelectedIndex);
                History.Items.Remove(History.SelectedItem);
            }
            catch { }

        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            string[] Allfile = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\History");
            try
            {
                foreach (string namefile in Allfile)
                {
                    string result = System.IO.Path.GetFileName(namefile);
                    using (BinaryReader reader = new BinaryReader(File.Open(Directory.GetCurrentDirectory() + $@"\History\" + result, FileMode.Open)))
                    {
                        History.Items.Add(reader.ReadString());
                    }
                }
            }
            catch { }
        }
        //public void Count()
        //{
        //M:
        //    string[] Allfile = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\History");
        //    try
        //    {
        //        foreach (string namefile in Allfile)
        //        {
        //            string result = System.IO.Path.GetFileName(namefile);
        //            using (BinaryReader reader = new BinaryReader(File.Open(Directory.GetCurrentDirectory() + $@"\History\" + result, FileMode.Open)))
        //            {
        //                History.Items.Add(reader.ReadString());
        //            }
        //        }
        //    }
        //    catch { }
        //    Thread.Sleep(3000);
        //    goto M;
        //    }
    }
}
