﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading;

namespace ConsoleApp17
{ }
class admin
{
    static string[] texts = new string[] { "МАГАЗИН\n",
        "Админестратор\n", "1: Создать", "2: Редактировать", "3: Удалить", "4: Просмотреть", "5: Выход" };
    public void admins()
    {
        Console.Clear();
        adminN();
    }
    static void adminN()
    {
        menu();
    }
    static void create()
    {
        Console.Clear();
        AdminCreate adm = new AdminCreate();
        adm.admi();
    }
    static void cha()
    {
        Console.Clear();
        adminCh adm = new adminCh();
        adm.adminChan();
    }
    static void pro()
    {
        Console.Clear();
        adminget adm = new adminget();
        adm.getI();
    }
    static void admindel()
    {
        Console.Clear();
        admingek adm = new admingek();
        adm.admink();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { create(); }; break;
            case 2: { cha(); } break;
            case 3: { admindel(); } break;
            case 4: { pro(); }; break;
            case 5: { vixod(); }; break;
            case 6: { }; break;
        }
    }
    static void vixod()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[5]);
        }
        if (i == 5)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[5]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 5;
                Text(5);
            }
            if (num == 6)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class adminCh
{
    public void adminChan()
    {
        menu();
    }
    static string[] texts = new string[] { "Админестратор\n", "1: Изменить человека, не принятого в сеть", "2: Изменить данные уже принятого человека в сеть", "3: Взять на работу", "4: Выход" };
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { chChel(); }; break;
            case 2: { chProf(); } break;
            case 3: { vzat(); } break;
            case 4: { nazad(); }; break;
            case 5: { }; break;
        }
    }
    static void vzat()
    {
        Console.Clear();
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\люди\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Человек - его ID: " + Path.GetFileNameWithoutExtension(files.FullName));
        }
        Console.WriteLine("Введите ID человека чтобы принять его на работу");
        string log1 = Console.ReadLine();
        if (File.Exists(@"C:\Debug\люди\" + log1 + ".dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log1 + ".dat", FileMode.Open)))
            {
                log = zhurnal.ReadString();
                pas = zhurnal.ReadString();
                mest = zhurnal.ReadString();
                dol = zhurnal.ReadString();
                obr = zhurnal.ReadString();
                secname = zhurnal.ReadString();
                name = zhurnal.ReadString();
                god = zhurnal.ReadInt32();
                zhurnal.Close();
            }
        tru:
            Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
            Console.WriteLine("Введите для него должность");


            string dolzh = Console.ReadLine();

            DateTime date = DateTime.Today;
            string datas = Convert.ToString(date);

            if (dolzh == "кладовщик")
            {
                string mestKL = "сеть";
                int zarp = 30000;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log1 + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mestKL);
                    zhurnal.Write(dolzh);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zarp);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else if (dolzh == "кадры")
            {
                string mestKL = "сеть";
                int zarp = 34000;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log1 + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mestKL);
                    zhurnal.Write(dolzh);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zarp);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else if (dolzh == "бухгалтер")
            {
                string mestKL = "сеть";
                int zarp = 36000;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log1 + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mestKL);
                    zhurnal.Write(dolzh);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zarp);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else if (dolzh == "кассир")
            {
            try3:
                int l = 0;
                DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                foreach (FileInfo files in die2.GetFiles("*.dat"))
                {
                    Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); l++;
                }
                if (l == 0)
                {
                    Console.WriteLine("Магазинов ещё нету");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере магазин для него");
                string nameM = Console.ReadLine();
                if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
                {
                    int zarp = 20000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + log1 + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(nameM);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zarp);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + log1 + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(nameM);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zarp);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такого магазина нету");
                    Console.ReadKey();
                    Console.Clear();
                    goto try3;
                }
            }
            else
            {
                Console.WriteLine("Такой должности нету");
                Console.ReadKey();
                Console.Clear();
                goto tru;

            }
        }
        else
        {
            Console.WriteLine("Такого человека нету");
            Console.ReadKey();
            menu();
        }
    }
    static string log, pas, mest, dol, obr, secname, name;
    static int god, zar, dd;
    static void chProf()
    {
        Console.Clear();
    tru20:
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность");
        string dolzh = Console.ReadLine();
        log = dolzh;
        int a = 0;

        DateTime date = DateTime.Today;
        string datas = Convert.ToString(date);

        if (log == "кладовщик")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету кладовщиков");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выберете сотрудника по ID: ");
            log = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которые мы имеем");
            da:
                Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                try
                {
                    Console.WriteLine("Введите должность");
                    dol = Console.ReadLine();

                    if (dol == "кладовщик")
                    {
                        mest = "сеть";
                        zar = 30000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dolzh);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }
                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "кадры")
                    {
                        mest = "сеть";
                        zar = 34000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dolzh);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "бухгалтер")
                    {
                        mest = "сеть";
                        zar = 36000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dolzh);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "кассир")
                    {
                    try3:
                        int l = 0;
                        DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                        foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                        {
                            Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                        }
                        if (l == 0)
                        {
                            Console.WriteLine("Магазинов ещё нету");
                            Console.ReadKey();
                            goto tru20;
                        }
                        else
                            Console.WriteLine("Выбере магазин для него");
                        mest = Console.ReadLine();
                        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                        {
                            zar = 20000;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(log);
                                zhurnal.Write(pas);
                                zhurnal.Write(mest);
                                zhurnal.Write(dolzh);
                                zhurnal.Write(obr);
                                zhurnal.Write(secname);
                                zhurnal.Write(name);
                                zhurnal.Write(god);
                                zhurnal.Write(zar);
                                zhurnal.Write(datas);
                                zhurnal.Close();
                            }

                            Console.WriteLine("Всё готово");
                            Console.ReadKey();
                            goto obr;
                        }
                        else
                        {
                            Console.WriteLine("Такого магазина нету");
                            Console.ReadKey();

                            goto try3;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Такой должности нету");
                        Console.ReadKey();

                        goto da;

                    }


                obr:
                    Console.WriteLine("Введите новое образование");
                allgood:
                    Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                    string obr1 = Console.ReadLine();
                    if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                    {
                        goto finaly;
                    }
                    else
                    {
                        Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                        Console.ReadKey();
                        goto allgood;
                    }
                finaly:
                    Console.Write("Введите Фамилию: ");
                    secname = Console.ReadLine();
                    Console.Write("Введите имя: ");
                    name = Console.ReadLine();
                dat:
                    try
                    {
                        Console.Write("Введите год рождения: ");
                        god = Convert.ToInt32(Console.ReadLine());
                        if (god < 1960 || god > 2002)
                        {
                            Console.WriteLine("Такую дату нельзя ввести");
                            Console.ReadKey();
                            goto dat;
                        }
                        else
                        {
                            goto allgoodK;
                        }

                    }
                    catch
                    {

                        Console.WriteLine("Вы ввели что-то не так");
                        Console.ReadKey();
                        goto dat;
                    }
                allgoodK:
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dol);
                        zhurnal.Write(obr1);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                        zhurnal.Close();
                    }
                }
                catch
                {
                    Console.WriteLine("Вы что-то ввели не так и произошла ошибка");
                    Console.ReadKey();
                    goto da;
                }
                if (dol == "кладовщик")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                }
                else if (dol == "кадры")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                }
                else if (dol == "бухгалтер")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                }
                else if (dol == "кассир")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\" + log + ".dat");
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет");
                Console.ReadKey();
                goto klad;
            }

        }
        else if (log == "кадры")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету кадров");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выберете сотрудника по ID: ");
            log = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которые мы имеем");
            da:
                Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                Console.WriteLine("Введите должность");
                dol = Console.ReadLine();

                if (dol == "кладовщик")
                {
                    mest = "сеть";
                    zar = 30000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кадры")
                {
                    mest = "сеть";
                    zar = 34000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "бухгалтер")
                {
                    mest = "сеть";
                    zar = 36000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кассир")
                {
                try3:
                    int l = 0;
                    DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                    foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                    {
                        Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                    }
                    if (l == 0)
                    {
                        Console.WriteLine("Магазинов ещё нету");
                        Console.ReadKey();
                        goto try3;
                    }
                    else
                        Console.WriteLine("Выбере магазин для него");
                    mest = Console.ReadLine();
                    if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                    {
                        zar = 20000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else
                    {
                        Console.WriteLine("Такого магазина нету");
                        Console.ReadKey();

                        goto try3;
                    }
                }
                else
                {
                    Console.WriteLine("Такой должности нету");
                    Console.ReadKey();

                    goto da;

                }
            obr:
                Console.WriteLine("Введите новое образование");
            allgood:
                Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                string obr1 = Console.ReadLine();
                if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                {
                    goto finaly;
                }
                else
                {
                    Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                    Console.ReadKey();
                    goto allgood;
                }
            finaly:
                Console.Write("Введите Фамилию: ");
                secname = Console.ReadLine();
                Console.Write("Введите имя: ");
                name = Console.ReadLine();
            dat:
                try
                {
                    Console.Write("Введите год рождения: ");
                    god = Convert.ToInt32(Console.ReadLine());
                    if (god < 1960 || god > 2002)
                    {
                        Console.WriteLine("Такую дату нельзя ввести");
                        Console.ReadKey();
                        goto dat;
                    }
                    else
                    {
                        goto allgoodK;
                    }

                }
                catch
                {

                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    goto dat;
                }
            allgoodK:
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mest);
                    zhurnal.Write(dol);
                    zhurnal.Write(obr1);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zar);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                if (dol == "кладовщик")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                }
                else if (dol == "кадры")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                }
                else if (dol == "бухгалтер")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                }
                else if (dol == "кассир")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\" + log + ".dat");
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (log == "бухгалтер")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету бухгалтера");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выберете сотрудника по ID: ");
            log = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которые мы имеем");
            da:
                Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                Console.WriteLine("Введите должность");
                dol = Console.ReadLine();

                if (dol == "кладовщик")
                {
                    mest = "сеть";
                    zar = 30000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кадры")
                {
                    mest = "сеть";
                    zar = 34000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "бухгалтер")
                {
                    mest = "сеть";
                    zar = 36000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кассир")
                {
                try3:
                    int l = 0;
                    DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                    foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                    {
                        Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                    }
                    if (l == 0)
                    {
                        Console.WriteLine("Магазинов ещё нету");
                        Console.ReadKey();
                        goto try3;
                    }
                    else
                        Console.WriteLine("Выбере магазин для него");
                    mest = Console.ReadLine();
                    if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                    {
                        zar = 20000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else
                    {
                        Console.WriteLine("Такого магазина нету");
                        Console.ReadKey();

                        goto try3;
                    }
                }
                else
                {
                    Console.WriteLine("Такой должности нету");
                    Console.ReadKey();

                    goto da;

                }
            obr:
                Console.WriteLine("Введите новое образование");
            allgood:
                Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                string obr1 = Console.ReadLine();
                if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                {
                    goto finaly;
                }
                else
                {
                    Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                    Console.ReadKey();
                    goto allgood;
                }
            finaly:
                Console.Write("Введите Фамилию: ");
                secname = Console.ReadLine();
                Console.Write("Введите имя: ");
                name = Console.ReadLine();
            dat:
                try
                {
                    Console.Write("Введите год рождения: ");
                    god = Convert.ToInt32(Console.ReadLine());
                    if (god < 1960 || god > 2002)
                    {
                        Console.WriteLine("Такую дату нельзя ввести");
                        Console.ReadKey();
                        goto dat;
                    }
                    else
                    {
                        goto allgoodK;
                    }

                }
                catch
                {

                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    goto dat;
                }
            allgoodK:
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mest);
                    zhurnal.Write(dol);
                    zhurnal.Write(obr1);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zar);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                if (dol == "кладовщик")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                }
                else if (dol == "кадры")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                }
                else if (dol == "бухгалтер")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                }
                else if (dol == "кассир")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\" + log + ".dat");
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (log == "кассир")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету магазинов");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере магазин: ");
            mest = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + ".dat"))
            {
            sotr:
                DirectoryInfo db = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\");
                foreach (FileInfo da in db.GetFiles())
                {
                    Console.WriteLine("ID сотрудника: " + Path.GetFileNameWithoutExtension(da.FullName)); a++;
                }

                log = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat"))
                {
                    Console.Clear();
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Это те данные, которыми он сейчас обладает");
                    Console.WriteLine("Вводим должности, место работы и зарплата определится автоматически");
                tru:
                    Console.Clear();
                    Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                    Console.WriteLine("Введите для него должность");
                    dol = Console.ReadLine();

                    if (dol == "кладовщик")
                    {
                        mest = "сеть";
                        zar = 30000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }
                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "кадры")
                    {
                        mest = "сеть";
                        zar = 34000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "бухгалтер")
                    {
                        mest = "сеть";
                        zar = 36000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "кассир")
                    {
                    try3:
                        int l = 0;
                        DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                        foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                        {
                            Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                        }
                        if (l == 0)
                        {
                            Console.WriteLine("Магазинов ещё нету");
                            Console.ReadKey();
                            goto tru;
                        }
                        else
                            Console.WriteLine("Выбере магазин для него");
                        mest = Console.ReadLine();
                        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                        {
                            zar = 20000;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(log);
                                zhurnal.Write(pas);
                                zhurnal.Write(mest);
                                zhurnal.Write(dol);
                                zhurnal.Write(obr);
                                zhurnal.Write(secname);
                                zhurnal.Write(name);
                                zhurnal.Write(god);
                                zhurnal.Write(zar);
                                zhurnal.Write(datas);
                                zhurnal.Close();
                            }
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + log + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(log);
                                zhurnal.Write(pas);
                                zhurnal.Write(mest);
                                zhurnal.Write(dol);
                                zhurnal.Write(obr);
                                zhurnal.Write(secname);
                                zhurnal.Write(name);
                                zhurnal.Write(god);
                                zhurnal.Write(zar);
                                zhurnal.Write(datas);
                                zhurnal.Close();
                            }
                            Console.WriteLine("Всё готово");
                            Console.ReadKey();
                            goto obr;
                        }
                        else
                        {
                            Console.WriteLine("Такого магазина нету");
                            Console.ReadKey();

                            goto try3;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Такой должности нету");
                        Console.ReadKey();

                        goto tru;

                    }
                obr:
                    Console.WriteLine("Введите новое образование");
                allgood:
                    Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                    string obr1 = Console.ReadLine();
                    if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                    {
                        goto finaly;
                    }
                    else
                    {
                        Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                        Console.ReadKey();
                        goto allgood;
                    }
                finaly:
                    Console.Write("Введите Фамилию: ");
                    secname = Console.ReadLine();
                    Console.Write("Введите имя: ");
                    name = Console.ReadLine();
                dat:
                    try
                    {
                        Console.Write("Введите год рождения: ");
                        god = Convert.ToInt32(Console.ReadLine());
                        if (god < 1960 || god > 2002)
                        {
                            Console.WriteLine("Такую дату нельзя ввести");
                            Console.ReadKey();
                            goto dat;
                        }
                        else
                        {
                            goto allgoodK;
                        }

                    }
                    catch
                    {

                        Console.WriteLine("Вы ввели что-то не так");
                        Console.ReadKey();
                        goto dat;
                    }
                allgoodK:
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dol);
                        zhurnal.Write(obr1);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                        zhurnal.Close();
                    }
                    if (dol == "кладовщик")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                        File.Delete(@"C:\Debug\СетьМагазиновАхеть\продавец.dat");
                    }
                    else if (dol == "кадры")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                        File.Delete(@"C:\Debug\СетьМагазиновАхеть\продавец.dat");
                    }
                    else if (dol == "бухгалтер")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                        File.Delete(@"C:\Debug\СетьМагазиновАхеть\продавец.dat");
                    }
                    else if (dol == "кассир")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat");
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такого сотрудика нету");
                    Console.ReadKey();
                    goto sotr;
                }
            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                goto klad;
            }

        }
    }
    static void chChel()
    {
        Console.Clear();
        int a = 0;
        DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\люди\");
        foreach (FileInfo files in die2.GetFiles())
        {
            Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Людей ещё нету");
            Console.ReadKey();
            menu();
        }
        else
            Console.Write("Выберете человека по его ID: ");
        log = Console.ReadLine();
        if (File.Exists(@"C:\Debug\люди\" + log + ".dat"))
        {

            goto tr1;
        }
        else
        {
            Console.WriteLine("Такого человека нету");
            Console.ReadKey();
            menu();
        }

    tr1:
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.Open)))
        {
            log = zhurnal.ReadString();
            pas = zhurnal.ReadString();
            mest = zhurnal.ReadString();
            dol = zhurnal.ReadString();
            obr = zhurnal.ReadString();
            secname = zhurnal.ReadString();
            name = zhurnal.ReadString();
            god = zhurnal.ReadInt32();
            zar = zhurnal.ReadInt32();
            Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar, pas);
            zhurnal.Close();
        }
        Console.WriteLine("Это те данные, которыми он сейчас обладает");
        Console.WriteLine("Удалаяем все данные, после нажатия любой кнопки");
        Console.ReadKey();
        File.Delete(@"C:\Debug\люди\" + log + ".dat");
        File.Delete(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat");
    r:
        Console.Clear();
        try
        {
            int gg = 0;
            try
            {
                Console.Write("Введите логин: ");
                log = Console.ReadLine();
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                }
            }
            catch
            {
                goto r;
            }
            for (int i = 0; i < log.Length; i++)
            {
                if (((log[i] >= 'А') && (log[i] <= 'Я')) || ((log[i] >= 'а') && (log[i] <= 'я')) || log[i] == 'ё')
                    gg++;
            }
            if (gg > 0)
            {
                Console.WriteLine();
                Console.WriteLine("Никаких русских символов!");
                Thread.Sleep(2000);
                goto r;
            }
            else
            {

                goto tr;
            }
        }
        catch
        {
            Console.WriteLine("Введите нормально логин");
            Console.ReadKey();
            goto r;
        }
    tr:
        Console.Clear();
        Console.Write("Введите пароль: ");
        pas = Console.ReadLine();
        if (pas.Length < 8)
        {
            Console.WriteLine();
            Console.WriteLine("Длина пароля не соответствует требованиям безопасности");
            Thread.Sleep(2000);
            goto tr;
        }
        int g1 = 0, g2 = 0, g3 = 0, g4 = 0, g5 = 0, g6 = 0, g7 = 0;
        for (int i = 0; i < pas.Length; i++)
        {
            if ((pas[i] >= 'A') && (pas[i] <= 'Z'))
                g1++;
            if (pas[i] == '!' || pas[i] == '@' || pas[i] == '#' || pas[i] == '$' || pas[i] == '%' || pas[i] == '&' || pas[i] == '*')
                g2++;
            if (pas[i] >= '0' && pas[i] <= '9')
                if (((pas[i] >= 'А') && (pas[i] <= 'Я')) || ((pas[i] >= 'а') && (pas[i] <= 'я')) || pas[i] == 'ё')
                    g4++;
            if (pas == null || pas == "")
                g5++;
            if (pas.Contains(" "))
                g6++;
        }
        for (int j = 0; j < pas.Length - 3; j++)
        {
            if (char.IsUpper(pas[j]) && char.IsUpper(pas[j + 1]) && char.IsUpper(pas[j + 2]))
            {
                Console.WriteLine();
                Console.WriteLine("Три заглавных символа в пароле не могут идти подряд, повторите попытку");
                Thread.Sleep(2000);
                goto tr;
            }
            else g7++;
        }
        foreach (char cr in pas)
            if (Char.IsNumber(cr))
                g3++;
        if (g1 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 заглавных буквы!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g2 < 2)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 2 спец. символа!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g3 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 цифры!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g4 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Никаких русских символов!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g5 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Видишь пароль? Нет. И я не вижу, а его не ввели");
            Console.ReadKey();
            goto tr;
        }
        if (g6 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Пароль не должен содержать пробелов");
            Thread.Sleep(2000);
            goto tr;
        }


        else

            try
            {

                Console.Write("Введите Фамилию: ");
                secname = Console.ReadLine();
                Console.Write("Введите имя: ");
                name = Console.ReadLine();
            dat:
                try
                {

                    Console.Write("Введите год рождения: ");
                    god = Convert.ToInt32(Console.ReadLine());
                    if (god < 1960 || god > 2002)
                    {
                        Console.WriteLine("Такую дату нельзя ввести");
                        Console.ReadKey();
                        goto dat;
                    }
                    else
                    {
                        goto tru;
                    }

                }
                catch
                {

                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    goto dat;
                }
            tru:
                obr = "NONE";
                mest = "NONE";
                dol = "NONE";
                zar = 0;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                }
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mest);
                    zhurnal.Write(dol);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zar);
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar, pas);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которыми мы ввели сейчас");
            }
            catch
            {
                Console.WriteLine("Вы что-то ввели не так и система дала ошибку");
                Console.ReadKey();
                menu();
            }
        Console.WriteLine("Всё готово");
        Console.ReadKey();
        menu();

    }

    static void nazad()
    {
        Console.Clear();
        admin adm = new admin();
        adm.admins();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 4;
                Text(4);
            }
            if (num == 5)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class AdminCreate
{
    static string[] texts = new string[] { "Админестратор\n", "1: Создать человека", "2: Создать магазин", "3: Выход" };
    public void admi()
    {
        create();
    }
    static void create()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { createH(); }; break;
            case 2: { creat(); } break;
            case 3: { vixod(); } break;
            case 4: { }; break;
        }
    }
    static void creat()
    {
        Console.Clear();
        try
        {
            Console.WriteLine("Введите название магазина");
            string name = Console.ReadLine();


            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + name))
            {
                Console.WriteLine("Такой магазин с таким название уже есть");
            }
            else
            {
                Console.WriteLine("Начинаю создание..");
                Thread.Sleep(2000);
                DirectoryInfo di = Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\магазины\" + name);
                DirectoryInfo di1 = Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\магазины\" + name + @"\склад");
                DirectoryInfo di2 = Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\магазины\" + name + @"\должность");
                DirectoryInfo di3 = Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\магазины\" + name + @"\продавец");
                File.Create(@"C:\Debug\СетьМагазиновАхеть\магазины\" + name + ".dat");
                Console.WriteLine("Всё готово");
            }
        }
        catch
        {
            Console.WriteLine("Вы что-то сделали не так");
            Console.ReadKey();
            create();
        }
        Console.ReadKey();
        create();
    }
    static string log, pas;
    static int dd;
    static void createH()
    {
    r:
        Console.Clear();
        try
        {
            int gg = 0;
            try
            {
                Console.Write("Введите логин: ");
                log = Console.ReadLine();
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.OpenOrCreate)))
                {

                }
            }
            catch
            {
                Console.WriteLine("Так нельзя");
                Console.ReadKey();
                goto r;
            }
            for (int i = 0; i < log.Length; i++)
            {
                if (((log[i] >= 'А') && (log[i] <= 'Я')) || ((log[i] >= 'а') && (log[i] <= 'я')) || log[i] == 'ё')
                    gg++;
            }
            if (gg > 0)
            {
                Console.WriteLine();
                Console.WriteLine("Никаких русских символов!");
                Thread.Sleep(2000);
                goto r;
            }
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat"))
            {
                Console.WriteLine("Такой человек уже существует!");
                Console.ReadKey();
                goto r;
            }
            else
                goto tr;
        }
        catch
        {
            Console.WriteLine("Введите нормально логин");
            Console.ReadKey();
            goto r;
        }
    tr:
        Console.Clear();
        Console.Write("Введите пароль: ");
        pas = Console.ReadLine();
        if (pas.Length < 8)
        {
            Console.WriteLine();
            Console.WriteLine("Длина пароля не соответствует требованиям безопасности");
            Thread.Sleep(2000);
            goto tr;
        }
        int g1 = 0, g2 = 0, g3 = 0, g4 = 0, g5 = 0, g6 = 0, g7 = 0;
        for (int i = 0; i < pas.Length; i++)
        {
            if ((pas[i] >= 'A') && (pas[i] <= 'Z'))
                g1++;
            if (pas[i] == '!' || pas[i] == '@' || pas[i] == '#' || pas[i] == '$' || pas[i] == '%' || pas[i] == '&' || pas[i] == '*')
                g2++;
            if (pas[i] >= '0' && pas[i] <= '9')
                if (((pas[i] >= 'А') && (pas[i] <= 'Я')) || ((pas[i] >= 'а') && (pas[i] <= 'я')) || pas[i] == 'ё')
                    g4++;
            if (pas == null || pas == "")
                g5++;
            if (pas.Contains(" "))
                g6++;
        }
        for (int j = 0; j < pas.Length - 3; j++)
        {
            if (char.IsUpper(pas[j]) && char.IsUpper(pas[j + 1]) && char.IsUpper(pas[j + 2]))
            {
                Console.WriteLine();
                Console.WriteLine("Три заглавных символа в пароле не могут идти подряд, повторите попытку");
                Thread.Sleep(2000);
                goto tr;
            }
            else g7++;
        }
        foreach (char cr in pas)
            if (Char.IsNumber(cr))
                g3++;
        if (g1 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 заглавных буквы!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g2 < 2)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 2 спец. символа!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g3 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 цифры!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g4 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Никаких русских символов!");
            Thread.Sleep(2000);
            goto tr;
        }
        if (g5 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Видишь пароль? Нет. И я не вижу, а его не ввели");
            Console.ReadKey();
            goto tr;
        }
        if (g6 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Пароль не должен содержать пробелов");
            Thread.Sleep(2000);
            goto tr;
        }

        else

            Console.WriteLine("Начинаем создание человека..");
        string dolz = "NONE";
        string mesto = "NONE";
        string obr = "NONE";
        string secname = "NONE";
        string name = "NONE";
        Console.Write("Введите Фамилию: ");
        secname = Console.ReadLine();
        Console.Write("Введите имя: ");
        name = Console.ReadLine();
    dat:
        try
        {
            Console.Write("Введите год рождения: ");
            dd = Convert.ToInt32(Console.ReadLine());
            if (dd < 1960 || dd > 2002)
            {
                Console.WriteLine("Такую дату нельзя ввести");
                Console.ReadKey();
                goto dat;
            }
            else
            {
                goto allgoodK;
            }

        }
        catch
        {
            Console.Clear();
            Console.WriteLine("Вы ввели что-то не так");
            Console.ReadKey();
            goto dat;
        }
    allgoodK:
        int zar = 0;
        Thread.Sleep(2000);
        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat", FileMode.OpenOrCreate)))
        {
            zhurnal.Write(log);
        }
        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.OpenOrCreate)))
        {
            zhurnal.Write(log);
            zhurnal.Write(pas);
            zhurnal.Write(mesto);
            zhurnal.Write(dolz);
            zhurnal.Write(obr);
            zhurnal.Write(secname);
            zhurnal.Write(name);
            zhurnal.Write(dd);
            zhurnal.Write(zar);
        }
        Console.WriteLine("Человек был создан,вот его данные:");
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.Open)))
        {

            log = zhurnal.ReadString();
            pas = zhurnal.ReadString();
            mesto = zhurnal.ReadString();
            dolz = zhurnal.ReadString();
            obr = zhurnal.ReadString();
            secname = zhurnal.ReadString();
            name = zhurnal.ReadString();
            dd = zhurnal.ReadInt32();
            zar = zhurnal.ReadInt32();
            Console.Write("Логин: {0} Пароль: {1} Место работы: {2} Должность: {3} Образование: {4} Фамилия: {5} Имя: {6} Год Рождения: {7} Зарплата: {8}", log, pas, mesto, dolz, obr, secname, name, dd, zar);
            zhurnal.Close();
        }
        Console.ReadKey();
        create();
    }
    static void vixod()
    {
        Console.Clear();
        admin adm = new admin();
        adm.admins();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 4;
                Text(4);
            }
            if (num == 5)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class kadriCh
{
    static string[] texts = new string[] { "Кадр\n", "1: Изменить человека, не принятого в сеть", "2: Изменить данные уже принятого человека в сеть", "3: Выход" };
    public void kaCh()
    {
        menu();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { chChel(); }; break;
            case 2: { chProf(); } break;
            case 3: { nazad(); } break;
            case 4: { }; break;
        }
    }
    static string log, pas, mest, dol, obr, secname, name;
    static int god, zar;
    static void chProf()
    {
        Console.Clear();
    tru20:
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность");
        string dolzh = Console.ReadLine();
        log = dolzh;
        int a = 0;

        DateTime date = DateTime.Today;
        string datas = Convert.ToString(date);

        if (log == "кладовщик")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету кладовщиков");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выберете сотрудника по ID: ");
            log = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которые мы имеем");
            da:
                Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                Console.WriteLine("Введите должность");
                dol = Console.ReadLine();

                if (dol == "кладовщик")
                {
                    mest = "сеть";
                    zar = 30000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кадры")
                {
                    mest = "сеть";
                    zar = 34000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "бухгалтер")
                {
                    mest = "сеть";
                    zar = 36000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кассир")
                {
                try3:
                    int l = 0;
                    DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                    foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                    {
                        Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                    }
                    if (l == 0)
                    {
                        Console.WriteLine("Магазинов ещё нету");
                        Console.ReadKey();
                        goto tru20;
                    }
                    else
                        Console.WriteLine("Выбере магазин для него");
                    mest = Console.ReadLine();
                    if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                    {
                        zar = 20000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dolzh);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else
                    {
                        Console.WriteLine("Такого магазина нету");
                        Console.ReadKey();

                        goto try3;
                    }
                }
                else
                {
                    Console.WriteLine("Такой должности нету");
                    Console.ReadKey();

                    goto da;

                }
            obr:
                Console.WriteLine("Введите новое образование");
            allgood:
                Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                string obr1 = Console.ReadLine();
                if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                {
                    goto finaly;
                }
                else
                {
                    Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                    Console.ReadKey();
                    goto allgood;
                }
            finaly:
                Console.Write("Введите Фамилию: ");
                secname = Console.ReadLine();
                Console.Write("Введите имя: ");
                name = Console.ReadLine();
            dat:
                try
                {
                    Console.Write("Введите год рождения: ");
                    god = Convert.ToInt32(Console.ReadLine());
                    if (god < 1960 || god > 2002)
                    {
                        Console.WriteLine("Такую дату нельзя ввести");
                        Console.ReadKey();
                        goto dat;
                    }
                    else
                    {
                        goto allgoodK;
                    }

                }
                catch
                {

                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    goto dat;
                }
            allgoodK:

                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mest);
                    zhurnal.Write(dol);
                    zhurnal.Write(obr1);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zar);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                if (dol == "кладовщик")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                }
                else if (dol == "кадры")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                }
                else if (dol == "бухгалтер")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                }
                else if (dol == "кассир")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\" + log + ".dat");
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет");
                Console.ReadKey();
                goto klad;
            }

        }
        else if (log == "кадры")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету кадров");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выберете сотрудника по ID: ");
            log = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которые мы имеем");
            da:
                Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                Console.WriteLine("Введите должность");
                dol = Console.ReadLine();

                if (dol == "кладовщик")
                {
                    mest = "сеть";
                    zar = 30000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кадры")
                {
                    mest = "сеть";
                    zar = 34000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "бухгалтер")
                {
                    mest = "сеть";
                    zar = 36000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кассир")
                {
                try3:
                    int l = 0;
                    DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                    foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                    {
                        Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                    }
                    if (l == 0)
                    {
                        Console.WriteLine("Магазинов ещё нету");
                        Console.ReadKey();
                        goto try3;
                    }
                    else
                        Console.WriteLine("Выбере магазин для него");
                    mest = Console.ReadLine();
                    if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                    {
                        zar = 20000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else
                    {
                        Console.WriteLine("Такого магазина нету");
                        Console.ReadKey();

                        goto try3;
                    }
                }
                else
                {
                    Console.WriteLine("Такой должности нету");
                    Console.ReadKey();

                    goto da;

                }
            obr:
                Console.WriteLine("Введите новое образование");
            allgood:
                Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                string obr1 = Console.ReadLine();
                if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                {
                    goto finaly;
                }
                else
                {
                    Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                    Console.ReadKey();
                    goto allgood;
                }
            finaly:
                Console.Write("Введите Фамилию: ");
                secname = Console.ReadLine();
                Console.Write("Введите имя: ");
                name = Console.ReadLine();
            dat:
                try
                {
                    Console.Write("Введите год рождения: ");
                    god = Convert.ToInt32(Console.ReadLine());
                    if (god < 1960 || god > 2002)
                    {
                        Console.WriteLine("Такую дату нельзя ввести");
                        Console.ReadKey();
                        goto dat;
                    }
                    else
                    {
                        goto allgoodK;
                    }

                }
                catch
                {

                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    goto dat;
                }
            allgoodK:
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mest);
                    zhurnal.Write(dol);
                    zhurnal.Write(obr1);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zar);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                if (dol == "кладовщик")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                }
                else if (dol == "кадры")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                }
                else if (dol == "бухгалтер")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                }
                else if (dol == "кассир")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\" + log + ".dat");
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (log == "бухгалтер")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету бухгалтера");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выберете сотрудника по ID: ");
            log = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                Console.WriteLine("Это те данные, которые мы имеем");
            da:
                Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                Console.WriteLine("Введите должность");
                dol = Console.ReadLine();

                if (dol == "кладовщик")
                {
                    mest = "сеть";
                    zar = 30000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кадры")
                {
                    mest = "сеть";
                    zar = 34000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "бухгалтер")
                {
                    mest = "сеть";
                    zar = 36000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    goto obr;
                }
                else if (dol == "кассир")
                {
                try3:
                    int l = 0;
                    DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                    foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                    {
                        Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                    }
                    if (l == 0)
                    {
                        Console.WriteLine("Магазинов ещё нету");
                        Console.ReadKey();
                        goto try3;
                    }
                    else
                        Console.WriteLine("Выбере магазин для него");
                    mest = Console.ReadLine();
                    if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                    {
                        zar = 20000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else
                    {
                        Console.WriteLine("Такого магазина нету");
                        Console.ReadKey();

                        goto try3;
                    }
                }
                else
                {
                    Console.WriteLine("Такой должности нету");
                    Console.ReadKey();

                    goto da;

                }
            obr:
                Console.WriteLine("Введите новое образование");
            allgood:
                Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                string obr1 = Console.ReadLine();
                if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                {
                    goto finaly;
                }
                else
                {
                    Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                    Console.ReadKey();
                    goto allgood;
                }
            finaly:
                Console.Write("Введите Фамилию: ");
                secname = Console.ReadLine();
                Console.Write("Введите имя: ");
                name = Console.ReadLine();
            dat:
                try
                {
                    Console.Write("Введите год рождения: ");
                    god = Convert.ToInt32(Console.ReadLine());
                    if (god < 1960 || god > 2002)
                    {
                        Console.WriteLine("Такую дату нельзя ввести");
                        Console.ReadKey();
                        goto dat;
                    }
                    else
                    {
                        goto allgoodK;
                    }

                }
                catch
                {

                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    goto dat;
                }
            allgoodK:
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mest);
                    zhurnal.Write(dol);
                    zhurnal.Write(obr1);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zar);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                    zhurnal.Close();
                }
                if (dol == "кладовщик")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                }
                else if (dol == "кадры")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                }
                else if (dol == "бухгалтер")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                }
                else if (dol == "кассир")
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\" + log + ".dat");
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (log == "кассир")
        {
        klad:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Нету магазинов");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере магазин: ");
            mest = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + ".dat"))
            {
            sotr:
                DirectoryInfo db = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\");
                foreach (FileInfo da in db.GetFiles())
                {
                    Console.WriteLine("ID сотрудника: " + Path.GetFileNameWithoutExtension(da.FullName)); a++;
                }

                log = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat"))
                {
                    Console.Clear();
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                        zhurnal.Close();
                    }
                    Console.WriteLine("Это те данные, которыми он сейчас обладает");
                    Console.WriteLine("Вводим должности, место работы и зарплата определится автоматически");
                tru:
                    Console.Clear();
                    Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
                    Console.WriteLine("Введите для него должность");
                    dol = Console.ReadLine();

                    if (dol == "кладовщик")
                    {
                        mest = "сеть";
                        zar = 30000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }
                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "кадры")
                    {
                        mest = "сеть";
                        zar = 34000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "бухгалтер")
                    {
                        mest = "сеть";
                        zar = 36000;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Write(datas);
                            zhurnal.Close();
                        }

                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        goto obr;
                    }
                    else if (dol == "кассир")
                    {
                    try3:
                        int l = 0;
                        DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                        foreach (FileInfo lol in dieL.GetFiles("*.dat"))
                        {
                            Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
                        }
                        if (l == 0)
                        {
                            Console.WriteLine("Магазинов ещё нету");
                            Console.ReadKey();
                            goto tru;
                        }
                        else
                            Console.WriteLine("Выбере магазин для него");
                        mest = Console.ReadLine();
                        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
                        {
                            zar = 20000;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(log);
                                zhurnal.Write(pas);
                                zhurnal.Write(mest);
                                zhurnal.Write(dol);
                                zhurnal.Write(obr);
                                zhurnal.Write(secname);
                                zhurnal.Write(name);
                                zhurnal.Write(god);
                                zhurnal.Write(zar);
                                zhurnal.Write(datas);
                                zhurnal.Close();
                            }
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + log + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(log);
                                zhurnal.Write(pas);
                                zhurnal.Write(mest);
                                zhurnal.Write(dol);
                                zhurnal.Write(obr);
                                zhurnal.Write(secname);
                                zhurnal.Write(name);
                                zhurnal.Write(god);
                                zhurnal.Write(zar);
                                zhurnal.Write(datas);
                                zhurnal.Close();
                            }
                            Console.WriteLine("Всё готово");
                            Console.ReadKey();
                            goto obr;
                        }
                        else
                        {
                            Console.WriteLine("Такого магазина нету");
                            Console.ReadKey();

                            goto try3;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Такой должности нету");
                        Console.ReadKey();

                        goto tru;

                    }
                obr:
                    Console.WriteLine("Введите новое образование");
                allgood:
                    Console.Write("Введите образование из выбора: СОО, СПО, ВО: ");
                    string obr1 = Console.ReadLine();
                    if (obr1 == "СОО" || obr1 == "СПО" || obr1 == "ВО")
                    {
                        goto finaly;
                    }
                    else
                    {
                        Console.WriteLine("Такое образование не доступно для нашей сети магазинов или-же его просто нету");
                        Console.ReadKey();
                        goto allgood;
                    }
                finaly:
                    Console.Write("Введите Фамилию: ");
                    secname = Console.ReadLine();
                    Console.Write("Введите имя: ");
                    name = Console.ReadLine();
                dat:
                    try
                    {
                        Console.Write("Введите год рождения: ");
                        god = Convert.ToInt32(Console.ReadLine());
                        if (god < 1960 || god > 2002)
                        {
                            Console.WriteLine("Такую дату нельзя ввести");
                            Console.ReadKey();
                            goto dat;
                        }
                        else
                        {
                            goto allgoodK;
                        }

                    }
                    catch
                    {

                        Console.WriteLine("Вы ввели что-то не так");
                        Console.ReadKey();
                        goto dat;
                    }
                allgoodK:
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(mest);
                        zhurnal.Write(dol);
                        zhurnal.Write(obr1);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zar);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                        zhurnal.Close();
                    }
                    if (dol == "кладовщик")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log + ".dat");
                        File.Delete(@"C:\Debug\СетьМагазиновАхеть\продавец.dat");
                    }
                    else if (dol == "кадры")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\кадры\" + log + ".dat");
                        File.Delete(@"C:\Debug\СетьМагазиновАхеть\продавец.dat");
                    }
                    else if (dol == "бухгалтер")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log + ".dat");
                        File.Delete(@"C:\Debug\СетьМагазиновАхеть\продавец.dat");
                    }
                    else if (dol == "кассир")
                    {
                        File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat", @"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\продавец\" + log + ".dat");
                    }
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такого сотрудика нету");
                    Console.ReadKey();
                    goto sotr;
                }
            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                goto klad;
            }

        }
    }
    static void chChel()
    {
        Console.Clear();
    one:
        int a = 0;
        DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\люди\");
        foreach (FileInfo files in die2.GetFiles())
        {
            Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Людей ещё нету");
            Console.ReadKey();
            menu();
        }
        else
            Console.Write("Выберете человека по его ID: ");
        log = Console.ReadLine();
        if (File.Exists(@"C:\Debug\люди\" + log + ".dat"))
        {
            Console.Clear();
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.Open)))
            {
                log = zhurnal.ReadString();
                pas = zhurnal.ReadString();
                mest = zhurnal.ReadString();
                dol = zhurnal.ReadString();
                obr = zhurnal.ReadString();
                secname = zhurnal.ReadString();
                name = zhurnal.ReadString();
                god = zhurnal.ReadInt32();
                zar = zhurnal.ReadInt32();
                Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar);
                zhurnal.Close();
            }
            Console.WriteLine("Это те данные, которыми он сейчас обладает");
            Console.Write("Введите Фамилию: ");
            secname = Console.ReadLine();
            Console.Write("Введите имя: ");
            name = Console.ReadLine();
        dat:
            try
            {
                Console.Write("Введите год рождения: ");
                god = Convert.ToInt32(Console.ReadLine());
                if (god < 1980 || god > 2002)
                {
                    Console.WriteLine("Такую дату нельзя ввести");
                    Console.ReadKey();
                    goto dat;
                }
                else
                {
                    goto tru;
                }
            }
            catch
            {

                Console.WriteLine("Вы ввели что-то не так");
                Console.ReadKey();
                goto dat;
            }
        tru:
            mest = "NONE";
            dol = "NONE";
            obr = "NONE";
            zar = 0;
            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.OpenOrCreate)))
            {
                zhurnal.Write(log);
                zhurnal.Write(pas);
                zhurnal.Write(mest);
                zhurnal.Write(dol);
                zhurnal.Write(obr);
                zhurnal.Write(secname);
                zhurnal.Write(name);
                zhurnal.Write(god);
                zhurnal.Write(zar);
                zhurnal.Close();
            }
            Console.WriteLine("Всё готово");
            Console.ReadKey();
            menu();
        }
        else
        {
            Console.WriteLine("Такого человека нету");
            Console.ReadKey();
            goto one;
        }


    }

    static void nazad()
    {
        Console.Clear();
        kadri adm = new kadri();
        adm.kadr();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 3;
                Text(3);
            }
            if (num == 5)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class kadri
{
    static string[] texts = new string[] { "Кадр\n", "1: Взять на работу", "2: Уволить", "3: Просмотреть", "4: Изменение данных", "5: Выход" };
    public void kadr()
    {
        vxod();
    }
    static void vxod()
    {
        menu();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { vzat(); }; break;
            case 2: { uvol(); } break;
            case 3: { prosmot(); } break;
            case 4: { cha(); }; break;
            case 5: { vixod(); }; break;
            case 6: { }; break;
        }
    }
    static string log, pas, mest, dol, obr, secname, name, nacha;
    static int god, zar;
    static void cha()
    {
        Console.Clear();
        kadriCh adm = new kadriCh();
        adm.kaCh();
    }
    static void vixod()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
    static void prosmot()
    {
    tru:
        Console.Clear();
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность по которой вы хотите просмотреть данные");
        string dolzh = Console.ReadLine();
        if (dolzh == "кладовщик")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha = zhurnal.ReadString();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2}  Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {8}", log, mest, dol, obr, secname, name, god, zar, nacha);
                    zhurnal.Close();
                }

                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }
        }
        else if (dolzh == "кадры")
        {
        klad:
            int b = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName));
                b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha = zhurnal.ReadString();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2}  Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {8}", log, mest, dol, obr, secname, name, god, zar, nacha);
                    zhurnal.Close();
                }

                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }

        }
        else if (dolzh == "бухгалтер")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека:");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha = zhurnal.ReadString();
                    Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2}  Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {8}", log, mest, dol, obr, secname, name, god, zar, nacha);
                    zhurnal.Close();
                }
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (dolzh == "кассир")
        {
        try3:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            int k = 0;
            foreach (FileInfo files in die2.GetFiles("*.dat"))
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); k++;
            }
            if (k == 0)
            {
                Console.WriteLine("Магазинов ещё нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере магазин для него");
            string nameM = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
            {
            klad:
                int t = 0;
                DirectoryInfo diel = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\");
                foreach (FileInfo filesN in diel.GetFiles())
                {
                    Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(filesN.FullName)); t++;
                }
                if (t == 0)
                {
                    Console.WriteLine("Тут никого нету");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере ID человека");
                string id = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat"))
                {
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        nacha = zhurnal.ReadString();
                        Console.WriteLine("Логин: {0} Место работы: {1} Должность: {2}  Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {8}", log, mest, dol, obr, secname, name, god, zar, nacha);
                        zhurnal.Close();
                    }
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такой человек не найдет");
                    Console.ReadKey();
                    goto klad;
                }

            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                Console.Clear();
                goto try3;
            }
        }
        else
        {
            Console.WriteLine("Такой должности нету");
            Console.ReadKey();
            Console.Clear();
            goto tru;

        }

    }
    static void uvol()
    {
    tru:
        Console.Clear();
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность по которой вы хотите уволить кого-то");
        string dolzh = Console.ReadLine();
        if (dolzh == "кладовщик")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут некого увольнять");
                Console.ReadKey();
                menu();
            }
            Console.WriteLine("Выбере ID человека, которого хотите уволить");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat"))
            {
                File.Move(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat", @"C:\Debug\уволен\" + id + ".dat");
                Console.WriteLine("Человек уволен");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }
        }
        else if (dolzh == "кадры")
        {
        klad:
            int b = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName));
                b++;
            }
            if (b == 1)
            {
                Console.WriteLine("В этой компании не может быть менее одного кадра!");
                Console.WriteLine("В ДОСТУПЕ ОТКАЗАНО");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере ID человека, которого хотите уволить");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat"))
            {
                File.Move(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat", @"C:\Debug\уволен\" + id + ".dat");
                Console.WriteLine("Человек уволен");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }

        }
        else if (dolzh == "бухгалтер")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут некого увольнять");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере ID человека, которого хотите уволить");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat"))
            {
                File.Move(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat", @"C:\Debug\уволен\" + id + ".dat");
                Console.WriteLine("Человек уволен");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (dolzh == "кассир")
        {
        try3:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            int k = 0;
            foreach (FileInfo files in die2.GetFiles("*.dat"))
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); k++;
            }
            if (k == 0)
            {
                Console.WriteLine("Магазинов ещё нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере магазин для него");
            string nameM = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
            {
            klad:
                int t = 0;
                DirectoryInfo diel = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\");
                foreach (FileInfo filesN in diel.GetFiles())
                {
                    Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(filesN.FullName)); t++;
                }
                if (t == 0)
                {
                    Console.WriteLine("Тут некого увольнять");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере ID человека, которого хотите уволить");
                string id = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat"))
                {
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat", @"C:\Debug\уволен\" + id + ".dat");
                    File.Move(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + id + ".dat", @"C:\Debug\уволен\" + id + ".dat");
                    Console.WriteLine("Человек уволен");
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такой человек не найдет");
                    Console.ReadKey();
                    goto klad;
                }

            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                Console.Clear();
                goto try3;
            }
        }
        else
        {
            Console.WriteLine("Такой должности нету");
            Console.ReadKey();
            Console.Clear();
            goto tru;

        }

    }
    static void vzat()
    {
        Console.Clear();
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\люди\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Человек - его ID: " + Path.GetFileNameWithoutExtension(files.FullName));
        }
        Console.WriteLine("Введите ID человека чтобы принять его на работу");
        string log1 = Console.ReadLine();
        if (File.Exists(@"C:\Debug\люди\" + log1 + ".dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log1 + ".dat", FileMode.Open)))
            {
                log = zhurnal.ReadString();
                pas = zhurnal.ReadString();
                mest = zhurnal.ReadString();
                dol = zhurnal.ReadString();
                obr = zhurnal.ReadString();
                secname = zhurnal.ReadString();
                name = zhurnal.ReadString();
                god = zhurnal.ReadInt32();
                zhurnal.Close();
            }
        tru:
            Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
            Console.WriteLine("Введите для него должность");


            string dolzh = Console.ReadLine();

            DateTime date = DateTime.Today;
            string datas = Convert.ToString(date);

            if (dolzh == "кладовщик")
            {
                string mestKL = "сеть";
                int zarp = 30000;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log1 + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mestKL);
                    zhurnal.Write(dolzh);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zarp);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else if (dolzh == "кадры")
            {
                string mestKL = "сеть";
                int zarp = 34000;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log1 + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mestKL);
                    zhurnal.Write(dolzh);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zarp);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else if (dolzh == "бухгалтер")
            {
                string mestKL = "сеть";
                int zarp = 36000;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log1 + ".dat", FileMode.Create)))
                {
                    zhurnal.Write(log);
                    zhurnal.Write(pas);
                    zhurnal.Write(mestKL);
                    zhurnal.Write(dolzh);
                    zhurnal.Write(obr);
                    zhurnal.Write(secname);
                    zhurnal.Write(name);
                    zhurnal.Write(god);
                    zhurnal.Write(zarp);
                    zhurnal.Write(datas);
                    zhurnal.Close();
                }
                File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else if (dolzh == "кассир")
            {
            try3:
                int l = 0;
                DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                foreach (FileInfo files in die2.GetFiles("*.dat"))
                {
                    Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); l++;
                }
                if (l == 0)
                {
                    Console.WriteLine("Магазинов ещё нету");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере магазин для него");
                string nameM = Console.ReadLine();
                if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
                {
                    int zarp = 20000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + log1 + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(nameM);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zarp);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + log1 + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(log);
                        zhurnal.Write(pas);
                        zhurnal.Write(nameM);
                        zhurnal.Write(dolzh);
                        zhurnal.Write(obr);
                        zhurnal.Write(secname);
                        zhurnal.Write(name);
                        zhurnal.Write(god);
                        zhurnal.Write(zarp);
                        zhurnal.Write(datas);
                        zhurnal.Close();
                    }
                    File.Delete(@"C:\Debug\люди\" + log1 + ".dat");
                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такого магазина нету");
                    Console.ReadKey();
                    Console.Clear();
                    goto try3;
                }
            }
            else
            {
                Console.WriteLine("Такой должности нету");
                Console.ReadKey();
                Console.Clear();
                goto tru;

            }
        }
        else
        {
            Console.WriteLine("Такого человека нету");
            Console.ReadKey();
            menu();
        }
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[5]);
        }
        if (i == 5)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[5]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 5;
                Text(5);
            }
            if (num == 6)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class register
{
    public void registerr()
    {
        Console.Clear();
        reg();
    }
    static string email, log, pas;
    static void returnreg()
    {
        reg();
    }
    static void returnreglog()
    {
        reglog();
    }

    static void reg()
    {
    Dan:
        int g = 0;
        try
        {
            Console.WriteLine("Введите email");
            email = Console.ReadLine();
            string pattern = @"^(?("")(""[^""]+?""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
            @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9]{2,17}))$";
            if (Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase))
            {
                reglog();
            }
            else
            {
                Console.WriteLine("Введите по нормальному");
                Console.ReadKey();
                goto Dan;
            }
        }
        catch
        {
            Console.WriteLine("Ты ввёл что-то не так");
            Console.ReadKey();
            goto Dan;
        }

    }
    static void reglog()
    {
    r2:
        try
        {
            int g4 = 0;
            Console.WriteLine("Введите логин");
            log = Console.ReadLine();
            for (int i = 0; i < log.Length; i++)
            {
                if (((log[i] >= 'А') && (log[i] <= 'Я')) || ((log[i] >= 'а') && (log[i] <= 'я')) || log[i] == 'ё')
                    g4++;
            }
            if (g4 > 0)
            {
                Console.WriteLine();
                Console.WriteLine("Никаких русских символов!");
                Thread.Sleep(2000);
                goto r2;
            }
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat"))
            {
                Console.WriteLine("Такой покупатель уже существует!");
                Console.ReadKey();
                returnreglog();
            }
            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log + ".dat", FileMode.OpenOrCreate)))
            {

                zhurnal.Write(email);
                zhurnal.Write(log);
            }
            regpas();
        }
        catch
        {
            Console.WriteLine("Введите нормально логин");
            Console.ReadKey();
            returnreglog();
        }
    }
    static void regpas()
    {

    r2:
        Console.Clear();
        Console.Write("Введите пароль: ");
        pas = Console.ReadLine();
        if (pas.Length < 8)
        {
            Console.WriteLine();
            Console.WriteLine("Длина пароля не соответствует требованиям безопасности");
            Thread.Sleep(2000);
            goto r2;
        }
        int g1 = 0, g2 = 0, g3 = 0, g4 = 0, g5 = 0, g6 = 0, g7 = 0;
        for (int i = 0; i < pas.Length; i++)
        {
            if ((pas[i] >= 'A') && (pas[i] <= 'Z'))
                g1++;
            if (pas[i] == '!' || pas[i] == '@' || pas[i] == '#' || pas[i] == '$' || pas[i] == '%' || pas[i] == '&' || pas[i] == '*' || pas[i] == '^')
                g2++;

            if (((pas[i] >= 'А') && (pas[i] <= 'Я')) || ((pas[i] >= 'а') && (pas[i] <= 'я')) || pas[i] == 'ё')
                g4++;
            if (pas == null || pas == "")
                g5++;
            if (pas.Contains(" "))
                g6++;
        }
        for (int j = 0; j < pas.Length - 3; j++)
        {
            if (char.IsUpper(pas[j]) && char.IsUpper(pas[j + 1]) && char.IsUpper(pas[j + 2]))
            {
                Console.WriteLine();
                Console.WriteLine("Три заглавных символа в пароле не могут идти подряд, повторите попытку");
                Thread.Sleep(2000);
                goto r2;
            }
            else g7++;
        }
        foreach (char cr in pas)
            if (Char.IsNumber(cr))
                g3++;
        if (g1 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 заглавных буквы!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g2 < 2)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 2 спец. символа!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g3 <= 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 цифры!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g4 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Никаких русских символов!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g5 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Видишь пароль? Нет. И я не вижу, а его не ввели");
            Console.ReadKey();
            goto r2;
        }
        if (g6 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Пароль не должен содержать пробелов");
            Thread.Sleep(2000);
            goto r2;
        }
        else

            regpasS();
    }
    static void regpasS()
    {

        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat", FileMode.OpenOrCreate)))
        {
            zhurnal.Write(log);
        }
        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log + ".dat", FileMode.OpenOrCreate)))
        {

            zhurnal.Write(email);
            zhurnal.Write(log);
            zhurnal.Write(pas);
        }
        Console.WriteLine("Ваш аккаунт был создан, вот ваши данные:");
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log + ".dat", FileMode.OpenOrCreate)))
        {
            email = zhurnal.ReadString();
            log = zhurnal.ReadString();
            pas = zhurnal.ReadString();
            Console.WriteLine("Ваш email: {0} Ваш логин: {1}  Ваш пороль: {2}", email, log, pas);
            zhurnal.Close();
        }
        Console.ReadKey();
        exit();
    }
    static void exit()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }

}
class avtorizachia
{
    static string log, pas, email;
    public void into()
    {
        Console.Clear();
        vxod();
    }
    static void admin()
    {
        admin adm = new admin();
        adm.admins();
    }
    static void vxod()
    {
        Console.Write("Введите логин: ");
        string log1 = Console.ReadLine();
        if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log1 + ".dat"))
        {
            if (File.Exists(@"C:\Debug\Админ\" + log1 + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Админ\" + log1 + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    zhurnal.Close();
                }
                if (log1 == log)
                {
                    if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + log + ".dat"))
                    {
                        Console.Write("Введите пароль: ");
                        string pas1 = Console.ReadLine();
                        if (pas == pas1)
                        {
                            Console.WriteLine("Доступ разрешён");
                            Thread.Sleep(2000);
                            Console.Clear();
                            admin();
                        }
                        else
                        {
                            Console.WriteLine("Вы ввели пароль не правильно");
                            Console.ReadKey();
                            exit();
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();
                }
            }
            else if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log1 + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log1 + ".dat", FileMode.Open)))
                {
                    email = zhurnal.ReadString();
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    zhurnal.Close();
                }
                if (log == log1)
                {
                    Console.Write("Введите пароль: ");
                    string pas1 = Console.ReadLine();
                    if (pas == pas1)
                    {
                        Console.WriteLine("Доступ разрешён");
                        Thread.Sleep(2000);
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\человек.dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(email);
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Close();
                        }
                        Console.Clear();
                        pokupat();
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели пароль не правильно");
                        Console.ReadKey();
                        exit();
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();

                }
            }
            else if (File.Exists(@"C:\Debug\люди\" + log1 + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log1 + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    zhurnal.Close();
                }
                if (log == log1)
                {
                    Console.Write("Введите пароль: ");
                    string pas1 = Console.ReadLine();
                    if (pas == pas1)
                    {
                        Console.WriteLine("Доступ разрешён");
                        Thread.Sleep(2000);
                        Console.Clear();
                        lud();
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели пароль не правильно");
                        Console.ReadKey();
                        exit();
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();

                }
            }
            else if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log1 + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + log1 + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    zhurnal.Close();
                }
                if (log == log1)
                {
                    Console.Write("Введите пароль: ");
                    string pas1 = Console.ReadLine();
                    if (pas == pas1)
                    {
                        Console.WriteLine("Доступ разрешён");
                        Thread.Sleep(2000);
                        Console.Clear();
                        kadr();
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели пароль не правильно");
                        Console.ReadKey();
                        exit();
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();

                }
            }
            else if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log1 + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + log1 + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    zhurnal.Close();
                }
                if (log == log1)
                {
                    Console.Write("Введите пароль: ");
                    string pas1 = Console.ReadLine();
                    if (pas == pas1)
                    {
                        Console.WriteLine("Доступ разрешён");
                        Thread.Sleep(2000);
                        Console.Clear();
                        kald();
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели пароль не правильно");
                        Console.ReadKey();
                        exit();
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();

                }


            }
            else if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + log1 + ".dat"))
            {
                string mest, dol, obr, secname, name; int god, zar;
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\" + log1 + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    zhurnal.Close();
                }
                if (log == log1)
                {
                    Console.Write("Введите пароль: ");
                    string pas1 = Console.ReadLine();
                    if (pas == pas1)
                    {
                        Console.WriteLine("Доступ разрешён");
                        Thread.Sleep(2000);
                        Console.Clear();
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\продавец" + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Close();
                        }
                        prod();
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели пароль не правильно");
                        Console.ReadKey();
                        exit();
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();

                }
            }
            else if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log1 + ".dat"))
            {
                string mest, dol, obr, secname, name; int god, zar;
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log1 + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    zhurnal.Close();
                }
                if (log == log1)
                {
                    Console.Write("Введите пароль: ");
                    string pas1 = Console.ReadLine();
                    if (pas == pas1)
                    {
                        Console.WriteLine("Доступ разрешён");
                        Thread.Sleep(2000);
                        Console.Clear();
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + log1 + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(log);
                            zhurnal.Write(pas);
                            zhurnal.Write(mest);
                            zhurnal.Write(dol);
                            zhurnal.Write(obr);
                            zhurnal.Write(secname);
                            zhurnal.Write(name);
                            zhurnal.Write(god);
                            zhurnal.Write(zar);
                            zhurnal.Close();
                        }
                        bux();
                    }
                    else
                    {
                        Console.WriteLine("Вы ввели пароль не правильно");
                        Console.ReadKey();
                        exit();
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не верный логин");
                    Console.ReadKey();
                    exit();

                }
            }
            else
            {
                Console.WriteLine("Такого нету");
                Console.ReadKey();
                exit();
            }
        }
        else
        {
            Console.WriteLine("Такого нету в системе");
            Console.ReadKey();
            exit();
        }

    }
    static void bux()
    {
        Console.Clear();
        bux adm = new bux();
        adm.buc();
    }
    static void prod()
    {
        Console.Clear();
        prodav adm = new prodav();
        adm.prod();
    }
    static void kald()
    {
        Console.Clear();
        kladovshik adm = new kladovshik();
        adm.klad();
    }
    static void kadr()
    {
        Console.Clear();
        kadri adm = new kadri();
        adm.kadr();
    }
    static void lud()
    {
        Console.WriteLine("Вы вошли, но вы не обладаете никакими возможностями");
        Console.WriteLine("Нажмите любую кнопку чтобы вернуться");
        Console.ReadKey();
        exit();
    }
    static void pokupat()
    {
        Console.Clear();
        pokup adm = new pokup();
        adm.poku1();
    }
    static void exit()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
}
class pokup
{
    static string[] texts = new string[] { "Покупатель\n", "1: Добавить в корзину", "2: Убрать из корзины", "3: Просмотреть свою корзину", "4: Выход" };
    public void poku1()
    {
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\человек.dat", FileMode.Open)))
        {
            email = zhurnal.ReadString();
            log = zhurnal.ReadString();
            pas = zhurnal.ReadString();
            zhurnal.Close();
        }
        menu();
    }
    static void vixod()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { dobad(); }; break;
            case 2: { ubrad(); } break;
            case 3: { getI(); } break;
            case 4: { vixod(); }; break;
            case 5: { }; break;
        }
    }
    static void getI()
    {
        Console.Clear();
        int l = 0;
        DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\заказ\" + log);
        foreach (FileInfo lol in dieL.GetFiles())
        {
            l++;
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\заказ\" + log + @"\" + lol, FileMode.Open)))
            {
                name = zhurnal.ReadString();
                kategor = zhurnal.ReadString();
                kol = zhurnal.ReadInt32();
                chuk = zhurnal.ReadInt32();
                mest = zhurnal.ReadString();
                zhurnal.Close();
            }
            Console.WriteLine("Название: {0} Категория: {1} Колличество: {2} Цена: {3} ", name, kategor, kol, chuk);
        }
        if (l == 0)
        {
            Console.WriteLine("Ваша корзина пуста");
            Console.ReadKey();
            menu();
        }

        Console.ReadKey();
        menu();
    }
    static string email, log, pas, mest, dol, obr, secname, name, kategor, dd1;
    static int chuk, kol;
    static void ubrad()
    {
    ub:
        Console.Clear();
        int l = 0;
        DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\заказ\" + log);
        foreach (FileInfo lol in dieL.GetFiles())
        {
            Console.WriteLine("Продукты: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
        }
        if (l == 0)
        {
            Console.WriteLine("Вы ещё ничего не добавили");
            Console.ReadKey();
            menu();
        }
        else
            Console.Write("Введите название: ");
        name = Console.ReadLine();
        if (File.Exists(@"C:\Debug\заказ\" + log + @"\" + name + ".dat"))
        {
        ib:
            int kal = 0;
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\заказ\" + log + @"\" + name + ".dat", FileMode.Open)))
            {
                name = zhurnal.ReadString();
                kategor = zhurnal.ReadString();
                kol = zhurnal.ReadInt32();
                chuk = zhurnal.ReadInt32();
                mest = zhurnal.ReadString();
                zhurnal.Close();
            }
            Console.WriteLine("Столько у вас в корзине: " + kol);
            try
            {
                Console.WriteLine("Сколько вы хотите убрать?");
                kal = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Так нельзя");
                Console.ReadKey();
                goto ib;
            }
            kal = kol - kal;
            if (kal == 0)
            {

                Console.WriteLine("Убираем весь продукт т.к теперь у вас будет 0 именно этих продуктов.");
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                int ko111 = kol + kal;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(name);
                    zhurnal.Write(chuk);
                    zhurnal.Write(ko111);
                    zhurnal.Write(dd1);
                }
                File.Delete(@"C:\Debug\заказ\" + log + @"\" + name + ".dat");
                Console.ReadKey();
                menu();
            }
            else if (kal > 0)
            {
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\заказ\" + log + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(name);
                    zhurnal.Write(kategor);
                    zhurnal.Write(kal);
                    zhurnal.Write(chuk);
                    zhurnal.Write(mest);
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                int ko111 = kol + kal;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(name);
                    zhurnal.Write(chuk);
                    zhurnal.Write(ko111);
                    zhurnal.Write(dd1);
                }
                Console.WriteLine("Теперь у вас " + name + " " + kal);
                Console.WriteLine("Всё готово");

                Console.ReadKey();
                menu();
            }
            else if (kal <= 0)
            {
                Console.WriteLine("Зачем?");
                Console.ReadKey();
                goto ib;
            }


        }
        else
        {
            Console.WriteLine("Такого продукта нету");
            Console.ReadKey();
            goto ub;
        }
    }
    static void dobad()
    {
    try3:
        Console.Clear();
        int l = 0;
        DirectoryInfo dieL = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
        foreach (FileInfo lol in dieL.GetFiles("*.dat"))
        {
            Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(lol.FullName)); l++;
        }
        if (l == 0)
        {
            Console.WriteLine("Магазинов ещё нету");
            Console.ReadKey();
            Console.Clear();
            menu();
        }
        else
            Console.Write("Выбере магазин, в которой хотите зайти: ");
        mest = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest))
        {
            goto try1;
        }
        else
        {
            Console.WriteLine("Такого магазина нету");
            Console.ReadKey();
            Console.Clear();
            goto try3;
        }
    try1:
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName));
        }
        Console.Write("Введите категорию из выше представленных: ");
        kategor = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor))
        {

        try2:
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName));
            }
            Console.Write("Введите продукт из выше представленных: ");
            name = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat"))
            {


                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                if (kol == 0)
                {
                    Console.WriteLine("Вы или ещё кто-то уже взяли всё");
                    Console.ReadKey();
                    menu();
                }
                if (File.Exists(@"C:\Debug\заказ\" + log + @"\" + name + ".dat"))
                {
                try55:
                    Console.WriteLine("Вы уже добавили это в ваш заказ");
                    try
                    {
                    dada:
                        Console.WriteLine("На складе " + kol);
                        Console.Write("Сколько вы хотите? Введите число: ");
                        int skok = Convert.ToInt32(Console.ReadLine());
                        if (skok > kol)
                        {
                            Console.WriteLine("Столько нету");
                            Console.ReadKey();
                            Console.Clear();
                            goto try55;
                        }
                        if (skok < 0)
                        {
                            Console.WriteLine("Так нельзя");
                            Console.ReadKey();

                            goto dada;
                        }
                        else
                        {
                            int skok1 = 0;
                            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\заказ\" + log + @"\" + name + ".dat", FileMode.Open)))
                            {
                                name = zhurnal.ReadString();
                                kategor = zhurnal.ReadString();
                                skok1 = zhurnal.ReadInt32();
                                chuk = zhurnal.ReadInt32();
                                mest = zhurnal.ReadString();
                                zhurnal.Close();
                            }
                            skok = skok1 + skok;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\заказ\" + log + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(name);
                                zhurnal.Write(kategor);
                                zhurnal.Write(skok);
                                zhurnal.Write(chuk);
                                zhurnal.Write(mest);
                            }
                            skok = 0;
                            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                            {
                                name = zhurnal.ReadString();
                                chuk = zhurnal.ReadInt32();
                                kol = zhurnal.ReadInt32();
                                dd1 = zhurnal.ReadString();
                                zhurnal.Close();
                            }
                            int ko111 = kol - skok;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(name);
                                zhurnal.Write(chuk);
                                zhurnal.Write(ko111);
                                zhurnal.Write(dd1);
                            }
                            Console.WriteLine("Добавленно в корзину");
                            Console.ReadKey();
                            menu();
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Такое нельзя вводить");
                        Console.ReadKey();
                        Console.Clear();
                        goto try55;
                    }
                    Console.ReadKey();
                    menu();
                }
                double chena = 0;
                DateTime dt1 = DateTime.Now;
                var date2 = dt1.AddDays(14);
                string date3 = date2.ToShortDateString();

                DateTime date1D = new DateTime();
                DateTime date2D = new DateTime();

                date1D = Convert.ToDateTime(dd1);
                date2D = Convert.ToDateTime(date3);
                if (date1D < DateTime.Now)
                {
                    Console.WriteLine("Срок годности истёк");
                    Console.WriteLine("Этот товар нельзя преобрести");
                    Console.ReadKey();
                    menu();
                }
                else if (date2D >= date1D)
                {
                try5:
                    chena = Convert.ToDouble(chuk);
                    chena = chena / 2;
                    chuk = Convert.ToInt32(chena);
                    chuk = chuk + 20;
                    Console.WriteLine("Цена за штуку 50%: " + chuk);
                    try
                    {
                        Console.WriteLine("На складе " + kol);
                        if (kol == 0)
                        {
                            Console.WriteLine("Больше нету этого продукта");
                            Console.ReadKey();
                            menu();
                        }
                        Console.Write("Сколько вы хотите? Введите число: ");
                        int skok = Convert.ToInt32(Console.ReadLine());
                        if (skok > kol)
                        {
                            Console.WriteLine("Столько нету");
                            Console.ReadKey();
                            Console.Clear();
                            goto try5;
                        }
                        else
                        {
                            Directory.CreateDirectory(@"C:\Debug\заказ\" + log);
                            File.Create(@"C:\Debug\заказ\" + log + ".dat");
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\заказ\" + log + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(name);
                                zhurnal.Write(kategor);
                                zhurnal.Write(skok);
                                zhurnal.Write(chuk);
                                zhurnal.Write(mest);
                            }
                            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                            {
                                name = zhurnal.ReadString();
                                chuk = zhurnal.ReadInt32();
                                kol = zhurnal.ReadInt32();
                                dd1 = zhurnal.ReadString();
                                zhurnal.Close();
                            }
                            int ko111 = kol - skok;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(name);
                                zhurnal.Write(chuk);
                                zhurnal.Write(ko111);
                                zhurnal.Write(dd1);
                            }
                            Console.WriteLine("Добавленно в корзину");
                            Console.ReadKey();
                            menu();
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Такое нельзя вводить");
                        Console.ReadKey();
                        Console.Clear();
                        goto try5;
                    }

                }
                else if (date2D < date1D)
                {
                    chuk = chuk + 20;
                    Console.WriteLine("Цена за штуку: " + chuk);
                try5:
                    try
                    {
                        Console.WriteLine("На складе " + kol);
                        if (kol == 0)
                        {
                            Console.WriteLine("Больше нету этого продукта");
                            Console.ReadKey();
                            menu();
                        }
                        Console.Write("Сколько вы хотите? Введите число: ");
                        int skok = Convert.ToInt32(Console.ReadLine());
                        if (skok > kol)
                        {
                            Console.WriteLine("Столько нету");
                            Console.ReadKey();
                            Console.Clear();
                            goto try5;
                        }
                        else
                        {
                            Directory.CreateDirectory(@"C:\Debug\заказ\" + log);
                            File.Create(@"C:\Debug\заказ\" + log + ".dat");
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\заказ\" + log + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(name);
                                zhurnal.Write(kategor);
                                zhurnal.Write(skok);
                                zhurnal.Write(chuk);
                                zhurnal.Write(mest);
                            }
                            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                            {
                                name = zhurnal.ReadString();
                                chuk = zhurnal.ReadInt32();
                                kol = zhurnal.ReadInt32();
                                dd1 = zhurnal.ReadString();
                                zhurnal.Close();
                            }
                            int ko111 = kol - skok;
                            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                            {
                                zhurnal.Write(name);
                                zhurnal.Write(chuk);
                                zhurnal.Write(ko111);
                                zhurnal.Write(dd1);
                            }
                            Console.WriteLine("Добавленно в корзину");
                            Console.ReadKey();
                            menu();
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Такое нельзя вводить");
                        Console.ReadKey();
                        Console.Clear();
                        goto try5;
                    }
                }
            }
            else
            {
                Console.WriteLine("Вы ввели как-то не так");
                Console.ReadKey();
                goto try2;
            }

        }
        else
        {
            Console.WriteLine("Вы ввели что-то не так");
            Console.ReadKey();
            goto try1;
        }
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);

        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 4;
                Text(4);
            }
            if (num == 5)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class prodav
{
    static string[] texts = new string[] { "Продавец\n", "1: Оформить покупку", "2: Удалить покупку", "3: Выход" };

    static string log, pas, mest, dol, obr, secname, name;
    static int god, zar;
    public void prod()
    {
        menu();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { oform(); }; break;
            case 2: { ubr(); } break;
            case 3: { vixod(); } break;
            case 4: { }; break;
        }
    }
    static string namePP, kategor, mestP;
    static int kol, chuk;
    static void ubr()
    {
    go:
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\продавец.dat", FileMode.Open)))
        {
            log = zhurnal.ReadString();
            pas = zhurnal.ReadString();
            mest = zhurnal.ReadString();
            dol = zhurnal.ReadString();
            obr = zhurnal.ReadString();
            secname = zhurnal.ReadString();
            name = zhurnal.ReadString();
            god = zhurnal.ReadInt32();
            zar = zhurnal.ReadInt32();
            zhurnal.Close();
        }
        Console.Clear();
        int a = 0;
        DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\заказ\");
        foreach (FileInfo files in die1.GetFiles())
        {
            Console.WriteLine("Заказ человека ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Ещё никто не сделал заказ");
            Console.ReadKey();
            menu();
        }
        Console.WriteLine("Выберете человека, которому хотите отклонить заказ");
        string nameP = Console.ReadLine();
        if (File.Exists(@"C:\Debug\заказ\" + nameP + ".dat"))
        {
            a = 0;
        Da:
            DirectoryInfo die = new DirectoryInfo(@"C:\Debug\заказ\" + nameP + @"\");
            foreach (FileInfo file in die.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(file.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Он ещё ничего не заказал");
                Console.ReadKey();
                menu();
            }
            Console.WriteLine("Введите продукт, который хотите отлконить. Если хотите выйти, введите ВЫХОД");

            string prod = Console.ReadLine();
            if (prod == "ВЫХОД")
            {
                menu();
            }
            if (File.Exists(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat"))
            {
                string email;
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + nameP + ".dat", FileMode.Open)))
                {
                    email = zhurnal.ReadString();
                    string logG = zhurnal.ReadString();
                    string pasP = zhurnal.ReadString();
                    zhurnal.Close();
                }
                // отправитель - устанавливаем адрес и отображаемое в письме имя
                MailAddress from = new MailAddress("yurakoshke@mail.ru", "Сеть Магазинов ZaraS");
                // кому отправляем
                MailAddress to = new MailAddress(email);
                // создаем объект сообщения
                MailMessage m = new MailMessage(from, to);
                // тема письма
                m.Subject = "ОТМЕНА ЗАКАЗА человека по ID " + nameP;
                // текст письма
                m.Body = "Ваш заказ был отменён";
                // письмо представляет код html
                m.IsBodyHtml = true;
                // адрес smtp-сервера и порт, с которого будем отправлять письмо
                SmtpClient smtp = new SmtpClient("smtp.mail.ru", 25);
                // логин и пароль
                smtp.Credentials = new NetworkCredential("yurakoshke@mail.ru", "zekindaplaneta");
                smtp.EnableSsl = true;
                smtp.Send(m);
                string dd1 = "";
                string namD, dd1P, kategorP;
                int chukP, kolP;
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat", FileMode.Open)))
                {
                    namD = zhurnal.ReadString();
                    kategorP = zhurnal.ReadString();
                    kolP = zhurnal.ReadInt32();
                    chukP = zhurnal.ReadInt32();
                    mest = zhurnal.ReadString();
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategorP + @"\" + namD + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                int ko111 = kol + kolP;
                using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mest + @"\склад\" + kategorP + @"\" + namD + ".dat", FileMode.OpenOrCreate)))
                {
                    zhurnal.Write(name);
                    zhurnal.Write(chuk);
                    zhurnal.Write(ko111);
                    zhurnal.Write(dd1);
                }
                File.Delete(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat");
                Console.WriteLine("Заказ отменён");
                Console.ReadKey();
                goto Da;
            }
            else
            {
                Console.WriteLine("Такого продукта нету");
                Console.ReadKey();
                goto Da;
            }

        }
        else
        {
            Console.WriteLine("Такого покупателя нет");
            Console.ReadKey();
            goto go;
        }
    }
    static void oform()
    {
    go:
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\продавец.dat", FileMode.Open)))
        {
            log = zhurnal.ReadString();
            pas = zhurnal.ReadString();
            mest = zhurnal.ReadString();
            dol = zhurnal.ReadString();
            obr = zhurnal.ReadString();
            secname = zhurnal.ReadString();
            name = zhurnal.ReadString();
            god = zhurnal.ReadInt32();
            zar = zhurnal.ReadInt32();
            zhurnal.Close();
        }
        Console.Clear();
        int a = 0;
        DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\заказ\");
        foreach (FileInfo files in die1.GetFiles())
        {
            Console.WriteLine("Заказ человека ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Ещё никто не сделал заказ");
            Console.ReadKey();
            menu();
        }
        Console.WriteLine("Выберете человека, которому хотите оформить заказ");
        string nameP = Console.ReadLine();
        if (File.Exists(@"C:\Debug\заказ\" + nameP + ".dat"))
        {
            a = 0;
        Da:
            DirectoryInfo die = new DirectoryInfo(@"C:\Debug\заказ\" + nameP + @"\");
            foreach (FileInfo file in die.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(file.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Он ешё ничего не заказал");
                Console.ReadKey();
                menu();
            }
            Console.WriteLine("Введите продукт, который оформите. Если хотите выйти, введите ВЫХОД");

            string prod = Console.ReadLine();
            if (prod == "ВЫХОД")
            {
                menu();
            }
            else if (File.Exists(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat", FileMode.Open)))
                {
                    namePP = zhurnal.ReadString();
                    kategor = zhurnal.ReadString();
                    kol = zhurnal.ReadInt32();
                    chuk = zhurnal.ReadInt32();
                    mestP = zhurnal.ReadString();
                    zhurnal.Close();
                }
                goto dalshe;
            }
            else
            {
                Console.WriteLine("Такого заказа нет");
                Console.ReadKey();
                goto Da;
            }
        dalshe:
            if (mestP == mest)
            {
                string email;
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + nameP + ".dat", FileMode.Open)))
                {
                    email = zhurnal.ReadString();
                    string logG = zhurnal.ReadString();
                    string pasP = zhurnal.ReadString();
                    zhurnal.Close();
                }
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat", FileMode.Open)))
                {
                    namePP = zhurnal.ReadString();
                    kategor = zhurnal.ReadString();
                    kol = zhurnal.ReadInt32();
                    chuk = zhurnal.ReadInt32();
                    mestP = zhurnal.ReadString();
                    zhurnal.Close();
                }
                int obsh11 = 20 * kol;
                int obsh = kol * chuk;
                Console.WriteLine("Оформляем заказ..");
                Thread.Sleep(2000);
                // отправитель - устанавливаем адрес и отображаемое в письме имя
                MailAddress from = new MailAddress("yurakoshke@mail.ru", "Сеть Магазинов Zara");
                // кому отправляем
                MailAddress to = new MailAddress(email);
                // создаем объект сообщения
                MailMessage m = new MailMessage(from, to);
                // тема письма
                m.Subject = "Чек человека по ID " + nameP;
                // текст письма
                m.Body = "Ваш продукт оформлен на сумму: " + obsh + ". Наименование продукта: " + namePP + ". Колличество продуктов: " + kol + ". Цена за штуку: " + chuk;
                // письмо представляет код html
                m.IsBodyHtml = true;
                // адрес smtp-сервера и порт, с которого будем отправлять письмо
                SmtpClient smtp = new SmtpClient("smtp.mail.ru", 25);
                // логин и пароль
                smtp.Credentials = new NetworkCredential("yurakoshke@mail.ru", "zekindaplaneta");
                smtp.EnableSsl = true;
                smtp.Send(m);
                Random rnd = new Random();
                int value = rnd.Next(0, 100000);
                DateTime date = DateTime.Today;
                string dd = Convert.ToString(date);
            agada:
                if (File.Exists(@"C:\Debug\бюджет\бюджет.dat"))
                {
                    int aga = 0, aga1 = 0;
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\бюджет\бюджет.dat", FileMode.Open)))
                    {
                        aga = zhurnal.ReadInt32();
                    }
                    aga1 = obsh11 + aga;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\бюджет\бюджет.dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(aga1);
                    }
                }
                else
                {
                    int da = 1000000;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\бюджет\бюджет.dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(da);
                        goto agada;
                    }
                }
                if (File.Exists(@"C:\Debug\Отчёты\" + value + ".dat"))
                {
                    int obsh1 = 0;
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + value + ".dat", FileMode.Open)))
                    {
                        obsh1 = zhurnal.ReadInt32();
                        dd = zhurnal.ReadString();
                    }
                    obsh11 = obsh11 + obsh1;
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\Отчёты\" + value + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(obsh11);
                        zhurnal.Write(dd);
                    }
                }
                else
                {
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\Отчёты\" + value + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(obsh11);
                        zhurnal.Write(dd);
                    }
                }
                File.Delete(@"C:\Debug\заказ\" + nameP + @"\" + prod + ".dat");
                File.Delete(@"C:\Debug\СетьМагазиновАхеть\магазины\" + mestP + @"\склад\" + kategor + @"\" + name + ".dat");
                Console.WriteLine("Заказ оформлен");
                Console.ReadKey();
                goto Da;

            }
            else
            {
                Console.WriteLine("Нету доступа к этому продукту");
                Console.ReadKey();
                goto Da;
            }

        }
        else
        {
            Console.WriteLine("Такого покупателя нет");
            Console.ReadKey();
            goto go;
        }
    }
    static void vixod()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 4;
                Text(4);
            }
            if (num == 5)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class Program
{

    static string[] texts = new string[] { "Сеть магазинов Zara\n",
                "1: Зарегистрироваться", "2: Войти", "3: Выход"};
    static string logA, pasA;

    static void Main(string[] args)
    {
        p1();
    }
    static void kardprov()
    {
        Console.WriteLine("Проверим, есть-ли админ.");
        Console.WriteLine("Проверка...");
        Thread.Sleep(2000);
        string[] AllFiles = Directory.GetFiles(@"C:\Debug\Админ\");
        int a = 0;
        foreach (string namefile in AllFiles)
        {
            a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Админ не найден.");
            Console.WriteLine("Создадим админа");
            Console.ReadKey();
            Console.Clear();
            reglog();
        }
        else
        {
            Console.WriteLine("Админ существует, всё хорошо");
            Thread.Sleep(2000);
            Console.Clear();
            nachalo();
        }
    }
    static void p1()
    {
        Console.WriteLine("Готовим папки");
        Directory.CreateDirectory(@"C:\Debug\Админ");
        Directory.CreateDirectory(@"C:\Debug\люди");
        Directory.CreateDirectory(@"C:\Debug\Отчёты");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\Все логины");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\кадры");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\кладовщик");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\магазины");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\общийсклад");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\Покупатели");
        Directory.CreateDirectory(@"C:\Debug\уволен");
        Directory.CreateDirectory(@"C:\Debug\заказ");
        Directory.CreateDirectory(@"C:\Debug\бюджет");
        Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\всепродавцы\");

        kardprov();

    }
    static void provR()
    {
        reglog();
    }
    static void reglog()
    {
    r:
        int gg = 0;
        try
        {

            Console.Write("Введите логин: ");
            logA = Console.ReadLine();
        }
        catch
        {
            Console.WriteLine("Введите нормально логин");
            Console.ReadKey();
            provR();
        }
        for (int i = 0; i < logA.Length; i++)
        {
            if (((logA[i] >= 'А') && (logA[i] <= 'Я')) || ((logA[i] >= 'а') && (logA[i] <= 'я')) || logA[i] == 'ё')
                gg++;
        }
        if (gg > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Никаких русских символов!");
            Thread.Sleep(2000);
            goto r;
        }
        if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + logA + ".dat"))
        {
            Console.WriteLine("Такой логин уже есть, как так?..");
            Console.ReadKey();
            provR();
        }
        using (BinaryWriter zhurnalI = new BinaryWriter(File.Open(@"C:\Debug\Админ\" + logA + ".dat", FileMode.OpenOrCreate)))
        {
            zhurnalI.Write(logA);
        }
        regpas();

    }
    static void regpas()
    {
    r2:
        Console.Clear();
        Console.Write("Введите пароль: ");
        pasA = Console.ReadLine();
        if (pasA.Length < 8)
        {
            Console.WriteLine();
            Console.WriteLine("Длина пароля не соответствует требованиям безопасности");
            Thread.Sleep(2000);
            goto r2;
        }
        int g1 = 0, g2 = 0, g3 = 0, g4 = 0, g5 = 0, g6 = 0, g7 = 0;
        for (int i = 0; i < pasA.Length; i++)
        {
            if ((pasA[i] >= 'A') && (pasA[i] <= 'Z'))
                g1++;
            if (pasA[i] == '!' || pasA[i] == '@' || pasA[i] == '#' || pasA[i] == '$' || pasA[i] == '%' || pasA[i] == '&' || pasA[i] == '*')
                g2++;

            if (((pasA[i] >= 'А') && (pasA[i] <= 'Я')) || ((pasA[i] >= 'а') && (pasA[i] <= 'я')) || pasA[i] == 'ё')
                g4++;
            if (pasA == null || pasA == "")
                g5++;
            if (pasA.Contains(" "))
                g6++;
        }
        for (int j = 0; j < pasA.Length - 3; j++)
        {
            if (char.IsUpper(pasA[j]) && char.IsUpper(pasA[j + 1]) && char.IsUpper(pasA[j + 2]))
            {
                Console.WriteLine();
                Console.WriteLine("Три заглавных символа в пароле не могут идти подряд, повторите попытку");
                Thread.Sleep(2000);
                goto r2;
            }
            else g7++;
        }
        foreach (char cr in pasA)
            if (Char.IsNumber(cr))
                g3++;

        if (g1 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 заглавных буквы!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g2 < 2)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 2 спец. символа!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g3 < 3)
        {
            Console.WriteLine();
            Console.WriteLine("Минимум 3 цифры!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g4 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Никаких русских символов!");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g5 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Вы ввели пустой пароль");
            Thread.Sleep(2000);
            goto r2;
        }
        if (g6 > 0)
        {
            Console.WriteLine();
            Console.WriteLine("Пароль не должен содержать пробелов");
            Thread.Sleep(2000);
            goto r2;
        }

        else
            create();
    }

    static void create()
    {
        Console.WriteLine("Создаю админа..");
        Thread.Sleep(2000);
        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\Все логины\" + logA + ".dat", FileMode.OpenOrCreate)))
        {
            zhurnal.Write(logA);
            zhurnal.Close();
        }
        using (BinaryWriter zhurnalI = new BinaryWriter(File.Open(@"C:\Debug\Админ\" + logA + ".dat", FileMode.OpenOrCreate)))
        {
            zhurnalI.Write(logA);
            zhurnalI.Write(pasA);
            zhurnalI.Close();
        }
        Console.WriteLine("Вот что мы получили");
        using (BinaryReader zhurnalI = new BinaryReader(File.Open(@"C:\Debug\Админ\" + logA + ".dat", FileMode.Open)))
        {
            logA = zhurnalI.ReadString();
            pasA = zhurnalI.ReadString();
            Console.WriteLine("Ваш логин: {0}  Ваш пороль: {1}", logA, pasA);
            zhurnalI.Close();
        }
        Console.ReadKey();
        Console.WriteLine("Админ создан, переношу в главное меню");
        Thread.Sleep(4000);
        Console.Clear();
        nachalo();
    }
    static void nachalo()
    {
        Console.WriteLine("------------------------------------------------------------------------------------" +
           "------------------------------------------------------------------------------------Добро Пожаловать в Сеть магазинов Zara -------------------------------------------------------------------------------------" +
           "--------------------------------------------------------------------");
        Thread.Sleep(4000); //время 4 секунды - пауза
        menu();
    }

    public void menuGl()
    {
        menu();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { registerMen(); Console.Clear(); }; break;
            case 2: { vxod(); Console.Clear(); } break;
            case 3: { vixod(); Console.Clear(); } break;
            case 4: { }; break;
        }
    }
    static void registerMen()
    {
        register adm = new register();
        adm.registerr();
    }
    static void vxod()
    {
        avtorizachia adm = new avtorizachia();
        adm.into();
    }
    static void vixod()
    {
        Process.GetCurrentProcess().Kill();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);

        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);

        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;

        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 3;
                Text(3);
            }
            if (num == 4)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class kladovshik
{
    static string[] texts = new string[] { "Кладовщик\n", "1: Заказать продукты", "2: Переместить с общего с клада в склад магазина", "3: Просмотреть товары на общем складе", "4: Просмотерть товары в магазине", "5: Бракованные", "6: Выход" };
    public void klad() => menu();

    static void vixod()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { sozdat(); }; break;
            case 2: { peremeshen(); } break;
            case 3: { smotrObsh(); } break;
            case 4: { smotrMag(); }; break;
            case 5: { brak(); }; break;
            case 6: { vixod(); }; break;
            case 7: { }; break;
        }
    }
    static string kategor, name, dd1, nameM;
    static int day, month, chuk, kol, kol2;
    static void brak()
    {
    try1:
        Console.Clear();
        int t = 0;
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
        }
        if (t == 0)
        {
            Console.WriteLine("Там ничего нету");
            Console.ReadKey();
            menu();
        }
        else
            Console.Write("Введите категорию из выше представленных: ");
        kategor = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor))
        {
        try2:
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName));
            }
            Console.Write("Введите продукт из выше представленных: ");
            name = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat"))
            {
                Console.WriteLine("Брак выбан и утилизирован");
                File.Delete(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat");
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Вы ввели как-то не так");
                Console.ReadKey();
                goto try2;
            }
        }
        else
        {
            Console.WriteLine("Вы ввели что-то не так");
            Console.ReadKey();
            goto try1;
        }
    }
    static void smotrMag()
    {

        Console.Clear();
        DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
        foreach (FileInfo files in die2.GetFiles("*.dat"))
        {
            Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName));
        }
        Console.Write("Введите магазин: ");
        nameM = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
        {
        try1:
            int a = 0;
            DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\");
            foreach (FileInfo files in die.GetFiles("*.dat"))
            {
                Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Магазин пуст");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Введите категорию из выше представленных: ");
            kategor = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor))
            {
            try2:
                int b = 0;
                DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\");
                foreach (FileInfo files in die1.GetFiles("*.dat"))
                {
                    Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName)); b++;
                }
                if (b == 0)
                {
                    Console.WriteLine("Продуктов нету");
                    Console.ReadKey();
                    menu();
                }
                Console.Write("Введите продукт из выше представленных: ");
                name = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\" + name + ".dat"))
                {

                    Console.Clear();
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                    {
                        name = zhurnal.ReadString();
                        chuk = zhurnal.ReadInt32();
                        kol = zhurnal.ReadInt32();
                        dd1 = zhurnal.ReadString();
                        zhurnal.Close();
                    }
                    Console.WriteLine("Категория: {0} Продукт: {1} Цена за штуку: {2}  Колличество: {3} Срок годности: {4}", kategor, name, chuk, kol, dd1);
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Вы ввели как-то не так");
                    Console.ReadKey();
                    goto try2;
                }

            }
            else
            {
                Console.WriteLine("Вы ввели что-то не так");
                Console.ReadKey();
                goto try1;
            }
        }
        else
        {
            Console.WriteLine("Такого магазина нету");
            Console.ReadKey();
            menu();
        }
    }

    static void smotrObsh()
    {
    try1:
        Console.Clear();
        int a = 0;
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Магазин пуст");
            Console.ReadKey();
            menu();
        }
        Console.Write("Введите категорию из выше представленных: ");
        kategor = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor))
        {
        try2:
            int b = 0;
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName)); b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Нечего смотреть");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Введите продукт из выше представленных: ");
            name = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                Console.WriteLine("Категория: {0} Продукт: {1} Цена за штуку: {2}  Колличество: {3} Срок годности: {4}", kategor, name, chuk, kol, dd1);
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Вы ввели как-то не так");
                Console.ReadKey();
                goto try2;
            }
        }
        else
        {
            Console.WriteLine("Вы ввели что-то не так");
            Console.ReadKey();
            goto try1;
        }
    }
    static void peremeshen()
    {
    try1:
        Console.Clear();
        int a = 0;
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Нечего перемещать");
            Console.ReadKey();
            menu();
        }
        else
            Console.Write("Введите категорию из выше представленных: ");
        kategor = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor))
        {
        try2:
            int b = 0;
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName)); b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Нечего перемещать");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Введите продукт из выше представленных: ");
            name = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat"))
            {
            try3:
                Console.Clear();
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
                foreach (FileInfo files in die2.GetFiles("*.dat"))
                {
                    Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName));
                }
                Console.WriteLine("Введите название магазин, предсталвенный выше");
                nameM = Console.ReadLine();
                if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
                {

                    DirectoryInfo di = Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor);
                    File.Create(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + ".dat");
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(name);
                        zhurnal.Write(chuk);
                        zhurnal.Write(kol);
                        zhurnal.Write(dd1);
                        zhurnal.Close();
                    }
                    File.Delete(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat");

                    Console.WriteLine("Всё готово");
                    Console.ReadKey();
                    menu();

                }
                else
                {
                    Console.WriteLine("Такого магазина нету");
                    Console.ReadKey();
                    goto try3;
                }

            }
            else
            {
                Console.WriteLine("Вы ввели как-то не так");
                Console.ReadKey();
                goto try2;
            }

        }
        else
        {
            Console.WriteLine("Вы ввели что-то не так");
            Console.ReadKey();
            goto try1;
        }
        Console.ReadKey();
    }
    static void sozdat()
    {
    aga:
        Console.Clear();
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName));
        }
        try
        {
            Console.Write("Введите категорию товара: ");
            kategor = Console.ReadLine();
            DirectoryInfo di = Directory.CreateDirectory(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor);
            using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + ".dat", FileMode.OpenOrCreate)))
            {
            }
        }
        catch
        {
            goto aga;
        }

        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor))
        {
        dada:
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName));
            }
            try
            {
                Console.Write("Введие название продукта: ");
                name = Console.ReadLine();

            }
            catch
            {
                Console.WriteLine("Что-то пошло не так");
                Console.ReadKey();
                goto dada;
            }
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat"))
            {
                Console.WriteLine("Такой продукт уже есть");

            back:
                Console.WriteLine("Если хотите ещё докупить этих продуктов, введите ДА");
                Console.WriteLine("Если хотите изменить срок, колличество и цену об этом продукте, введите НЕТ");
                string yes = Console.ReadLine();
                try
                {
                    if (yes == "ДА")
                    {
                        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                        {
                            name = zhurnal.ReadString();
                            chuk = zhurnal.ReadInt32();
                            kol = zhurnal.ReadInt32();
                            dd1 = zhurnal.ReadString();
                            zhurnal.Close();
                        }
                        Console.WriteLine("У нас есть " + kol + " " + name);
                        Console.WriteLine("Введите колличество, сколько хотите докупить");
                        kol2 = Convert.ToInt32(Console.ReadLine());
                        int kol3 = kol + kol2;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(name);
                            zhurnal.Write(chuk);
                            zhurnal.Write(kol3);
                            zhurnal.Write(dd1);
                        }
                        Console.WriteLine("Вы докупили эти продукты");
                        Console.ReadKey();
                        menu();
                    }
                    else if (yes == "НЕТ")
                    {
                    nono:
                        Console.WriteLine("Введите даты для срока годности:");
                    no:
                        try
                        {
                            Console.Write("Введите месяц: ");
                            month = Convert.ToInt32(Console.ReadLine());
                            if (month > 12)
                            {
                                Console.WriteLine("Всего 12 месяцев");
                                Console.ReadKey();
                                Console.Clear();
                                goto no;
                            }

                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto no;
                        }
                    no1:
                        try
                        {
                            Console.Write("Введите день: ");
                            day = Convert.ToInt32(Console.ReadLine());
                            if (day > 29)
                            {
                                Console.WriteLine("Такого числа нету");
                                Console.ReadKey();
                                Console.Clear();
                                goto no1;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto no1;
                        }
                        DateTime br = new DateTime(2020, month, day);
                        if (br < DateTime.Now)
                        {
                            Console.WriteLine("Дата не может быть меньше сегодняшней даты");
                            Console.ReadKey();
                            Console.Clear();
                            goto nono;
                        }

                    shuk:
                        try
                        {
                            Console.Write("Введите цену за штуку: ");
                            chuk = Convert.ToInt32(Console.ReadLine());
                            if (chuk <= 0)
                            {
                                Console.WriteLine("Мы не можем продовать продукты равные или меньше 0");
                                goto shuk;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto shuk;
                        }
                    shuk1:
                        try
                        {
                            Console.Write("Введите колличество: ");
                            kol = Convert.ToInt32(Console.ReadLine());
                            if (kol <= 0)
                            {
                                Console.WriteLine("Мы не можем купить 0 продуктов или меньше");
                                goto shuk1;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto shuk1;
                        }
                        DateTime dd = new DateTime(2020, month, day);
                        dd1 = Convert.ToString(dd);
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Create)))
                        {
                            zhurnal.Write(name);
                            zhurnal.Write(chuk);
                            zhurnal.Write(kol);
                            zhurnal.Write(dd1);
                        }
                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        menu();

                    }
                    else
                    {
                        Console.WriteLine("Вы ввели не правильно, попробуйте ещё раз");
                        Console.ReadKey();
                        Console.Clear();
                        goto back;
                    }
                }
                catch
                {
                    Console.WriteLine("Что-то пошло не так");
                    Console.ReadKey();
                    goto dada;
                }
            }
            else
            {
            nono:
                Console.WriteLine("Введите даты для срока годности:");
            no:
                try
                {
                    Console.Write("Введите месяц: ");
                    month = Convert.ToInt32(Console.ReadLine());
                    if (month > 12)
                    {
                        Console.WriteLine("Всего 12 месяцев");
                        Console.ReadKey();
                        Console.Clear();
                        goto no;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto no;
                }
            no1:
                try
                {
                    Console.Write("Введите день: ");
                    day = Convert.ToInt32(Console.ReadLine());
                    if (day > 29)
                    {
                        Console.WriteLine("Такого числа нету");
                        Console.ReadKey();
                        Console.Clear();
                        goto no1;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto no1;
                }
                DateTime br = new DateTime(2020, month, day);
                if (br < DateTime.Now)
                {
                    Console.WriteLine("Дата не может быть меньше сегодняшней даты");
                    Console.ReadKey();
                    Console.Clear();
                    goto nono;
                }
            shuk:
                try
                {
                    Console.Write("Введите цену за штуку: ");
                    chuk = Convert.ToInt32(Console.ReadLine());
                    if (chuk <= 0)
                    {
                        Console.WriteLine("Мы не можем продовать продукты равные или меньше 0");
                        goto shuk;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto shuk;
                }
            shuk1:
                try
                {
                    Console.Write("Введите колличество: ");
                    kol = Convert.ToInt32(Console.ReadLine());
                    if (kol <= 0)
                    {
                        Console.WriteLine("Мы не можем купить 0 продуктов или меньше");
                        goto shuk1;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto shuk1;
                }
                try
                {
                    DateTime dd = new DateTime(2020, month, day);
                    dd1 = Convert.ToString(dd);
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(name);
                        zhurnal.Write(chuk);
                        zhurnal.Write(kol);
                        zhurnal.Write(dd1);
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так и система дала сбой");
                    Console.ReadKey();
                    goto dada;
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }

        }
        else
        {
        dada:
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName));
            }
            try
            {
                Console.Write("Введие название продукта: ");
                name = Console.ReadLine();

            }
            catch
            {
                Console.WriteLine("Что-то пошло не так");
                Console.ReadKey();
                goto dada;
            }
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat"))
            {
                Console.WriteLine("Такой продукт уже есть");

            back:
                Console.WriteLine("Если хотите ещё докупить этих продуктов, введите ДА");
                Console.WriteLine("Если хотите изменить срок, колличество и цену об этом продукте, введите НЕТ");
                string yes = Console.ReadLine();
                try
                {
                    if (yes == "ДА")
                    {
                        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                        {
                            name = zhurnal.ReadString();
                            chuk = zhurnal.ReadInt32();
                            kol = zhurnal.ReadInt32();
                            dd1 = zhurnal.ReadString();
                            zhurnal.Close();
                        }
                        Console.WriteLine("У нас есть " + kol + " " + name);
                        Console.WriteLine("Введите колличество, сколько хотите докупить");
                        kol2 = Convert.ToInt32(Console.ReadLine());
                        int kol3 = kol + kol2;
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                        {
                            zhurnal.Write(name);
                            zhurnal.Write(chuk);
                            zhurnal.Write(kol3);
                            zhurnal.Write(dd1);
                        }
                        Console.WriteLine("Вы докупили эти продукты");
                        Console.ReadKey();
                        menu();
                    }
                    else if (yes == "НЕТ")
                    {
                    nono:
                        Console.WriteLine("Введите даты для срока годности:");
                    no:
                        try
                        {
                            Console.Write("Введите месяц: ");
                            month = Convert.ToInt32(Console.ReadLine());
                            if (month > 12)
                            {
                                Console.WriteLine("Всего 12 месяцев");
                                Console.ReadKey();
                                Console.Clear();
                                goto no;
                            }

                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto no;
                        }
                    no1:
                        try
                        {
                            Console.Write("Введите день: ");
                            day = Convert.ToInt32(Console.ReadLine());
                            if (day > 29)
                            {
                                Console.WriteLine("Такого числа нету");
                                Console.ReadKey();
                                Console.Clear();
                                goto no1;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto no1;
                        }
                        DateTime br = new DateTime(2020, month, day);
                        if (br < DateTime.Now)
                        {
                            Console.WriteLine("Дата не может быть меньше сегодняшней даты");
                            Console.ReadKey();
                            Console.Clear();
                            goto nono;
                        }

                    shuk:
                        try
                        {
                            Console.Write("Введите цену за штуку: ");
                            chuk = Convert.ToInt32(Console.ReadLine());
                            if (chuk <= 0)
                            {
                                Console.WriteLine("Мы не можем продовать продукты равные или меньше 0");
                                goto shuk;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto shuk;
                        }
                    shuk1:
                        try
                        {
                            Console.Write("Введите колличество: ");
                            kol = Convert.ToInt32(Console.ReadLine());
                            if (kol <= 0)
                            {
                                Console.WriteLine("Мы не можем купить 0 продуктов или меньше");
                                goto shuk1;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели что-то не так");
                            Console.ReadKey();
                            Console.Clear();
                            goto shuk1;
                        }
                        DateTime dd = new DateTime(2020, month, day);
                        dd1 = Convert.ToString(dd);
                        using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Create)))
                        {
                            zhurnal.Write(name);
                            zhurnal.Write(chuk);
                            zhurnal.Write(kol);
                            zhurnal.Write(dd1);
                        }
                        Console.WriteLine("Всё готово");
                        Console.ReadKey();
                        menu();

                    }
                    else
                    {
                        Console.WriteLine("Вы ввели не правильно, попробуйте ещё раз");
                        Console.ReadKey();
                        Console.Clear();
                        goto back;
                    }
                }
                catch
                {
                    Console.WriteLine("Что-то пошло не так");
                    Console.ReadKey();
                    goto dada;
                }
            }
            else
            {
            nono:
                Console.WriteLine("Введите даты для срока годности:");
            no:
                try
                {
                    Console.Write("Введите месяц: ");
                    month = Convert.ToInt32(Console.ReadLine());
                    if (month > 12)
                    {
                        Console.WriteLine("Всего 12 месяцев");
                        Console.ReadKey();
                        Console.Clear();
                        goto no;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto no;
                }
            no1:
                try
                {
                    Console.Write("Введите день: ");
                    day = Convert.ToInt32(Console.ReadLine());
                    if (day > 29)
                    {
                        Console.WriteLine("Такого числа нету");
                        Console.ReadKey();
                        Console.Clear();
                        goto no1;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto no1;
                }
                DateTime br = new DateTime(2020, month, day);
                if (br < DateTime.Now)
                {
                    Console.WriteLine("Дата не может быть меньше сегодняшней даты");
                    Console.ReadKey();
                    Console.Clear();
                    goto nono;
                }
            shuk:
                try
                {
                    Console.Write("Введите цену за штуку: ");
                    chuk = Convert.ToInt32(Console.ReadLine());
                    if (chuk <= 0)
                    {
                        Console.WriteLine("Мы не можем продовать продукты равные или меньше 0");
                        goto shuk;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto shuk;
                }
            shuk1:
                try
                {
                    Console.Write("Введите колличество: ");
                    kol = Convert.ToInt32(Console.ReadLine());
                    if (kol <= 0)
                    {
                        Console.WriteLine("Мы не можем купить 0 продуктов или меньше");
                        goto shuk1;
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так");
                    Console.ReadKey();
                    Console.Clear();
                    goto shuk1;
                }
                try
                {
                    DateTime dd = new DateTime(2020, month, day);
                    dd1 = Convert.ToString(dd);
                    using (BinaryWriter zhurnal = new BinaryWriter(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.OpenOrCreate)))
                    {
                        zhurnal.Write(name);
                        zhurnal.Write(chuk);
                        zhurnal.Write(kol);
                        zhurnal.Write(dd1);
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели что-то не так и система дала сбой");
                    Console.ReadKey();
                    goto dada;
                }
                Console.WriteLine("Всё готово");
                Console.ReadKey();
                menu();
            }

        }
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
        }
        if (i == 5)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[5]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[6]);
        }
        if (i == 6)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[6]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 6;
                Text(6);
            }
            if (num == 7)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class bux
{
    static string[] texts = new string[] { "Бухгалтер\n", "1: Просмотреть прибыль", "2: Просмотреть зарплаты", "3: Просмотреть бюджет компании", "4: Выход", };
    public void buc()
    {
        menu();
    }
    static void vixod()
    {
        Console.Clear();
        Program adm = new Program();
        adm.menuGl();
    }
    static string log, pas, mest, dol, obr, secname, name, nacha1;
    static int god, zar, nacha;
    static void getPP()
    {
        Console.Clear();
        DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\Отчёты\");
        DirectoryInfo die11 = new DirectoryInfo(@"C:\Debug\Отчёты\");
        int obsh1 = 0, vse12 = 0, vse11 = 0, vse10 = 0, vse9 = 0, vse8 = 0, vse7 = 0, vse6 = 0, vse5 = 0, vse4 = 0, vse3 = 0, vse2 = 0, vse1 = 0;
        string dd = " ";
        DateTime data12 = new DateTime(2020, 12, 1); DateTime data121 = new DateTime(2020, 12, 31);
        DateTime data11 = new DateTime(2020, 11, 1); DateTime data111 = new DateTime(2020, 11, 30);
        DateTime data10 = new DateTime(2020, 10, 1); DateTime data101 = new DateTime(2020, 10, 31);
        DateTime data9 = new DateTime(2020, 9, 1); DateTime data91 = new DateTime(2020, 9, 30);
        DateTime data8 = new DateTime(2020, 8, 1); DateTime data81 = new DateTime(2020, 8, 31);
        DateTime data7 = new DateTime(2020, 7, 1); DateTime data71 = new DateTime(2020, 7, 31);
        DateTime data6 = new DateTime(2020, 6, 1); DateTime data61 = new DateTime(2020, 6, 30);
        DateTime data5 = new DateTime(2020, 5, 1); DateTime data51 = new DateTime(2020, 5, 31);
        DateTime data4 = new DateTime(2020, 4, 1); DateTime data41 = new DateTime(2020, 4, 30);
        DateTime data3 = new DateTime(2020, 3, 1); DateTime data31 = new DateTime(2020, 3, 31);
        DateTime data2 = new DateTime(2020, 2, 1); DateTime data21 = new DateTime(2020, 2, 29);
        DateTime data1 = new DateTime(2020, 1, 1); DateTime data1L = new DateTime(2020, 1, 31);
        DateTime prev = new DateTime(2020, 1, 1); DateTime vtor = new DateTime(2020, 6, 30);
        DateTime prev1 = new DateTime(2020, 7, 1); DateTime vtor1 = new DateTime(2020, 12, 31);
        DateTime god1 = new DateTime(2020, 1, 1); DateTime god2 = new DateTime(2020, 12, 31);
        DateTime date = new DateTime();
        foreach (FileInfo files in die1.GetFiles("*.dat"))
        {
            Console.WriteLine("Отчёт: " + Path.GetFileNameWithoutExtension(files.FullName));
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();
            }
            Console.WriteLine("Колличество прибыли: " + obsh1);
            Console.WriteLine("Дата прибылт: " + dd);
        }

        foreach (FileInfo files1 in die11.GetFiles("*.dat"))
        {

            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files1, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();
            }
            date = Convert.ToDateTime(dd);
            if (data12 <= date && date <= data121)
            {
                vse12 = vse12 + obsh1;
            }
            if (data11 <= date && date <= data111)
            {
                vse11 = vse11 + obsh1;
            }
            if (data10 <= date && date <= data101)
            {
                vse10 = vse10 + obsh1;
            }
            if (data9 <= date && date <= data91)
            {
                vse9 = vse9 + obsh1;
            }
            if (data8 <= date && date <= data81)
            {
                vse8 = vse8 + obsh1;
            }
            if (data7 <= date && date <= data71)
            {
                vse7 = vse7 + obsh1;
            }
            if (data6 <= date && date <= data61)
            {
                vse6 = vse6 + obsh1;
            }
            if (data5 <= date && date <= data51)
            {
                vse5 = vse5 + obsh1;
            }
            if (data4 <= date && date <= data41)
            {
                vse4 = vse4 + obsh1;
            }
            if (data3 <= date && date <= data31)
            {
                vse3 = vse3 + obsh1;
            }
            if (data2 <= date && date <= data21)
            {
                vse2 = vse2 + obsh1;
            }
            if (data1 <= date && date <= data1L)
            {
                vse1 = vse1 + obsh1;
            }
        }
        Console.WriteLine();
        Console.WriteLine("Прибыль за этот Январь: " + vse1);
        Console.WriteLine("Прибыль за этот Февраль: " + vse2);
        Console.WriteLine("Прибыль за этот Март: " + vse3);
        Console.WriteLine("Прибыль за этот Апрель: " + vse4);
        Console.WriteLine("Прибыль за этот Май: " + vse5);
        Console.WriteLine("Прибыль за этот Июнь: " + vse6);
        Console.WriteLine("Прибыль за этот Июль: " + vse7);
        Console.WriteLine("Прибыль за этот Август: " + vse8);
        Console.WriteLine("Прибыль за этот Сентябрь: " + vse9);
        Console.WriteLine("Прибыль за этот Октябрь: " + vse10);
        Console.WriteLine("Прибыль за этот Ноябрь: " + vse11);
        Console.WriteLine("Прибыль за этот Декабрь: " + vse12);
        Console.WriteLine();
        vse1 = 0; vse2 = 0;
        foreach (FileInfo files in die1.GetFiles("*.dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();

            }
            date = Convert.ToDateTime(dd);
            if (prev <= date && date <= vtor)
            {
                vse1 = vse1 + obsh1;
            }
            if (prev1 <= date && date <= vtor1)
            {
                vse2 = vse2 + obsh1;
            }
        }
        Console.WriteLine("Прибыль за Первое полугодие: " + vse1);
        Console.WriteLine("Прибыль за Второе полугодие: " + vse2);
        Console.WriteLine();
        vse1 = 0;
        foreach (FileInfo files in die1.GetFiles("*.dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();

            }
            date = Convert.ToDateTime(dd);
            if (god1 <= date && date <= god2)
            {
                vse1 = vse1 + obsh1;
            }
        }
        Console.WriteLine("Прибыль за этот год: " + vse1);
        Console.ReadKey();
        menu();
    }
    static void getZZ()
    {
    tru:
        Console.Clear();
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность по которой вы хотите просмотреть данные");
        DateTime data = new DateTime(1000, 1, 1);
        DateTime data1 = DateTime.Today;
        DateTime data2 = new DateTime(1000, 1, 1);

        string dolzh = Console.ReadLine();
        if (dolzh == "кладовщик")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                }
                zar = 14760;
                data = Convert.ToDateTime(nacha1);
                int month = int.Parse(data.ToString("MM"));
                int month1 = int.Parse(data1.ToString("MM"));
                Console.WriteLine("Зарплата за месяц " + zar);
                Console.WriteLine();
                zar = zar * 6;
                Console.WriteLine("Возможная зарплата за полгода " + zar);
                Console.WriteLine();
                zar = zar + zar;
                Console.WriteLine("Возможная зарплата за год " + zar);
                Console.WriteLine();
                zar = zar / 12;
                month = month1 - month;
                zar = zar * month;
                Console.WriteLine("Зарплата за всё время " + zar);
                Console.ReadKey();
                menu();

            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }
        }
        else if (dolzh == "кадры")
        {
        klad:
            int b = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName));
                b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                }
                zar = 16728;
                data = Convert.ToDateTime(nacha1);
                int month = int.Parse(data.ToString("MM"));
                int month1 = int.Parse(data1.ToString("MM"));
                Console.WriteLine("Зарплата за месяц " + zar);
                Console.WriteLine();
                zar = zar * 6;
                Console.WriteLine("Возможная зарплата за полгода " + zar);
                Console.WriteLine();
                zar = zar + zar;
                Console.WriteLine("Возможная зарплата за год " + zar);
                Console.WriteLine();
                zar = zar / 12;
                month = month1 - month;
                zar = zar * month;
                Console.WriteLine("Зарплата за всё время " + zar);
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }

        }
        else if (dolzh == "бухгалтер")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека:");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                }
                zar = 17712;
                data = Convert.ToDateTime(nacha1);
                int month = int.Parse(data.ToString("MM"));
                int month1 = int.Parse(data1.ToString("MM"));
                Console.WriteLine("Зарплата за месяц " + zar);
                Console.WriteLine();
                zar = zar * 6;
                Console.WriteLine("Возможная зарплата за полгода " + zar);
                Console.WriteLine();
                zar = zar + zar;
                Console.WriteLine("Возможная зарплата за год " + zar);
                Console.WriteLine();
                zar = zar / 12;
                month = month1 - month;
                zar = zar * month;
                Console.WriteLine("Зарплата за всё время " + zar);
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (dolzh == "кассир")
        {
        try3:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            int k = 0;
            foreach (FileInfo files in die2.GetFiles("*.dat"))
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); k++;
            }
            if (k == 0)
            {
                Console.WriteLine("Магазинов ещё нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере магазин");
            string nameM = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
            {
            klad:
                int t = 0;
                DirectoryInfo diel = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\");
                foreach (FileInfo filesN in diel.GetFiles())
                {
                    Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(filesN.FullName)); t++;
                }
                if (t == 0)
                {
                    Console.WriteLine("Тут никого нету");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере ID человека");
                string id = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat"))
                {
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        nacha1 = zhurnal.ReadString();
                    }
                    zar = 9840;
                    data = Convert.ToDateTime(nacha1);
                    int month = int.Parse(data.ToString("MM"));
                    int month1 = int.Parse(data1.ToString("MM"));
                    Console.WriteLine("Зарплата за месяц " + zar);
                    Console.WriteLine();
                    zar = zar * 6;
                    Console.WriteLine("Возможная зарплата за полгода " + zar);
                    Console.WriteLine();
                    zar = zar + zar;
                    Console.WriteLine("Возможная зарплата за год " + zar);
                    Console.WriteLine();
                    zar = zar / 12;
                    month = month1 - month;
                    zar = zar * month;
                    Console.WriteLine("Зарплата за всё время " + zar);
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такой человек не найдет");
                    Console.ReadKey();
                    goto klad;
                }

            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                Console.Clear();
                goto try3;
            }
        }
        else
        {
            Console.WriteLine("Такой должности нету");
            Console.ReadKey();
            Console.Clear();
            goto tru;

        }
    }
    static void getBUD()
    {
        Console.Clear();
        int aga = 0;
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\бюджет\бюджет.dat", FileMode.Open)))
        {
            aga = zhurnal.ReadInt32();
        }
        Console.WriteLine("Бюджет: " + aga);
        Console.ReadKey();
        menu();
    }

    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { getPP(); }; break;
            case 2: { getZZ(); } break;
            case 3: { getBUD(); } break;
            case 4: { vixod(); }; break;
            case 5: { }; break;
        }
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 4;
                Text(4);
            }
            if (num == 5)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }
}
class adminget
{
    static string[] texts = new string[] { "Админестратор\n", "1: Просмотреть людей", "2: Просмотреть людей в сети", "3: Просмотреть общий склад", "4: Просмотреть склады в магазине", "5: Просмотреть доходы", "6: Просмотреть зарплаты", "7: Просмотреть бюджет компании", "8: Просмотреть покупателей", "9: Выход" };
    public void getI()
    {
        menu();
    }
    static void menu()
    {
        Console.Clear();
        foreach (string text in texts)
            Console.WriteLine(text);
        int num = keys();//вызов менюшки 
        switch (num)
        {
            case 1: { getLud(); }; break;
            case 2: { proVz(); } break;
            case 3: { smotrObsh(); } break;
            case 4: { smotrMag(); }; break;
            case 5: { getPP(); }; break;
            case 6: { getZZ(); }; break;
            case 7: { getBUD(); }; break;
            case 8: { getPok(); }; break;
            case 9: { vixod(); }; break;
            case 10: { }; break;
        }
    }
    static string email, log, pas, mest, dol, obr, secname, name, nacha1;
    static int god, zar, nacha;

    static string kategor, dd1, nameM;
    static int day, month, chuk, kol, kol2;
    static void getPok()
    {
        Console.Clear();
        int a = 0;
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\покупатели\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Покупателя ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Ещё не создали людей");
            Console.ReadKey();
            menu();
        }
        Console.Write("Введите ID покупателя: ");
        log = Console.ReadLine();
        if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log + ".dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\покупатели\" + log + ".dat", FileMode.Open)))
            {
                email = zhurnal.ReadString();
                log = zhurnal.ReadString();
                pas = zhurnal.ReadString();
                Console.WriteLine("Ваш email: {0} Ваш логин: {1}  Ваш пороль: {2}", email, log, pas);
                zhurnal.Close();
            }
            Console.ReadKey();
            menu();
        }
        else
        {
            Console.WriteLine("Такого покупателя нет");
            Console.ReadKey();
            menu();
        }
    }
    static void getLud()
    {
        Console.Clear();
        int a = 0;
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\люди\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Человек ID: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Ещё не создали людей");
            Console.ReadKey();
            menu();
        }
        Console.Write("Введите ID: ");
        log = Console.ReadLine();
        if (File.Exists(@"C:\Debug\люди\" + log + ".dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\люди\" + log + ".dat", FileMode.Open)))
            {
                log = zhurnal.ReadString();
                pas = zhurnal.ReadString();
                mest = zhurnal.ReadString();
                dol = zhurnal.ReadString();
                obr = zhurnal.ReadString();
                secname = zhurnal.ReadString();
                name = zhurnal.ReadString();
                god = zhurnal.ReadInt32();
                zar = zhurnal.ReadInt32();
            }
            Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7}", log, mest, dol, obr, secname, name, god, zar, pas);
            Console.ReadKey();
            menu();
        }
        else
        {
            Console.WriteLine("Такого человека нету");
            Console.ReadKey();
            menu();
        }

    }
    static void getPP()
    {
        Console.Clear();
        DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\Отчёты\");
        DirectoryInfo die11 = new DirectoryInfo(@"C:\Debug\Отчёты\");
        int obsh1 = 0, vse12 = 0, vse11 = 0, vse10 = 0, vse9 = 0, vse8 = 0, vse7 = 0, vse6 = 0, vse5 = 0, vse4 = 0, vse3 = 0, vse2 = 0, vse1 = 0;
        string dd = " ";
        DateTime data12 = new DateTime(2020, 12, 1); DateTime data121 = new DateTime(2020, 12, 31);
        DateTime data11 = new DateTime(2020, 11, 1); DateTime data111 = new DateTime(2020, 11, 30);
        DateTime data10 = new DateTime(2020, 10, 1); DateTime data101 = new DateTime(2020, 10, 31);
        DateTime data9 = new DateTime(2020, 9, 1); DateTime data91 = new DateTime(2020, 9, 30);
        DateTime data8 = new DateTime(2020, 8, 1); DateTime data81 = new DateTime(2020, 8, 31);
        DateTime data7 = new DateTime(2020, 7, 1); DateTime data71 = new DateTime(2020, 7, 31);
        DateTime data6 = new DateTime(2020, 6, 1); DateTime data61 = new DateTime(2020, 6, 30);
        DateTime data5 = new DateTime(2020, 5, 1); DateTime data51 = new DateTime(2020, 5, 31);
        DateTime data4 = new DateTime(2020, 4, 1); DateTime data41 = new DateTime(2020, 4, 30);
        DateTime data3 = new DateTime(2020, 3, 1); DateTime data31 = new DateTime(2020, 3, 31);
        DateTime data2 = new DateTime(2020, 2, 1); DateTime data21 = new DateTime(2020, 2, 29);
        DateTime data1 = new DateTime(2020, 1, 1); DateTime data1L = new DateTime(2020, 1, 31);
        DateTime prev = new DateTime(2020, 1, 1); DateTime vtor = new DateTime(2020, 6, 30);
        DateTime prev1 = new DateTime(2020, 7, 1); DateTime vtor1 = new DateTime(2020, 12, 31);
        DateTime god1 = new DateTime(2020, 1, 1); DateTime god2 = new DateTime(2020, 12, 31);
        DateTime date = new DateTime();
        foreach (FileInfo files in die1.GetFiles("*.dat"))
        {
            Console.WriteLine("Отчёт: " + Path.GetFileNameWithoutExtension(files.FullName));
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();
            }
            Console.WriteLine("Колличество прибыли: " + obsh1);
            Console.WriteLine("Дата прибылт: " + dd);
        }

        foreach (FileInfo files1 in die11.GetFiles("*.dat"))
        {

            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files1, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();
            }
            date = Convert.ToDateTime(dd);
            if (data12 <= date && date <= data121)
            {
                vse12 = vse12 + obsh1;
            }
            if (data11 <= date && date <= data111)
            {
                vse11 = vse11 + obsh1;
            }
            if (data10 <= date && date <= data101)
            {
                vse10 = vse10 + obsh1;
            }
            if (data9 <= date && date <= data91)
            {
                vse9 = vse9 + obsh1;
            }
            if (data8 <= date && date <= data81)
            {
                vse8 = vse8 + obsh1;
            }
            if (data7 <= date && date <= data71)
            {
                vse7 = vse7 + obsh1;
            }
            if (data6 <= date && date <= data61)
            {
                vse6 = vse6 + obsh1;
            }
            if (data5 <= date && date <= data51)
            {
                vse5 = vse5 + obsh1;
            }
            if (data4 <= date && date <= data41)
            {
                vse4 = vse4 + obsh1;
            }
            if (data3 <= date && date <= data31)
            {
                vse3 = vse3 + obsh1;
            }
            if (data2 <= date && date <= data21)
            {
                vse2 = vse2 + obsh1;
            }
            if (data1 <= date && date <= data1L)
            {
                vse1 = vse1 + obsh1;
            }
        }
        Console.WriteLine();
        Console.WriteLine("Прибыль за этот Январь: " + vse1);
        Console.WriteLine("Прибыль за этот Февраль: " + vse2);
        Console.WriteLine("Прибыль за этот Март: " + vse3);
        Console.WriteLine("Прибыль за этот Апрель: " + vse4);
        Console.WriteLine("Прибыль за этот Май: " + vse5);
        Console.WriteLine("Прибыль за этот Июнь: " + vse6);
        Console.WriteLine("Прибыль за этот Июль: " + vse7);
        Console.WriteLine("Прибыль за этот Август: " + vse8);
        Console.WriteLine("Прибыль за этот Сентябрь: " + vse9);
        Console.WriteLine("Прибыль за этот Октябрь: " + vse10);
        Console.WriteLine("Прибыль за этот Ноябрь: " + vse11);
        Console.WriteLine("Прибыль за этот Декабрь: " + vse12);
        Console.WriteLine();
        vse1 = 0; vse2 = 0;
        foreach (FileInfo files in die1.GetFiles("*.dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();

            }
            date = Convert.ToDateTime(dd);
            if (prev <= date && date <= vtor)
            {
                vse1 = vse1 + obsh1;
            }
            if (prev1 <= date && date <= vtor1)
            {
                vse2 = vse2 + obsh1;
            }
        }
        Console.WriteLine("Прибыль за Первое полугодие: " + vse1);
        Console.WriteLine("Прибыль за Второе полугодие: " + vse2);
        Console.WriteLine();
        vse1 = 0;
        foreach (FileInfo files in die1.GetFiles("*.dat"))
        {
            using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\Отчёты\" + files, FileMode.Open)))
            {
                obsh1 = zhurnal.ReadInt32();
                dd = zhurnal.ReadString();

            }
            date = Convert.ToDateTime(dd);
            if (god1 <= date && date <= god2)
            {
                vse1 = vse1 + obsh1;
            }
        }
        Console.WriteLine("Прибыль за этот год: " + vse1);
        Console.ReadKey();
        menu();
    }
    static void getZZ()
    {
    tru:
        Console.Clear();
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность по которой вы хотите просмотреть данные");
        DateTime data = new DateTime(1000, 1, 1);
        DateTime data1 = DateTime.Today;
        string dolzh = Console.ReadLine();
        if (dolzh == "кладовщик")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                }
                zar = 14760;
                data = Convert.ToDateTime(nacha1);
                int month = int.Parse(data.ToString("MM"));
                int month1 = int.Parse(data1.ToString("MM"));
                Console.WriteLine("Зарплата за месяц " + zar);
                Console.WriteLine();
                zar = zar * 6;
                Console.WriteLine("Возможная зарплата за полгода " + zar);
                Console.WriteLine();
                zar = zar + zar;
                Console.WriteLine("Возможная зарплата за год " + zar);
                Console.WriteLine();
                zar = zar / 12;
                month = month1 - month;
                zar = zar * month;
                Console.WriteLine("Зарплата за всё время " + zar);
                Console.ReadKey();
                menu();

            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }
        }
        else if (dolzh == "кадры")
        {
        klad:
            int b = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName));
                b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                }
                zar = 16728;
                data = Convert.ToDateTime(nacha1);
                int month = int.Parse(data.ToString("MM"));
                int month1 = int.Parse(data1.ToString("MM"));
                Console.WriteLine("Зарплата за месяц " + zar);
                Console.WriteLine();
                zar = zar * 6;
                Console.WriteLine("Возможная зарплата за полгода " + zar);
                Console.WriteLine();
                zar = zar + zar;
                Console.WriteLine("Возможная зарплата за год " + zar);
                Console.WriteLine();
                zar = zar / 12;
                month = month1 - month;
                zar = zar * month;
                Console.WriteLine("Зарплата за всё время " + zar);
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }

        }
        else if (dolzh == "бухгалтер")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека:");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                }
                zar = 17712;
                data = Convert.ToDateTime(nacha1);
                int month = int.Parse(data.ToString("MM"));
                int month1 = int.Parse(data1.ToString("MM"));
                Console.WriteLine("Зарплата за месяц " + zar);
                Console.WriteLine();
                zar = zar * 6;
                Console.WriteLine("Возможная зарплата за полгода " + zar);
                Console.WriteLine();
                zar = zar + zar;
                Console.WriteLine("Возможная зарплата за год " + zar);
                Console.WriteLine();
                zar = zar / 12;
                month = month1 - month;
                zar = zar * month;
                Console.WriteLine("Зарплата за всё время " + zar);
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (dolzh == "кассир")
        {
        try3:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            int k = 0;
            foreach (FileInfo files in die2.GetFiles("*.dat"))
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); k++;
            }
            if (k == 0)
            {
                Console.WriteLine("Магазинов ещё нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере магазин");
            string nameM = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
            {
            klad:
                int t = 0;
                DirectoryInfo diel = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\");
                foreach (FileInfo filesN in diel.GetFiles())
                {
                    Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(filesN.FullName)); t++;
                }
                if (t == 0)
                {
                    Console.WriteLine("Тут никого нету");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере ID человека");
                string id = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat"))
                {
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        nacha1 = zhurnal.ReadString();
                    }
                    zar = 9840;
                    data = Convert.ToDateTime(nacha1);
                    int month = int.Parse(data.ToString("MM"));
                    int month1 = int.Parse(data1.ToString("MM"));
                    Console.WriteLine("Зарплата за месяц " + zar);
                    Console.WriteLine();
                    zar = zar * 6;
                    Console.WriteLine("Возможная зарплата за полгода " + zar);
                    Console.WriteLine();
                    zar = zar + zar;
                    Console.WriteLine("Возможная зарплата за год " + zar);
                    Console.WriteLine();
                    zar = zar / 12;
                    month = month1 - month;
                    zar = zar * month;
                    Console.WriteLine("Зарплата за всё время " + zar);
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такой человек не найдет");
                    Console.ReadKey();
                    goto klad;
                }

            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                Console.Clear();
                goto try3;
            }
        }
        else
        {
            Console.WriteLine("Такой должности нету");
            Console.ReadKey();
            Console.Clear();
            goto tru;

        }
    }
    static void getBUD()
    {
        Console.Clear();
        int aga = 0;
        using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\бюджет\бюджет.dat", FileMode.Open)))
        {
            aga = zhurnal.ReadInt32();
        }
        Console.WriteLine("Бюджет: " + aga);
        Console.ReadKey();
        menu();
    }
    static void smotrMag()
    {

        Console.Clear();
        DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
        foreach (FileInfo files in die2.GetFiles("*.dat"))
        {
            Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName));
        }
        Console.Write("Введите магазин: ");
        nameM = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
        {
        try1:
            int a = 0;
            DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\");
            foreach (FileInfo files in die.GetFiles("*.dat"))
            {
                Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
            }
            if (a == 0)
            {
                Console.WriteLine("Магазин пуст");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Введите категорию из выше представленных: ");
            kategor = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor))
            {
            try2:
                int b = 0;
                DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\");
                foreach (FileInfo files in die1.GetFiles("*.dat"))
                {
                    Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName)); b++;
                }
                if (b == 0)
                {
                    Console.WriteLine("Продуктов нету");
                    Console.ReadKey();
                    menu();
                }
                Console.Write("Введите продукт из выше представленных: ");
                name = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\" + name + ".dat"))
                {

                    Console.Clear();
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\склад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                    {
                        name = zhurnal.ReadString();
                        chuk = zhurnal.ReadInt32();
                        kol = zhurnal.ReadInt32();
                        dd1 = zhurnal.ReadString();
                        zhurnal.Close();
                    }
                    Console.WriteLine("Категория: {0} Продукт: {1} Цена за штуку: {2}  Колличество: {3} Срок годности: {4}", kategor, name, chuk, kol, dd1);
                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Вы ввели как-то не так");
                    Console.ReadKey();
                    goto try2;
                }

            }
            else
            {
                Console.WriteLine("Вы ввели что-то не так");
                Console.ReadKey();
                goto try1;
            }
        }
        else
        {
            Console.WriteLine("Такого магазина нету");
            Console.ReadKey();
            menu();
        }
    }

    static void smotrObsh()
    {
    try1:
        Console.Clear();
        int a = 0;
        DirectoryInfo die = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\");
        foreach (FileInfo files in die.GetFiles("*.dat"))
        {
            Console.WriteLine("Категория: " + Path.GetFileNameWithoutExtension(files.FullName)); a++;
        }
        if (a == 0)
        {
            Console.WriteLine("Магазин пуст");
            Console.ReadKey();
            menu();
        }
        Console.Write("Введите категорию из выше представленных: ");
        kategor = Console.ReadLine();
        if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor))
        {
        try2:
            int b = 0;
            DirectoryInfo die1 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\");
            foreach (FileInfo files in die1.GetFiles("*.dat"))
            {
                Console.WriteLine("Продукт: " + Path.GetFileNameWithoutExtension(files.FullName)); b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Нечего смотреть");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Введите продукт из выше представленных: ");
            name = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\общийсклад\" + kategor + @"\" + name + ".dat", FileMode.Open)))
                {
                    name = zhurnal.ReadString();
                    chuk = zhurnal.ReadInt32();
                    kol = zhurnal.ReadInt32();
                    dd1 = zhurnal.ReadString();
                    zhurnal.Close();
                }
                Console.WriteLine("Категория: {0} Продукт: {1} Цена за штуку: {2}  Колличество: {3} Срок годности: {4}", kategor, name, chuk, kol, dd1);
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Вы ввели как-то не так");
                Console.ReadKey();
                goto try2;
            }
        }
        else
        {
            Console.WriteLine("Вы ввели что-то не так");
            Console.ReadKey();
            goto try1;
        }
    }
    static void proVz()
    {
    tru:
        Console.Clear();
        Console.WriteLine("Должности: кладовщик, кадры, бухгалтер, кассир");
        Console.WriteLine("Введите должность по которой вы хотите просмотреть данные");
        string dolzh = Console.ReadLine();
        if (dolzh == "кладовщик")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кладовщик\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кладовщик\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                    Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {9}", log, mest, dol, obr, secname, name, god, zar, pas, nacha);
                }
                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }
        }
        else if (dolzh == "кадры")
        {
        klad:
            int b = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\кадры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName));
                b++;
            }
            if (b == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека: ");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\кадры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                    Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {9}", log, mest, dol, obr, secname, name, god, zar, pas, nacha);
                }

                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;

            }

        }
        else if (dolzh == "бухгалтер")
        {
        klad:
            int t = 0;
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\");
            foreach (FileInfo files in die2.GetFiles())
            {
                Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(files.FullName)); t++;
            }
            if (t == 0)
            {
                Console.WriteLine("Тут никого нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.Write("Выбере ID человека:");
            string id = Console.ReadLine();
            if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat"))
            {
                using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\бухгалтеры\" + id + ".dat", FileMode.Open)))
                {
                    log = zhurnal.ReadString();
                    pas = zhurnal.ReadString();
                    mest = zhurnal.ReadString();
                    dol = zhurnal.ReadString();
                    obr = zhurnal.ReadString();
                    secname = zhurnal.ReadString();
                    name = zhurnal.ReadString();
                    god = zhurnal.ReadInt32();
                    zar = zhurnal.ReadInt32();
                    nacha1 = zhurnal.ReadString();
                    Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {9}", log, mest, dol, obr, secname, name, god, zar, pas, nacha);
                }

                Console.ReadKey();
                menu();
            }
            else
            {
                Console.WriteLine("Такой человек не найдет");
                Console.ReadKey();
                goto klad;
            }
        }
        else if (dolzh == "кассир")
        {
        try3:
            DirectoryInfo die2 = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\");
            int k = 0;
            foreach (FileInfo files in die2.GetFiles("*.dat"))
            {
                Console.WriteLine("Магазин: " + Path.GetFileNameWithoutExtension(files.FullName)); k++;
            }
            if (k == 0)
            {
                Console.WriteLine("Магазинов ещё нету");
                Console.ReadKey();
                menu();
            }
            else
                Console.WriteLine("Выбере магазин для него");
            string nameM = Console.ReadLine();
            if (Directory.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM))
            {
            klad:
                int t = 0;
                DirectoryInfo diel = new DirectoryInfo(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\");
                foreach (FileInfo filesN in diel.GetFiles())
                {
                    Console.WriteLine("ID: " + Path.GetFileNameWithoutExtension(filesN.FullName)); t++;
                }
                if (t == 0)
                {
                    Console.WriteLine("Тут никого нету");
                    Console.ReadKey();
                    menu();
                }
                else
                    Console.WriteLine("Выбере ID человека, которого хотите уволить");
                string id = Console.ReadLine();
                if (File.Exists(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat"))
                {
                    using (BinaryReader zhurnal = new BinaryReader(File.Open(@"C:\Debug\СетьМагазиновАхеть\магазины\" + nameM + @"\продавец\" + id + ".dat", FileMode.Open)))
                    {
                        log = zhurnal.ReadString();
                        pas = zhurnal.ReadString();
                        mest = zhurnal.ReadString();
                        dol = zhurnal.ReadString();
                        obr = zhurnal.ReadString();
                        secname = zhurnal.ReadString();
                        name = zhurnal.ReadString();
                        god = zhurnal.ReadInt32();
                        zar = zhurnal.ReadInt32();
                        nacha1 = zhurnal.ReadString();
                        Console.WriteLine("Логин: {0} Пароль: {8} Место работы: {1} Должность: {2} Образование: {3} Фамилия: {4} Имя: {5} Год Рождения: {6} Зарплата: {7} Дата приёма: {9}", log, mest, dol, obr, secname, name, god, zar, pas, nacha);
                    }

                    Console.ReadKey();
                    menu();
                }
                else
                {
                    Console.WriteLine("Такой человек не найдет");
                    Console.ReadKey();
                    goto klad;
                }

            }
            else
            {
                Console.WriteLine("Такого магазина нету");
                Console.ReadKey();
                Console.Clear();
                goto try3;
            }
        }
        else
        {
            Console.WriteLine("Такой должности нету");
            Console.ReadKey();
            Console.Clear();
            goto tru;

        }
    }
    static void vixod()
    {
        Console.Clear();
        admin adm = new admin();
        adm.admins();
    }
    static void Text(int i)//Замена цвета менющки
    {
        if (i == 1)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);

        }
        if (i == 2)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);
        }
        if (i == 3)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);
        }
        if (i == 4)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);
        }
        if (i == 5)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[5]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);
        }
        if (i == 6)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[6]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);
        }
        if (i == 7)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[7]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[8]);
            Console.WriteLine(texts[9]);
        }
        if (i == 8)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[8]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(texts[9]);
        }
        if (i == 9)
        {
            Console.Clear();
            Console.WriteLine(texts[0]);
            Console.WriteLine(texts[1]);
            Console.WriteLine(texts[2]);
            Console.WriteLine(texts[3]);
            Console.WriteLine(texts[4]);
            Console.WriteLine(texts[5]);
            Console.WriteLine(texts[6]);
            Console.WriteLine(texts[7]);
            Console.WriteLine(texts[8]);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(texts[9]);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
        }
    }
    static int keys()//работа менюшки
    {
        int num = 0;
        bool flag = false;
        do
        {
            ConsoleKeyInfo keyPushed = Console.ReadKey();
            if (keyPushed.Key == ConsoleKey.DownArrow)
            {
                num++;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.UpArrow)
            {
                num--;
                Text(num);
            }
            if (keyPushed.Key == ConsoleKey.Enter)
            {
                flag = true;
            }
            if (num == 0)
            {
                num = 9;
                Text(9);
            }
            if (num == 10)
            {
                num = 1;
                Text(1);
            }
        } while (!flag);
        return num;

    }

}



