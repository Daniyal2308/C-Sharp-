﻿using System;

internal class admingek
{
    internal void admink()
    {
        throw new NotImplementedException();
    }
}