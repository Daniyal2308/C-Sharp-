﻿using System;
using System.Collections.Generic;

public class Library
{
	public List<> Books;
	public Library()
	{
	}
}
