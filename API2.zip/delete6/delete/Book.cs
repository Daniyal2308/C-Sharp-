﻿using System;
using System.Collections.Generic;


namespace delete
{
	public class Book
	{
		public int id { get; set; } 
		public string name { get; set; }
		public string author { get; set; }
		public int year { get; set; }
	}
}
