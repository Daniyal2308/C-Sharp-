﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace flappy_bird_game
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // создать новый экземпляр класса таймера, называемый игровым таймером
        DispatcherTimer gameTimer = new DispatcherTimer();
        // новое целое число силы тяжести удерживает vlaue 8
        int gravity = 8;
        // счётчик
        double score;
        // новый класс rect, чтобы помочь нам обнаруживать столкновения
        Rect FlappyRect;
        // новое логическое значение для проверки, закончилась игра или нет
        bool gameover = false;

        public MainWindow()
        {
            InitializeComponent();
            //установить настройки по умолчанию для таймера
            gameTimer.Tick += gameEngine; // привязать тик таймера к событию игрового движка
            gameTimer.Interval = TimeSpan.FromMilliseconds(20); //установите интервал на 20 миллисекунд

            // запустить функцию запуска игры
            startGame();
        }

        private void Canvas_KeyisDown(object sender, KeyEventArgs e)
        { // если нажата клавиша пробела
            if (e.Key == Key.Space)
            {
                // повернуть изображение птицы на -20 градусов от центрального положения
                flappyBird.RenderTransform = new RotateTransform(-20, flappyBird.Width / 2, flappyBird.Height / 2);
                // измените силу тяжести, чтобы он двигался вверх
                gravity = -8;
            }
            if (e.Key == Key.R && gameover == true)
            {
                // если нажата клавиша r И для логического значения game over установлено значение true
                // запустить функцию запуска игры
                startGame();
            }

        }

        private void Canvas_KeyisUp(object sender, KeyEventArgs e)
        { // если клавиши отпустить, мы изменим угол поворота птички на 5 градусов от центра.
            flappyBird.RenderTransform = new RotateTransform(5, flappyBird.Width / 2, flappyBird.Height / 2);
            //измените силу тяжести на 8, чтобы птица летела вниз, а не вверх
            gravity = 8;

        }
        private void startGame()
        { // это функция запуска игры 
          // эта функция загрузит все значения по умолчанию, чтобы начать эту игру

            // сначала сделайте временное целое число со значением 200
            int temp = 200;

            // установить счет на 0
            score = 0;
            // установите верхнее положение flappy bird на 100 пикселей
            Canvas.SetTop(flappyBird, 100);
            // установить игру на ложь
            gameover = false;

            // в приведенном ниже цикле просто проверяется каждое изображение в этой игре и устанавливается их положение по умолчанию.
            foreach (var x in MyCanvas.Children.OfType<Image>())
            {
                // установить трубы obs1 в положение по умолчанию
                if (x is Image && (string)x.Tag == "obs1")
                {
                    Canvas.SetLeft(x, 500);
                }
                // установить трубы obs2 в положение по умолчанию
                if (x is Image && (string)x.Tag == "obs2")
                {
                    Canvas.SetLeft(x, 800);
                }
                //установить трубы obs3 в положение по умолчанию
                if (x is Image && (string)x.Tag == "obs3")
                {
                    Canvas.SetLeft(x, 1000);
                }
                // установить облака в положение по умолчанию
                if (x is Image && (string)x.Tag == "clouds")
                {
                    Canvas.SetLeft(x, (300 + temp));
                    temp = 800;
                }

            }
            //запустить основной таймер игры
            gameTimer.Start();

        }
        private void gameEngine(object sender, EventArgs e)
        { // это событие игрового движка, связанное с таймером

            // сначала обновите текстовую метку партитуры целым числом
            scoreText.Content = "Рекорд: " + score;

            //свяжите изображение flappy bird с классом flappy rect
            FlappyRect = new Rect(Canvas.GetLeft(flappyBird), Canvas.GetTop(flappyBird), flappyBird.Width - 12, flappyBird.Height - 6);

            // установите гравитацию на изображение развевающейся птицы на холсте
            Canvas.SetTop(flappyBird, Canvas.GetTop(flappyBird) + gravity);

            // проверьте, не ушла ли птица за экран сверху или снизу
            if (Canvas.GetTop(flappyBird) + flappyBird.Height > 490 || Canvas.GetTop(flappyBird) < -30)
            {
                // если это так, мы завершаем игру и показываем текст сброса игры
                gameTimer.Stop();
                gameover = true;
                scoreText.Content += "   Нажмите R чтобы начать игру заново";
            }

            // ниже основной цикл, этот цикл будет проходить через каждое изображение на холсте
            // если он найдет какое-либо изображение с тегами, и следуйте инструкциям с ними

            foreach (var x in MyCanvas.Children.OfType<Image>())
            {
                if ((string)x.Tag == "obs1" || (string)x.Tag == "obs2" || (string)x.Tag == "obs3")
                {

                    //если мы нашли изображение с тегом obs1,2 или 3, то переместим его влево от осыпи

                    Canvas.SetLeft(x, Canvas.GetLeft(x) - 5);

                    // создайте новый прямоугольник под названием столбы и свяжите с ним прямоугольники
                    Rect pillars = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    // если прямая сторона с отрывом и прямая колонна сталкиваются
                    if (FlappyRect.IntersectsWith(pillars))
                    {
                        // остановить таймер, установить игру на истину и показать текст сброса
                        gameTimer.Stop();
                        gameover = true;
                        scoreText.Content += "  Нажмите R чтобы начать игру заново";
                    }

                }

                // если первый слой труб покидает сцену и переходит на -100 пикселей слева
                // нам нужно сбросить трубу, чтобы снова вернуться
                if ((string)x.Tag == "obs1" && Canvas.GetLeft(x) < -100)
                {
                    // сбросить трубу до 800 пикселей
                    Canvas.SetLeft(x, 800);
                    // прибавить 1 к счету
                    score = score + .5;

                }
                //если второй слой труб покидает сцену и переходит на -200 пикселей слева
                if ((string)x.Tag == "obs2" && Canvas.GetLeft(x) < -200)
                {
                    // мы устанавливаем эту трубу на 800 пикселей
                    Canvas.SetLeft(x, 800);
                    // прибавить 1 к счету
                    score = score + .5;
                }
                // если третий слой труб покидает сцену и переходит на -250 пикселей слева
                if ((string)x.Tag == "obs3" && Canvas.GetLeft(x) < -250)
                {
                    //устанавливаем трубу на 800 пикселей
                    Canvas.SetLeft(x, 800);
                    //прибавить 1 к счету
                    score = score + .5;

                }

                // если найдете какое-либо изображение с тегом облаков на нем
                if ((string)x.Tag == "clouds")
                {
                    // then we will slowly move the cloud towards left of the screen
                    Canvas.SetLeft(x, Canvas.GetLeft(x) - .6);


                    // если облака достигли -220 пикселей, мы сбросим его
                    if (Canvas.GetLeft(x) < -220)
                    {
                        // сбросить изображения облаков до 550 пикселей
                        Canvas.SetLeft(x, 550);
                    }
                }
            }

        }
    }
}
