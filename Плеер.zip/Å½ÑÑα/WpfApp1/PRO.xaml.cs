﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using Microsoft.Win32;
using System.Windows.Threading;
using System.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Nub.xaml
    /// </summary>
    public partial class PRO : Window
    {
        List<string> Mus = new List<string>();
        int r = 0;
        int theme = 0;
        string currentplaylist = "Begin";
        MainWindow pc = new MainWindow();
        string f;
        string photopath;
        private DispatcherTimer TimerVideo;
        public PRO(string login)
        {
            InitializeComponent();
            f = login;
            TimerVideo = new DispatcherTimer();
            TimerVideo.Interval = TimeSpan.FromSeconds(0.01);
            TimerVideo.Tick += new EventHandler(timer_tick);
            TimerVideo.Start();
        }
        private void timer_tick(object sender, EventArgs e)
        {
            ShowPosition();
        }
        private void ShowPosition()
        {
            Progres.Value = Player.Position.TotalSeconds;
        }
        private void Pause_Click(object sender, RoutedEventArgs e)
        {
              Progres.Value = Progres.Value;
            if (Player.LoadedBehavior == MediaState.Pause)
            {
                TimerVideo.Start();
                Player.LoadedBehavior = MediaState.Play;
                Pause.Content = "||";
            }
            else
            {
                TimerVideo.Stop();
                Player.LoadedBehavior = MediaState.Pause;
                Pause.Content = "▶";
            }
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\Begin\").Length];
            sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\Begin\");
            foreach (string s in sounds)
            {
                PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\Begin\", ""));
                Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\Begin\", ""));
            }
            string[] pl = new string[Directory.GetDirectories(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\").Length];
            pl = Directory.GetDirectories(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\");
            foreach (string s in pl)
            {
                PL.Items.Add(s.Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\", ""));
            }

            using (BinaryReader read = new BinaryReader(File.Open($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\UserData.dat", FileMode.Open)))
            {
                try
                {
                    read.ReadString();
                    read.ReadString();
                    photopath = read.ReadString();
                }
                catch { }
            }

            if (photopath!=null)
            {
                if (File.Exists(photopath))
                PhotoPrImg.Source = new BitmapImage(new Uri(photopath));

            }
        }
        private void PlayList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
 
            Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + PlayList.SelectedItem + ".mp3");
            Player.LoadedBehavior = MediaState.Play;
            r = PlayList.Items.IndexOf(PlayList.SelectedItem);

        }
        private void Previous_Click(object sender, RoutedEventArgs e)
        {

            if (r == 0)
            {
                r = PlayList.Items.Count - 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
            }
            else
            {
                r -= 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");

            }
        }
        private void Next_Click(object sender, RoutedEventArgs e)
        {

            if (r == Mus.Count - 1)
            {
                r = 0;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }
            else
            {
                r += 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }
        }
        private void Player_MediaEnded(object sender, RoutedEventArgs e)
        {

            Progres.Foreground = Brushes.Blue;
            Next.IsEnabled = true;
            Previous.IsEnabled = true;
            if (r == Mus.Count - 1)
            {
                r = 0;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }
            else
            {
                r += 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }

        }

        private void Progres_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {           

        }

        private void Player_MediaOpened(object sender, RoutedEventArgs e)
        {
            using (BinaryReader read = new BinaryReader(File.Open($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\UserData.dat", FileMode.Open)))
            {
                try
                {
                    read.ReadString();
                    read.ReadString();
                    photopath = read.ReadString();
                }
                catch { }
            }

            if (photopath != null)
            {
                PhotoPrImg.Source = new BitmapImage(new Uri(photopath));

            }


            Progres.Minimum = 0;
            Progres.Maximum = Player.NaturalDuration.TimeSpan.TotalSeconds;

        }
        private void PL_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
               
                                  
        }
        private void ADD_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFD = new OpenFileDialog();
            openFD.Filter = "MP3 files (*.mp3)|*.mp3|WAV files (*.wav)| Pdf files (*.pdf)|WMA files(*.wma)|*.wma";
            openFD.InitialDirectory = @"C:\";
            if (openFD.ShowDialog() == true)
            {
                File.Copy(openFD.FileName, Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\{openFD.SafeFileName}");
                PlayList.Items.Add(Path.GetFileNameWithoutExtension(openFD.SafeFileName));
                Mus.Add((Path.GetFileNameWithoutExtension(openFD.SafeFileName)));
                MediaPlayer mediaPlayer = new MediaPlayer();
            }
        }
        private void Rem_Click(object sender, RoutedEventArgs e)
        {
            File.Delete(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\{PlayList.SelectedItem}.mp3");
            PlayList.Items.Remove(PlayList.SelectedItem);
            Mus.Clear();
            string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
            sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
            foreach (string s in sounds)
            {

                Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
            }
        }
        private void AddPl_Click(object sender, RoutedEventArgs e)
        {
            if (NamePL.Text != "")
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{NamePL.Text}");
                MessageBox.Show("Плейлист создан");
                PL.Items.Add(NamePL.Text);
                NamePL.Text = "";
            }
            else { MessageBox.Show("Имя плейлиста не может быть пустым"); }
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Next_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
          
            
        }

        private void Previous_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void CLIP_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(Directory.GetCurrentDirectory() + $@"\Users\{f}\Clips\" + Mus[r] + ".mp4"))
            {
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Clips\" + Mus[r] + ".mp4");
            }
            else { MessageBox.Show("Клипа к этому треку нет, установите его прежде чем запустить"); }
        }

        private void Progres_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TimerVideo.Stop();
            Player.LoadedBehavior = MediaState.Pause;
        }

        private void Progres_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Player.Position = TimeSpan.FromSeconds(Progres.Value);
            TimerVideo.Start();
            Player.LoadedBehavior = MediaState.Play;
        }

        private void Plus10_Click(object sender, RoutedEventArgs e)
        {
            Player.Position = TimeSpan.FromSeconds(Progres.Value +10);
        }

        private void Minus10_Click(object sender, RoutedEventArgs e)
        {
            Player.Position = TimeSpan.FromSeconds(Progres.Value - 10);
        }
        
        private void RemPl_Click(object sender, RoutedEventArgs e)
        {
            if (currentplaylist != "Begin")
            {
                Directory.Delete(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{PL.SelectedItem}", true);
                PL.Items.Remove(PL.SelectedItem);
                currentplaylist = "Begin";
                PL.Items.Clear();
               string [] pl = Directory.GetDirectories(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\");
                foreach (string s in pl)
                {
                    PL.Items.Add(s.Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\", ""));
                }
                string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
                sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
                foreach (string s in sounds)
                {
                    PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}\", ""));
                    Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
                }
                //r = 0;
                //Mus.Clear();
                //PlayList.Items.Clear();
                //currentplaylist = "Begin";
                //string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
                //sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
                //foreach (string s in sounds)
                //{
                //    PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}\", ""));
                //    Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
                //}
            }
            else MessageBox.Show("Нельзя удалить основной плейлист", "Ошибка");
        }

        private void PL_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Mus.Clear();
            PlayList.Items.Clear();
            currentplaylist = PL.SelectedItem.ToString();
            string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
            sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
            foreach (string s in sounds)
            {
                PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}\", ""));
                Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
            }
        }

        private void Prof_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Profile d = new Profile($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\UserData.dat", f);
            d.Show();
        }

        private void Theme_Click(object sender, RoutedEventArgs e)
        {
            if (theme==0)
            {
                theme = 1;
                ADD.Background = Brushes.Gray;
                Rem.Background = Brushes.Gray;
                AddPl.Background = Brushes.Gray;
                RemPl.Background = Brushes.Gray;
                Minus10.Background = Brushes.Gray;
                Plus10.Background = Brushes.Gray;
                Next.Background = Brushes.Gray;
               Previous.Background = Brushes.Gray;
                CLIP.Background = Brushes.Gray;
                Pro.Background = Brushes.Gray;
            }
            else
            {
                theme = 0;
                ADD.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                Rem.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                AddPl.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                RemPl.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                Minus10.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                Plus10.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                Next.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                Previous.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                CLIP.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));
                Pro.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0x54, 0xCD, 0x40));

            }
        }

       
    }
}
