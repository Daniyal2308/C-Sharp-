﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Registracia.xaml
    /// </summary>
    public partial class Registracia : Window
    {
       //async void block()
       // {
       //     await Task.Run(() =>
       //     {
       //         SendKod.IsEnabled = false;
       //         Task.Delay(10000);
       //         SendKod.IsEnabled = true;
       //     });
       // }
      string kod = "";
        public  Registracia()
        {
            InitializeComponent();
            Kod.Visibility = Visibility.Hidden;
            Passw.Visibility = Visibility.Hidden;
            L2.Visibility = Visibility.Hidden;
            L1.Visibility = Visibility.Hidden;
            Reg.Visibility = Visibility.Hidden;
        }
        private void  SendKod_Click(object sender, RoutedEventArgs e)
        {
            //block();
            SendKod.Visibility = Visibility.Hidden;
            Kod.Visibility = Visibility.Visible;
            L2.Visibility = Visibility.Visible;

            Random rnd = new Random();           
            for (int i = 0; i < 5; i++)
            {
                kod += rnd.Next(0,10);
            }
            MailAddress from = new MailAddress("isip_d.f.ayubov@mpt.ru", "Проверочный код");
            MailAddress to = new MailAddress(MAIL.Text);
            MailMessage m = new MailMessage(from, to);
            m.Subject = "Письмо";
            m.IsBodyHtml = true;
            m.Body = kod;
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.Credentials = new NetworkCredential("isip_d.f.ayubov@mpt.ru", "11111");
            smtp.EnableSsl = true;
            smtp.Send(m);
        }
        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            if (!Directory.Exists(Directory.GetCurrentDirectory() + $@"\C:\Плеер"))
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\C:\Плеер");
            }
            if (Kod.Text == kod)
            { 
            Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\C:\Плеер\{MAIL.Text}");
            Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\C:\Плеер\{MAIL.Text}\Music");
            Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\C:\Плеер\{MAIL.Text}\Music\Begin");
            using (BinaryWriter writer = new BinaryWriter(File.Open(Directory.GetCurrentDirectory() + $@"\C:\{MAIL.Text}\UserData.dat", FileMode.OpenOrCreate)))
            {
                writer.Write(Passw.Text);
                writer.Write("Nub");
            }
            MessageBox.Show("Регистрация успешно завершена!", "Сведения о регистрации");
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
            }
        }
        private void Kod_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Kod.Text.Length == 5)
            {
                SendKod.Visibility = Visibility.Hidden;
                if (Kod.Text.ToString() == kod)
                {
                    Passw.Visibility = Visibility.Visible;
                    L1.Visibility = Visibility.Visible;
                    Reg.Visibility = Visibility.Visible;
                    Kod.Visibility = Visibility.Hidden;
                    L2.Visibility = Visibility.Hidden;
                }
                if (Kod.Text.ToString() != kod)
                {
                  Kod.Text = "";
                    kod = "";
                    SendKod.Visibility = Visibility.Visible;
                    Kod.Visibility = Visibility.Hidden;
                    L1.Visibility = Visibility.Hidden;
                    L2.Visibility = Visibility.Hidden;
                    Reg.Visibility = Visibility.Hidden;
                    Passw.Visibility = Visibility.Hidden;
                }
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        
    }
}
