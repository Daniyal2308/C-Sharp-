﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Profile.xaml
    /// </summary>
    public partial class Profile : Window
    {
        string PATH;
        string f;
        public Profile(string path, string login)
        {
            PATH = path;
            InitializeComponent();
            f = login;
        }
        string photopath;
        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (BinaryReader read = new BinaryReader(File.Open(PATH, FileMode.Open)))
            {
                try
                {
                    read.ReadString();
                    read.ReadString();
                    photopath = read.ReadString();
                }
                catch { }
            }

            if (photopath != null)
            {
             img.Source = new BitmapImage(new Uri(photopath));

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Process.Start(Assembly.GetEntryAssembly().Location);
            Environment.Exit(1);
        }

        private void Phot_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog OPFD = new OpenFileDialog();
            OPFD.InitialDirectory = $@"c:\";
            OPFD.Filter = "Pictures (*.BMP;*.JPG;*PNG;)|*.BMP;*.JPG; *.PNG" ;
            if (OPFD.ShowDialog() == true)
            {
                PATH = OPFD.FileName;
                img.Source = new BitmapImage(new Uri(PATH));
            }
            string pass;
            string mode;
            using (BinaryReader reader = new BinaryReader(File.Open($@"{Directory.GetCurrentDirectory()}" + $@"\С:\Плеер\{f}\UserData.dat", FileMode.Open)))
            {
                pass= reader.ReadString();
                mode = reader.ReadString();
            }
            using (BinaryWriter writer = new BinaryWriter(File.Open($@"{Directory.GetCurrentDirectory()}" + $@"\С:\Плеер\{f}\UserData.dat", FileMode.OpenOrCreate)))
            {
                writer.Write(pass);
                writer.Write(mode);
            }
            using (BinaryWriter writer= new BinaryWriter(File.Open($@"{Directory.GetCurrentDirectory()}" + $@"\С:\Плеер\{f}\UserData.dat", FileMode.Append)))
            {
                writer.Write(PATH);
            }
        }
    }
}
