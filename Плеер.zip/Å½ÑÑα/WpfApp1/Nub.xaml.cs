﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using Microsoft.Win32;
using System.Windows.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Nub.xaml
    /// </summary>
    public partial class Nub : Window
    {
        int schet=0;
        List <string> Mus =new List<string>();
        int r = 0;
        string currentplaylist="Begin";
        MainWindow pc = new MainWindow();
        string f;

        private DispatcherTimer TimerVideo;


        public Nub(string login)
        {
            InitializeComponent();
            f = login;
            TimerVideo = new DispatcherTimer();
            TimerVideo.Interval = TimeSpan.FromSeconds(0.01);
            TimerVideo.Tick += new EventHandler(timer_tick);
            TimerVideo.Start();
            Player.Stop();
        }

        private void timer_tick(object sender, EventArgs e)
        {
            ShowPosition();
        }
        private void ShowPosition()
        {
            Progres.Value = Player.Position.TotalSeconds;
        }
        private void Pause_Click(object sender, RoutedEventArgs e)
        {
            if (Player.LoadedBehavior == MediaState.Pause)
            {
                Player.LoadedBehavior = MediaState.Play;
                Pause.Content = "||";
            }
            else
            {
                Player.LoadedBehavior = MediaState.Pause;
                Pause.Content = "▶";
            }      
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\Begin\").Length];
            sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\Begin\");
            foreach (string s in sounds)
            {
                PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\Begin\", ""));
                Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\Begin\", ""));
            }
            string [] pl = new string[Directory.GetDirectories(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\").Length];
            pl = Directory.GetDirectories(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\");
            foreach (string s in pl)
            {
                PL.Items.Add(s.Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\", ""));               
            }
        }
        private void PlayList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (schet != 5)
            {
                schet += 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + PlayList.SelectedItem + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
                r = PlayList.Items.IndexOf(PlayList.SelectedItem);
            }
        }
        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            schet += 1;

            if (r==0)
            {
                r = PlayList.Items.Count - 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\"+Mus[r]+".mp3");
            } else
            {
                r -= 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\"+Mus[r]+".mp3");

            }
        }
        private void Next_Click(object sender, RoutedEventArgs e)
        {
            schet += 1;
            if (r == Mus.Count-1)
            {
                r = 0;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }
            else
            {
                r += 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }
        }
        private void Player_MediaEnded(object sender, RoutedEventArgs e)
        {
            Progres.Foreground = Brushes.Blue;
            Next.IsEnabled = true;
            Previous.IsEnabled = true;
            schet += 1;
            if (schet == 5)
            {
                Progres.Foreground = Brushes.Yellow;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\ADS.mp3");
                Player.LoadedBehavior = MediaState.Play;
                schet = -1;
                Next.IsEnabled = false;
                Previous.IsEnabled = false;
            }else if (r == Mus.Count - 1)
            {
                r = 0;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }
            else
            {
                r += 1;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\" + Mus[r] + ".mp3");
                Player.LoadedBehavior = MediaState.Play;
            }

        }

        private void Progres_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void Player_MediaOpened(object sender, RoutedEventArgs e)
        {
            Progres.Minimum = 0;
            Progres.Maximum = Player.NaturalDuration.TimeSpan.TotalSeconds;
            if (schet == 5)
            {
                Progres.Foreground = Brushes.Yellow;
                Player.Source = new Uri(Directory.GetCurrentDirectory() + $@"\ADS.mp3");
                Player.LoadedBehavior = MediaState.Play;
                Next.IsEnabled = false;
                Previous.IsEnabled = false;
            }
        }
        private void PL_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          
        }

        private void ADD_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFD = new OpenFileDialog();
            openFD.Filter = "MP3 files (*.mp3)|*.mp3|WAV files (*.wav)| Pdf files (*.pdf)|WMA files(*.wma)|*.wma";
            openFD.InitialDirectory = @"C:\Users\Ilyich\Music\";
            if (openFD.ShowDialog() == true)
            {
                File.Copy(openFD.FileName, Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\{openFD.SafeFileName}");
                PlayList.Items.Add(Path.GetFileNameWithoutExtension(openFD.SafeFileName));
                Mus.Add((Path.GetFileNameWithoutExtension(openFD.SafeFileName)));
                MediaPlayer mediaPlayer = new MediaPlayer();
            }
        }
        private void Rem_Click(object sender, RoutedEventArgs e)
        {
            File.Delete(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\{PlayList.SelectedItem}.mp3");
            PlayList.Items.Remove(PlayList.SelectedItem);
            Mus.Clear();
            string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
            sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
            foreach (string s in sounds)
            {
            
                Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
            }
        }
        private void AddPl_Click(object sender, RoutedEventArgs e)
        {
            if (NamePL.Text != "")
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{NamePL.Text}");
                MessageBox.Show("Плейлист создан");
                PL.Items.Add(NamePL.Text);
                NamePL.Text = "";
            }
            else { MessageBox.Show("Имя плейлиста не может быть пустым"); }
        }

        private void Buy_Click(object sender, RoutedEventArgs e)
        {
            Player.LoadedBehavior = MediaState.Stop;
            BuyFull ful = new BuyFull(Directory.GetCurrentDirectory() + $@"\Users\{f}\UserData.dat", f);
         Player.LoadedBehavior = MediaState.Stop;
            ful.Show();
            this.Hide();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void RemPl_Click(object sender, RoutedEventArgs e)
        {
            if (currentplaylist != "Begin")
            {
                Directory.Delete(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{PL.SelectedItem}", true);
                PL.Items.Remove(PL.SelectedItem);
                currentplaylist = "Begin";
                PL.Items.Clear();
                string[] pl = Directory.GetDirectories(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\");
                foreach (string s in pl)
                {
                    PL.Items.Add(s.Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\", ""));
                }
                string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
                sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
                foreach (string s in sounds)
                {
                    PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}\", ""));
                    Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
                }
            }
            else MessageBox.Show("Нельзя удалить основной плейлист", "Ошибка");
        }

        private void RemPl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            
        }

        private void PL_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Mus.Clear();
            PlayList.Items.Clear();
            currentplaylist = PL.SelectedItem.ToString();
            string[] sounds = new string[Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\").Length];
            sounds = Directory.GetFiles(Directory.GetCurrentDirectory() + $@"\Users\{f}\Music\{currentplaylist}\");
            foreach (string s in sounds)
            {
                PlayList.Items.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}\", ""));
                Mus.Add((s.Replace(".mp3", "")).Replace($@"{Directory.GetCurrentDirectory()}" + $@"\Users\{f}\Music\{currentplaylist}", ""));
            }
        }

        private void Vol_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }
    }
}
