﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       public string ban;
        public MainWindow()
        {
            InitializeComponent();
            if (!Directory.Exists(Directory.GetCurrentDirectory() + $@"\Users"))
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + $@"\Users");

            }
        }
        private void Registr_Click(object sender, RoutedEventArgs e)
        {
            Registracia w = new Registracia();
            w.Show();
            this.Close();
        }
        public string help()
        {
            return Post.Text;
        }
        private void Vhod_Click(object sender, RoutedEventArgs e)
        {
            string pass;
            string lvl;
            if (Directory.Exists(Directory.GetCurrentDirectory() + $@"\Users\{Post.Text}"))
            {
                using (BinaryReader read = new BinaryReader(File.Open(Directory.GetCurrentDirectory() + $@"\Users\{Post.Text}\UserData.dat", FileMode.Open)))
                {
                    pass=read.ReadString();
                    lvl= read.ReadString();
                }

                if (pass == PB.Password)
                {

                    if (lvl == "Nub")
                    {
                        Nub b = new Nub(Post.Text);
                        this.Hide();
                        b.Show();
                    }
                    if (lvl == "Pro")
                    {
                        PRO b = new PRO(Post.Text);
                        this.Hide();
                        b.Show();
                    }
                }
                else { MessageBox.Show("Неправильный пароль"); }
            }
            else { MessageBox.Show("Неправильная почта"); }
        }
    }
}
