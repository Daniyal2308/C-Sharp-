﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для BuyFull.xaml
    /// </summary>
    public partial class BuyFull : Window
    {
        string pat;
        string kod = "";
        public BuyFull( string path, string mail)
        {
            pat = path;
            InitializeComponent();
            Random rnd = new Random();
            for (int i = 0; i < 5; i++)
            {
                kod += rnd.Next(0, 10);
            }
            MailAddress from = new MailAddress("isip_d.f.ayubov@mpt.ru", "Проверочный код");
            MailAddress to = new MailAddress(mail);
            MailMessage m = new MailMessage(from, to);
            m.Subject = "Письмо";
            m.IsBodyHtml = true;
            m.Body = kod;
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            smtp.Credentials = new NetworkCredential("isip_d.f.ayubov@mpt.ru", "StudentMPT666");
            smtp.EnableSsl = true;
            smtp.Send(m);
        }
        private void Kod_TextChanged(object sender, TextChangedEventArgs e)
        {
            string pass = "";
            if (Kod.Text.Length == 5)
            {

                if (Kod.Text.ToString() == kod)
                {
                    using (BinaryReader read = new BinaryReader(File.Open(pat, FileMode.Open)))
                    {
                        pass = read.ReadString();
                    }
                    using (BinaryWriter writer = new BinaryWriter(File.Open(pat, FileMode.OpenOrCreate)))
                    {
                        writer.Write(pass);
                        writer.Write("Pro");
                    }
                    MainWindow b = new MainWindow();
                    b.Show();
                    this.Hide();                   
                }
                if (Kod.Text.ToString() != kod)
                {
                    Kod.Text = "";
                    kod = "";                  
                }
            }
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
