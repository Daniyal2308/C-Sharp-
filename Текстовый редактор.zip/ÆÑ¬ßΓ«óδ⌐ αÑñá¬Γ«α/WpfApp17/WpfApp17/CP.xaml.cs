﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace WpfApp17
{
    /// <summary>
    /// Логика взаимодействия для ColorPicker.xaml
    /// </summary>
    public partial class ColorPicker : Window
    {
       public int[] b = new int[3];
       public int red;
       public int green;
       public int blue;
        public ColorPicker()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            red = (int)SLR.Value;
            green = (int)SLG.Value;
            blue = (int)SLB.Value;
            this.Hide();
        }
        int[] a = new int[3];
        public int[] Colors ()
        {        
            a[0] = red;
            a[1] = green;
            a[2] = blue;
            return a;
        }
        private void SLR_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            red = (int)SLR.Value;
            green = (int)SLG.Value;
            blue = (int)SLB.Value;
            // var SetColor = Color.FromArgb((byte)b[0], (byte)b[1],(byte)b[2],0);
            El.Fill = new SolidColorBrush(Color.FromArgb(255,(byte)red, (byte)green, (byte)blue));
        }

        private void SLG_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            red = (int)SLR.Value;
            green = (int)SLG.Value;
            blue = (int)SLB.Value;
            El.Fill = new SolidColorBrush(Color.FromArgb(255, (byte)red, (byte)green, (byte)blue));
        }

        private void SLB_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            red = (int)SLR.Value;
            green = (int)SLG.Value;
            blue = (int)SLB.Value;
            El.Fill = new SolidColorBrush(Color.FromArgb(255, (byte)red, (byte)green, (byte)blue));
        }
    }
}
