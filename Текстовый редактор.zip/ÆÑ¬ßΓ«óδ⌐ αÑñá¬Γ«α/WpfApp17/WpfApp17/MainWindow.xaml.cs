﻿using Microsoft.Win32;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Drawing;


namespace WpfApp17
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       // bool chek = false; 
        string Fn="";
       
        public MainWindow()
        {
            InitializeComponent();
            

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var aFontsCollection = Fonts.SystemFontFamilies.Select(family => family.ToString()).ToList();//Запись всех системных шрифтов, которые формируется в виде коллекции "List"
            aFontsCollection.Sort();

            var style = new Style(typeof(ComboBoxItem));//запись стиля элемента ComboBox'а  
            var setter = new Setter(FontFamilyProperty, new Binding { Converter = new FontFamilyConvecter() });//Записываем свойства шрифтов
            //К стилям ComboBox'а добавляем свойства шрифтов
            style.Setters.Add(setter);
            ComboBox1.ItemContainerStyle = style;
            //
            ComboBox1.ItemsSource = aFontsCollection;//Вывод всех шрифтов в ComboBox

            for (int i = 8; i < 20; i++)
            {
                ComboBox3.Items.Add(i);
            }
            CB4.Items.Add(1);
            CB4.Items.Add(1.5);
            CB4.Items.Add(2);
            CB4.Items.Add(3);
        }

        private void ComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e) //Вид шрифта
        {
            var selectedFontFamily = new FontFamily(ComboBox1.SelectedItem.ToString());//Присваиваем выбранный ШРИФТ в переменную selectedFontFamily
            TextSelection text = RichText.Selection;//Записываем выбранные текст в переменную text класса TextSelection
            if (!text.IsEmpty)//Проверяем на пустое выделенного значения
            {
                text.ApplyPropertyValue(TextElement.FontFamilyProperty, selectedFontFamily); //Изменяем шрифт выделенного текста
            }
        }

     
        private void ComboBox3_SelectionChanged(object sender, SelectionChangedEventArgs e) //Размер шрифта
        {
            TextSelection text = RichText.Selection;
            if (!text.IsEmpty)
            {
                text.ApplyPropertyValue(TextElement.FontSizeProperty, ComboBox3.SelectedItem.ToString());
            }
        }

        private void OP_Click(object sender, RoutedEventArgs e) //Кнопка открыть
        {
            OpenFileDialog openFile = new Microsoft.Win32.OpenFileDialog();
            openFile.Filter = "Text files (*.txt)|*.txt| All files (*.*)|*.*";
            openFile.ShowDialog();
            RichText.Document.Blocks.Clear();
            try
            {
                RichText.Document.Blocks.Add(new Paragraph(new Run(File.ReadAllText(openFile.FileName))));
                Fn = openFile.FileName;
            }
            catch
            {

            }


        }
        string StringFromRichTextBox(RichTextBox rtb)
        {
            TextRange textRange = new TextRange(
                rtb.Document.ContentStart,
                rtb.Document.ContentEnd
            );
            return textRange.Text;
        }
        private void Sav_Click(object sender, RoutedEventArgs e) //Кнопка сохранить
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Формат: (*.txt)|*.txt";

            if (Fn.Length>0)
            {
                save.FileName = Fn;
            }
            if (save.ShowDialog()==true)
            {
                using (StreamWriter s = new StreamWriter(save.OpenFile(), Encoding.Default))
                {
                    s.Write(StringFromRichTextBox(RichText));
                    s.Close();
                }
            }
            RichText.Document.Blocks.Clear();
            Fn = "";
            
        }
        private void PRint_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog print = new PrintDialog();
            print.ShowDialog();
        }

        private void CB4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TextSelection text = RichText.Selection;
            if (!text.IsEmpty) //Block.LineHeightProperty
            {
                text.ApplyPropertyValue(Block.LineHeightProperty, CB4.SelectedItem.ToString());
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e) //Цвет
        {
            int[] a = new int[3];
            
            TextSelection text = RichText.Selection;           
            if (!text.IsEmpty) 
            {
                ////ColorPicker n = new ColorPicker();
                //n.Show();
                //a = n.Colors();
                text.ApplyPropertyValue(ForegroundProperty, new SolidColorBrush(Color.FromArgb(ColorP.SelectedColor.Value.A, ColorP.SelectedColor.Value.R, ColorP.SelectedColor.Value.G, ColorP.SelectedColor.Value.B)));
            }
        }
        private void MenuItem_Click_2(object sender, RoutedEventArgs e) //Интервал
        {
            if (CB4.SelectedItem.ToString() != "")
            {
                switch (CB4.SelectedItem.ToString())
                {
                    case "1":
                        {
                            ((Paragraph)RichText.Document.Blocks.FirstBlock).LineHeight = 10;
                            break;
                        }
                    case "1.5":
                        {
                            ((Paragraph)RichText.Document.Blocks.FirstBlock).LineHeight = 20;

                            break;
                        }
                    case "2":
                        {
                            ((Paragraph)RichText.Document.Blocks.FirstBlock).LineHeight = 30;

                            break;
                        }
                    case "3":
                        {
                            ((Paragraph)RichText.Document.Blocks.FirstBlock).LineHeight = 40;
                            break;
                        }
                }
            }
        }
    }

    public class FontFamilyConvecter : IValueConverter//Интерфейс позволяющие пользовательскую логику к привязке
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var sValue = value as string;//Сонверуем в тип данных string знаечие value и записываем в перемуную sValue
            if (sValue == null) return DependencyProperty.UnsetValue; //Проверяем на пустое значение переменной value, если условное равно true тогда возращаем значение Sentinel(используется вместо null , поскольку null может быть допустимым значением свойства, а также допустимым)

            return new FontFamily(sValue);//Возращаем стиль шрифта
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    
}
